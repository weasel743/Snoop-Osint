"""
Exemple de plugin Snoop OSINT v1.0.0

Structure requise:
  PLUGIN_NAME  : str — Nom affiché
  PLUGIN_ID    : str — Identifiant unique
  PLUGIN_DESC  : str — Description
  run(query, timeout, progress_callback) -> list[dict]
"""

PLUGIN_NAME = "Example Plugin"
PLUGIN_ID   = "example"
PLUGIN_DESC = "Un plugin exemple qui illustre la structure d'un module Snoop OSINT"

def run(query, timeout=10, progress_callback=None):
    """
    Effectue une recherche et retourne une liste de dicts.
    Chaque dict représente une ligne dans le tableau de résultats.
    Les clefs du premier dict définissent les colonnes.
    """
    results = []
    # Exemple: appel HTTP, scraping, ou traitement local
    for i in range(5):
        results.append({
            "Champ": f"Exemple {i+1}",
            "Valeur": f"Résultat pour '{query}'",
            "Source": "ExamplePlugin",
        })
        if progress_callback:
            progress_callback(i+1, 5)
    return results
