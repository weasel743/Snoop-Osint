import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(phone,timeout=10):
    results=[]
    try:
        import phonenumbers
        from phonenumbers import geocoder,carrier,timezone
        parsed=phonenumbers.parse(phone,None)
        fmt_intl=phonenumbers.format_number(parsed,phonenumbers.PhoneNumberFormat.INTERNATIONAL)
        fmt_natl=phonenumbers.format_number(parsed,phonenumbers.PhoneNumberFormat.NATIONAL)
        fmt_e164=phonenumbers.format_number(parsed,phonenumbers.PhoneNumberFormat.E164)
        country=geocoder.description_for_number(parsed,"fr") or "Inconnu"
        op=carrier.name_for_number(parsed,"fr") or "Inconnu"
        tz=list(timezone.time_zones_for_number(parsed))
        valid=phonenumbers.is_valid_number(parsed)
        possible=phonenumbers.is_possible_number(parsed)
        ntype=phonenumbers.number_type(parsed)
        type_map={0:"FIXE",1:"MOBILE",2:"FIXE_OU_MOBILE",3:"GRATUIT",4:"PREMIUM",5:"PARTAGE",6:"VOIP",7:"PERSONNEL",8:"PAGER",9:"UAN",10:"VOICEMAIL",99:"INCONNU"}
        results=[
            {"Champ":"Format international","Valeur":fmt_intl,"Source":"phonenumbers"},
            {"Champ":"Format national","Valeur":fmt_natl,"Source":"phonenumbers"},
            {"Champ":"Format E.164","Valeur":fmt_e164,"Source":"phonenumbers"},
            {"Champ":"Pays","Valeur":country,"Source":"phonenumbers"},
            {"Champ":"Indicatif","Valeur":f"+{parsed.country_code}","Source":"phonenumbers"},
            {"Champ":"Numero national","Valeur":str(parsed.national_number),"Source":"phonenumbers"},
            {"Champ":"Operateur","Valeur":op,"Source":"phonenumbers"},
            {"Champ":"Type","Valeur":type_map.get(ntype.real,"INCONNU"),"Source":"phonenumbers"},
            {"Champ":"Valide","Valeur":"✅ Oui" if valid else "❌ Non","Source":"phonenumbers"},
            {"Champ":"Possible","Valeur":"✅ Oui" if possible else "❌ Non","Source":"phonenumbers"},
            {"Champ":"Fuseau horaire","Valeur":", ".join(tz) if tz else "Inconnu","Source":"phonenumbers"},
        ]
    except ImportError:
        results.append({"Champ":"Info","Valeur":"phonenumbers non installe. Installez-le: pip install phonenumbers","Source":""})
    except Exception as e:
        results.append({"Champ":"Erreur","Valeur":f"Numero invalide: {e}","Source":"phonenumbers"})
    # Lookup IP API gratuit
    try:
        r=requests.get(f"http://apilayer.net/api/validate",params={"number":phone},headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            if d.get("valid"): results.append({"Champ":"[apilayer] Pays","Valeur":d.get("country_name",""),"Source":"apilayer.net"})
    except: pass
    return results
