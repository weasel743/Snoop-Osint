import re
from PyQt6.QtCore import QThread, pyqtSignal

def detect_type(value):
    v=value.strip()
    if re.match(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$",v): return "email"
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$",v): return "ip"
    if re.match(r"^([a-zA-Z0-9\-]+\.)+[a-zA-Z]{2,}$",v) and "." in v: return "domain"
    if re.match(r"^(\+\d{1,3}[\s\-]?)?\(?\d{1,4}\)?[\s\-]?\d{3,5}[\s\-]?\d{3,5}$",v): return "phone"
    if re.match(r"^(1[A-HJ-NP-Za-km-z1-9]{25,34}|3[A-HJ-NP-Za-km-z1-9]{25,33}|bc1[a-zA-HJ-NP-Z0-9]{6,87})$",v): return "btc"
    if re.match(r"^0x[a-fA-F0-9]{40}$",v): return "eth"
    if re.match(r"^https?://",v): return "url"
    return "username"

class CorrelationEngine(QThread):
    node_found = pyqtSignal(dict)
    edge_found = pyqtSignal(dict)
    progress = pyqtSignal(str)
    finished_signal = pyqtSignal(list,list)

    def __init__(self,seed,max_depth=3,max_nodes=60,timeout=10):
        super().__init__()
        self.seed=seed; self.max_depth=max_depth
        self.max_nodes=max_nodes; self.timeout=timeout
        self.nodes=[]; self.edges=[]; self._visited=set(); self._stop=False

    def stop(self): self._stop=True

    def _add_node(self,value,ntype,source=""):
        if value in self._visited or len(self.nodes)>=self.max_nodes: return False
        self._visited.add(value)
        node={"id":value,"type":ntype,"value":value,"source":source}
        self.nodes.append(node); self.node_found.emit(node); return True

    def _add_edge(self,src,dst,label=""):
        edge={"src":src,"dst":dst,"label":label}
        self.edges.append(edge); self.edge_found.emit(edge)

    def run(self):
        self._explore(self.seed,detect_type(self.seed),0)
        self.finished_signal.emit(self.nodes,self.edges)

    def _explore(self,value,vtype,depth):
        if self._stop or depth>self.max_depth or len(self.nodes)>=self.max_nodes: return
        if not self._add_node(value,vtype): return
        self.progress.emit(f"[{vtype}] {value}")
        if vtype=="email": self._from_email(value,depth)
        elif vtype=="username": self._from_username(value,depth)
        elif vtype=="domain": self._from_domain(value,depth)
        elif vtype=="ip": self._from_ip(value,depth)

    def _from_email(self,email,depth):
        import requests
        H={"User-Agent":"SnoopOSINT/1.0"}
        local=email.split("@")[0]; domain=email.split("@")[1] if "@" in email else ""
        if domain: self._add_edge(email,domain,"domain"); self._explore(domain,"domain",depth+1)
        import hashlib; h=hashlib.md5(email.lower().strip().encode()).hexdigest()
        try:
            r=requests.get(f"https://www.gravatar.com/{h}.json",headers=H,timeout=self.timeout)
            if r.status_code==200:
                entry=r.json().get("entry",[{}])[0]
                dn=entry.get("displayName","")
                if dn: self._add_node(f"gravatar:{dn}","name","Gravatar"); self._add_edge(email,f"gravatar:{dn}","name")
                for acc in entry.get("accounts",[]):
                    url=acc.get("url","")
                    if url: self._add_node(url,"platform","Gravatar"); self._add_edge(email,url,"platform")
        except: pass
        try:
            r2=requests.get("https://api.github.com/search/users",params={"q":f"{email} in:email"},headers={**H,"Accept":"application/vnd.github.v3+json"},timeout=self.timeout)
            if r2.status_code==200:
                items=r2.json().get("items",[])
                for item in items[:2]:
                    login=item.get("login","")
                    if login: self._add_edge(email,login,"github"); self._explore(login,"username",depth+1)
        except: pass

    def _from_username(self,username,depth):
        import requests
        H={"User-Agent":"SnoopOSINT/1.0","Accept":"application/vnd.github.v3+json"}
        try:
            r=requests.get(f"https://api.github.com/users/{username}",headers=H,timeout=self.timeout)
            if r.status_code==200:
                d=r.json()
                email=d.get("email","")
                blog=d.get("blog",""); company=d.get("company",""); loc=d.get("location","")
                if email: self._add_edge(username,email,"github_email"); self._explore(email,"email",depth+1)
                if blog:
                    b=blog.replace("https://","").replace("http://","").split("/")[0]
                    if b: self._add_edge(username,b,"github_blog"); self._explore(b,"domain",depth+1)
                if company: self._add_node(f"company:{company}","org","GitHub"); self._add_edge(username,f"company:{company}","employer")
                if loc: self._add_node(f"location:{loc}","location","GitHub"); self._add_edge(username,f"location:{loc}","location")
                r2=requests.get(f"https://api.github.com/users/{username}/events/public",params={"per_page":30},headers=H,timeout=self.timeout)
                if r2.status_code==200:
                    for ev in r2.json():
                        for commit in ev.get("payload",{}).get("commits",[]):
                            ce=commit.get("author",{}).get("email","")
                            if ce and "noreply" not in ce: self._add_edge(username,ce,"commit_email"); self._explore(ce,"email",depth+1)
        except: pass

    def _from_domain(self,domain,depth):
        import requests
        H={"User-Agent":"SnoopOSINT/1.0"}
        try:
            r=requests.get(f"https://dns.google/resolve?name={domain}&type=A",headers={**H,"Accept":"application/dns-json"},timeout=self.timeout)
            if r.status_code==200:
                for ans in r.json().get("Answer",[]):
                    ip=ans.get("data","")
                    if ip: self._add_edge(domain,ip,"A record"); self._explore(ip,"ip",depth+1)
        except: pass
        try:
            r2=requests.get("https://crt.sh/",params={"q":f"%.{domain}","output":"json"},headers=H,timeout=self.timeout)
            if r2.status_code==200:
                seen_subs=set()
                for c in r2.json()[:15]:
                    cn=c.get("common_name","").strip()
                    if cn and "*" not in cn and cn.endswith(domain) and cn!=domain and cn not in seen_subs:
                        seen_subs.add(cn); self._add_node(cn,"domain","crt.sh"); self._add_edge(domain,cn,"subdomain")
        except: pass

    def _from_ip(self,ip,depth):
        import requests
        H={"User-Agent":"SnoopOSINT/1.0"}
        try:
            r=requests.get(f"http://ip-api.com/json/{ip}",params={"fields":"org,isp,as,hosting"},headers=H,timeout=self.timeout)
            if r.status_code==200:
                d=r.json()
                org=d.get("org",""); isp=d.get("isp","")
                if org: self._add_node(f"org:{org}","org","ip-api"); self._add_edge(ip,f"org:{org}","organisation")
                if isp and isp!=org: self._add_node(f"isp:{isp}","org","ip-api"); self._add_edge(ip,f"isp:{isp}","isp")
        except: pass
        try:
            r2=requests.get(f"https://internetdb.shodan.io/{ip}",headers=H,timeout=self.timeout)
            if r2.status_code==200:
                d2=r2.json()
                for h in d2.get("hostnames",[])[:3]:
                    self._add_node(h,"domain","Shodan"); self._add_edge(ip,h,"hostname")
                    self._explore(h,"domain",depth+1)
        except: pass
