import os
def run(path,timeout=10):
    results=[]
    if not os.path.exists(path):
        return [{"Champ":"Erreur","Valeur":"Fichier introuvable","Source":""}]
    try:
        from PIL import Image, ExifTags
        img=Image.open(path)
        results.append({"Champ":"Format","Valeur":img.format or "Inconnu","Source":"Pillow"})
        results.append({"Champ":"Taille","Valeur":f"{img.width}x{img.height} px","Source":"Pillow"})
        results.append({"Champ":"Mode","Valeur":img.mode,"Source":"Pillow"})
        exif=img._getexif()
        if exif:
            for tag_id,v in exif.items():
                tag=ExifTags.TAGS.get(tag_id,str(tag_id))
                if tag=="GPSInfo":
                    try:
                        gps={}
                        for k2,v2 in v.items():
                            gps[ExifTags.GPSTAGS.get(k2,k2)]=v2
                        def to_deg(val):
                            d,m,s=val; return float(d)+float(m)/60+float(s)/3600
                        lat=to_deg(gps.get("GPSLatitude",(0,0,0)))
                        if gps.get("GPSLatitudeRef")=="S": lat=-lat
                        lon=to_deg(gps.get("GPSLongitude",(0,0,0)))
                        if gps.get("GPSLongitudeRef")=="W": lon=-lon
                        results.append({"Champ":"GPS Latitude","Valeur":f"{lat:.6f}","Source":"EXIF"})
                        results.append({"Champ":"GPS Longitude","Valeur":f"{lon:.6f}","Source":"EXIF"})
                        results.append({"Champ":"GPS Altitude","Valeur":str(gps.get("GPSAltitude","")),"Source":"EXIF"})
                        results.append({"Champ":"Google Maps","Valeur":f"https://maps.google.com/?q={lat:.6f},{lon:.6f}","Source":"EXIF"})
                    except: pass
                elif tag not in ("MakerNote","UserComment") and v:
                    results.append({"Champ":tag,"Valeur":str(v)[:200],"Source":"EXIF"})
    except ImportError: results.append({"Champ":"Info","Valeur":"Pillow non installe","Source":""})
    except Exception as e: results.append({"Champ":"Erreur Pillow","Valeur":str(e),"Source":""})
    try:
        import exifread
        with open(path,"rb") as f:
            tags=exifread.process_file(f,details=False)
        for k,v in tags.items():
            if "thumbnail" not in k.lower():
                results.append({"Champ":f"[exifread] {k}","Valeur":str(v)[:200],"Source":"exifread"})
    except: pass
    return results or [{"Champ":"Info","Valeur":"Aucune donnee EXIF trouvee","Source":""}]
