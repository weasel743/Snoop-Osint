import requests
H={"User-Agent":"SnoopOSINT/1.0","Accept":"application/vnd.github.v3+json"}
def run(username,timeout=10):
    results=[]
    try:
        r=requests.get(f"https://api.github.com/users/{username}",headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            for k,v in {"Nom":d.get("name"),"Login":d.get("login"),"Bio":d.get("bio"),"Email":d.get("email"),"Entreprise":d.get("company"),"Localisation":d.get("location"),"Site":d.get("blog"),"Twitter":d.get("twitter_username"),"Repos publics":d.get("public_repos"),"Gists":d.get("public_gists"),"Followers":d.get("followers"),"Following":d.get("following"),"Compte cree le":d.get("created_at","")[:10],"Derniere activite":d.get("updated_at","")[:10],"Profile URL":d.get("html_url"),"Avatar":d.get("avatar_url")}.items():
                if v is not None: results.append({"Champ":k,"Valeur":str(v)[:200],"Source":"GitHub API"})
        elif r.status_code==404:
            return [{"Champ":"Erreur","Valeur":"Utilisateur GitHub introuvable","Source":"GitHub API"}]
    except Exception as e:
        return [{"Champ":"Erreur","Valeur":str(e),"Source":"GitHub API"}]
    try:
        r2=requests.get(f"https://api.github.com/users/{username}/repos",params={"per_page":100,"sort":"updated"},headers=H,timeout=timeout)
        if r2.status_code==200:
            repos=r2.json()
            langs={}
            for repo in repos:
                l=repo.get("language")
                if l: langs[l]=langs.get(l,0)+1
            if langs:
                top=sorted(langs.items(),key=lambda x:-x[1])[:5]
                results.append({"Champ":"Langages principaux","Valeur":", ".join(f"{l}({c})" for l,c in top),"Source":"GitHub Repos"})
            stars=sum(r3.get("stargazers_count",0) for r3 in repos)
            results.append({"Champ":"Stars totales","Valeur":str(stars),"Source":"GitHub Repos"})
            forks=sum(r3.get("forks_count",0) for r3 in repos)
            results.append({"Champ":"Forks totaux","Valeur":str(forks),"Source":"GitHub Repos"})
            for repo in repos[:5]:
                results.append({"Champ":f"Repo: {repo.get('name','')}","Valeur":f"⭐{repo.get('stargazers_count',0)} | {repo.get('description','')[:80]}","Source":"GitHub Repos"})
    except: pass
    try:
        r3=requests.get(f"https://api.github.com/users/{username}/orgs",headers=H,timeout=timeout)
        if r3.status_code==200:
            orgs=r3.json()
            if orgs:
                results.append({"Champ":"Organisations","Valeur":", ".join(o.get("login","") for o in orgs),"Source":"GitHub API"})
    except: pass
    try:
        r4=requests.get(f"https://api.github.com/users/{username}/events/public",params={"per_page":30},headers=H,timeout=timeout)
        if r4.status_code==200:
            emails_commits=set()
            for ev in r4.json():
                payload=ev.get("payload",{})
                for commit in payload.get("commits",[]):
                    email=commit.get("author",{}).get("email","")
                    name=commit.get("author",{}).get("name","")
                    if email and "noreply" not in email: emails_commits.add(f"{name} <{email}>")
            if emails_commits:
                results.append({"Champ":"Emails dans commits","Valeur":", ".join(list(emails_commits)[:5]),"Source":"GitHub Events"})
    except: pass
    return results
