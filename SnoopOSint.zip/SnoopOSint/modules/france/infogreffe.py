import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(query,timeout=15):
    results=[]
    try:
        r=requests.get("https://recherche-entreprises.api.gouv.fr/search",params={"q":query,"per_page":5},headers=H,timeout=timeout)
        if r.status_code==200:
            for c in r.json().get("results",[]):
                siren=c.get("siren","")
                if siren:
                    try:
                        r2=requests.get(f"https://entreprise.data.gouv.fr/api/sirene/v3/etablissements/{siren}",headers=H,timeout=timeout)
                        if r2.status_code==200:
                            d=r2.json().get("etablissement",{})
                            u=d.get("unite_legale",{})
                            results.append({"Source":"data.gouv.fr","Nom":u.get("denomination",""),"SIREN":siren,"Dirigeant":f"{u.get('prenom_usuel','')} {u.get('nom','')}".strip(),"Forme":u.get("forme_juridique_libelle",""),"Statut":u.get("etat_administratif","")})
                    except: pass
                if not results:
                    siege=c.get("siege",{})
                    results.append({"Source":"API Entreprises","Nom":c.get("nom_complet",""),"SIREN":siren,"Dirigeant":"Non disponible sans clef","Forme":c.get("forme_juridique",""),"Statut":"Actif" if c.get("etat_administratif")=="A" else c.get("etat_administratif","")})
    except Exception as e:
        results.append({"Source":"API Entreprises","Nom":f"Erreur: {e}","SIREN":"","Dirigeant":"","Forme":"","Statut":""})
    return results or [{"Source":"","Nom":"Aucun resultat","SIREN":"","Dirigeant":"","Forme":"","Statut":""}]
