import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(query,timeout=15):
    results=[]
    try:
        r=requests.get("https://recherche-entreprises.api.gouv.fr/search",params={"q":query,"per_page":10},headers=H,timeout=timeout)
        if r.status_code==200:
            items=r.json().get("results",[])
            if not items:
                results.append({"Source":"API Entreprises","Nom":"Aucun resultat","SIREN":"","Ville":"","NAF":"","Forme":""})
                return results
            for c in items:
                siege=c.get("siege",{})
                results.append({"Source":"API Entreprises","Nom":c.get("nom_complet",""),"SIREN":c.get("siren",""),"Ville":siege.get("libelle_commune",""),"NAF":c.get("activite_principale",""),"Forme":c.get("forme_juridique","")})
    except Exception as e:
        results.append({"Source":"API Entreprises","Nom":f"Erreur: {e}","SIREN":"","Ville":"","NAF":"","Forme":""})
    try:
        r2=requests.get("https://public.opendatasoft.com/api/explore/v2.1/catalog/datasets/bulletins-officiels-des-annonces-civiles-et-commerciales/records",
            params={"where":f"denomination like '{query}'","limit":10,"order_by":"dateparution desc"},headers=H,timeout=timeout)
        if r2.status_code==200:
            records=r2.json().get("results",[])
            for rec in records[:5]:
                results.append({"Source":"BODACC","Nom":rec.get("denomination",""),"SIREN":rec.get("numeroinsertion",""),"Ville":rec.get("tribunal",""),"NAF":rec.get("familleavis_lib",""),"Forme":rec.get("dateparution","")})
    except: pass
    return results or [{"Source":"","Nom":"Aucun resultat","SIREN":"","Ville":"","NAF":"","Forme":""}]
