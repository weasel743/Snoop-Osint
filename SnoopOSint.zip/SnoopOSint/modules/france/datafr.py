import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(query,timeout=15):
    results=[]
    try:
        r=requests.get("https://www.data.gouv.fr/api/1/datasets/",params={"q":query,"page_size":10},headers=H,timeout=timeout)
        if r.status_code==200:
            items=r.json().get("data",[])
            if items:
                for ds in items:
                    org=ds.get("organization",{}) or {}
                    results.append({"Source":"data.gouv.fr","Titre":ds.get("title","")[:80],"Organisation":org.get("name","")[:60],"URL":ds.get("page",""),"Date":ds.get("last_modified","")[:10]})
            else:
                results.append({"Source":"data.gouv.fr","Titre":"Aucun resultat","Organisation":"","URL":"","Date":""})
    except Exception as e:
        results.append({"Source":"data.gouv.fr","Titre":f"Erreur: {e}","Organisation":"","URL":"","Date":""})
    try:
        r2=requests.get("https://api-entreprise.data.gouv.fr/rncs/v1/fiches_identite",params={"q":query},headers=H,timeout=timeout)
        if r2.status_code==200:
            items2=r2.json().get("fiches",[])
            for item in items2[:3]:
                results.append({"Source":"RNA Associations","Titre":item.get("denomination",""),"Organisation":item.get("siret",""),"URL":"","Date":item.get("date_mise_a_jour","")[:10]})
    except: pass
    return results or [{"Source":"","Titre":"Aucun resultat","Organisation":"","URL":"","Date":""}]
