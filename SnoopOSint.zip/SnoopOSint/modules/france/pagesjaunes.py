import requests
from bs4 import BeautifulSoup
H={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Accept":"text/html,application/xhtml+xml","Accept-Language":"fr-FR,fr;q=0.9"}
def run(query,timeout=15):
    results=[]
    try:
        r=requests.get("https://www.pagesjaunes.fr/annuaire/chercherlespros",params={"quoiqui":query,"ou":"France"},headers=H,timeout=timeout)
        if r.status_code==200:
            soup=BeautifulSoup(r.text,"html.parser")
            cards=soup.find_all("div",class_="bi-content",limit=10)
            if not cards: cards=soup.find_all("article",limit=10)
            if cards:
                for card in cards:
                    name_el=card.find(["h3","h2","span"],class_=lambda c:c and ("denomination" in c or "title" in c or "nom" in c))
                    name=name_el.get_text(strip=True) if name_el else query
                    addr_el=card.find(["span","p"],class_=lambda c:c and "adresse" in c)
                    addr=addr_el.get_text(strip=True) if addr_el else ""
                    tel_el=card.find(["span","a"],class_=lambda c:c and "tel" in c)
                    tel=tel_el.get_text(strip=True) if tel_el else ""
                    cat_el=card.find(["span","p"],class_=lambda c:c and ("activite" in c or "categorie" in c))
                    cat=cat_el.get_text(strip=True) if cat_el else ""
                    results.append({"Source":"Pages Jaunes","Nom":name[:100],"Adresse":addr[:150],"Telephone":tel,"Categorie":cat[:80]})
            else:
                if query.lower() in r.text.lower():
                    results.append({"Source":"Pages Jaunes","Nom":query,"Adresse":"Voir pagesjaunes.fr","Telephone":"","Categorie":""})
                else:
                    results.append({"Source":"Pages Jaunes","Nom":"Aucun resultat","Adresse":"","Telephone":"","Categorie":""})
        else:
            results.append({"Source":"Pages Jaunes","Nom":f"Erreur HTTP {r.status_code}","Adresse":"","Telephone":"","Categorie":""})
    except Exception as e:
        results.append({"Source":"Pages Jaunes","Nom":f"Erreur: {e}","Adresse":"","Telephone":"","Categorie":""})
    return results
