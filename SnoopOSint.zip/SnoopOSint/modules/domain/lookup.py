import requests, ssl, socket
H={"User-Agent":"SnoopOSINT/1.0"}
def _clean(domain): return domain.replace("https://","").replace("http://","").split("/")[0].strip()

def run_whois(domain,timeout=15):
    results=[]; d=_clean(domain)
    try:
        import whois; w=whois.whois(d)
        for k,v in {"Domaine":w.domain_name,"Registrar":w.registrar,"Creation":w.creation_date,"Expiration":w.expiration_date,"MAJ":w.updated_date,"Statut":w.status,"Serveurs NS":w.name_servers,"Emails":w.emails,"Pays":w.country,"Organisation":w.org,"DNSSEC":w.dnssec}.items():
            if v:
                val=v if isinstance(v,str) else (", ".join(str(x) for x in (v[:3] if isinstance(v,(list,set)) else [v])))
                results.append({"Champ":k,"Valeur":str(val)[:200],"Source":"python-whois"})
    except ImportError: results.extend(_fallback(d,timeout))
    except: results.extend(_fallback(d,timeout))
    if not results: results.extend(_fallback(d,timeout))
    return results

def _fallback(domain,timeout):
    results=[]
    try:
        r=requests.get(f"https://who-dat.as93.net/{domain}",headers=H,timeout=timeout)
        if r.status_code==200:
            d2=r.json(); reg=d2.get("Registrant",{}); ri=d2.get("Registrar",{}); dom=d2.get("Domain",{})
            for k,v in {"Registrar":ri.get("Name",""),"URL Registrar":ri.get("URL",""),"Organisation":reg.get("Organization",""),"Pays":reg.get("Country",""),"Creation":dom.get("Created Date",""),"Expiration":dom.get("Expiration Date",""),"MAJ":dom.get("Updated Date",""),"Statut":", ".join(dom.get("Status",[])),"DNSSEC":dom.get("DNSSEC","")}.items():
                if v: results.append({"Champ":k,"Valeur":str(v)[:200],"Source":"who-dat.as93.net"})
    except: pass
    try:
        r2=requests.get(f"https://rdap.org/domain/{domain}",headers=H,timeout=timeout)
        if r2.status_code==200:
            d3=r2.json()
            if d3.get("status"): results.append({"Champ":"RDAP Status","Valeur":", ".join(d3["status"]),"Source":"rdap.org"})
            for ev in d3.get("events",[])[:3]:
                results.append({"Champ":f"RDAP {ev.get('eventAction','')}","Valeur":ev.get("eventDate","")[:25],"Source":"rdap.org"})
    except: pass
    return results

def run_dns(domain,timeout=10):
    results=[]; d=_clean(domain)
    try:
        import dns.resolver
        for rtype in ["A","AAAA","MX","NS","TXT","CNAME","SOA","CAA"]:
            try:
                ans=dns.resolver.resolve(d,rtype,lifetime=timeout)
                for rdata in ans:
                    results.append({"Type":rtype,"Valeur":str(rdata),"TTL":str(ans.rrset.ttl),"Source":"dnspython"})
            except: pass
    except ImportError:
        results.extend(_doh(d,timeout))
    if not results: results.extend(_doh(d,timeout))
    return results

def _doh(domain,timeout):
    results=[]
    for rtype in ["A","AAAA","MX","NS","TXT","CNAME","SOA","CAA"]:
        try:
            r=requests.get(f"https://dns.google/resolve?name={domain}&type={rtype}",headers={**H,"Accept":"application/dns-json"},timeout=timeout)
            if r.status_code==200:
                for ans in r.json().get("Answer",[]):
                    results.append({"Type":rtype,"Valeur":ans.get("data",""),"TTL":str(ans.get("TTL","")),"Source":"DNS over HTTPS"})
        except: pass
    return results

def run_ssl(domain,timeout=10):
    results=[]; d=_clean(domain)
    try:
        ctx=ssl.create_default_context()
        with socket.create_connection((d,443),timeout=timeout) as sock:
            with ctx.wrap_socket(sock,server_hostname=d) as ss:
                cert=ss.getpeercert()
                subj=dict(x[0] for x in cert.get("subject",[]))
                iss=dict(x[0] for x in cert.get("issuer",[]))
                san=", ".join(v for t,v in cert.get("subjectAltName",[]) if t=="DNS")
                not_after=cert.get("notAfter","")
                try:
                    from datetime import datetime
                    exp=datetime.strptime(not_after,"%b %d %H:%M:%S %Y %Z")
                    days=(exp-datetime.utcnow()).days
                    validity=f"✅ Valide ({days} jours)" if days>0 else f"❌ EXPIRE il y a {-days} jours"
                except: validity="Inconnu"
                results+=[
                    {"Champ":"CN","Valeur":subj.get("commonName",""),"Source":"SSL"},
                    {"Champ":"Organisation","Valeur":subj.get("organizationName",""),"Source":"SSL"},
                    {"Champ":"Emetteur","Valeur":iss.get("commonName",""),"Source":"SSL"},
                    {"Champ":"Emetteur Org","Valeur":iss.get("organizationName",""),"Source":"SSL"},
                    {"Champ":"Valide depuis","Valeur":cert.get("notBefore",""),"Source":"SSL"},
                    {"Champ":"Expire le","Valeur":not_after,"Source":"SSL"},
                    {"Champ":"Validite","Valeur":validity,"Source":"SSL"},
                    {"Champ":"SANs","Valeur":san[:300],"Source":"SSL"},
                    {"Champ":"Version TLS","Valeur":ss.version(),"Source":"SSL"},
                ]
    except Exception as e:
        results.append({"Champ":"Info","Valeur":str(e),"Source":"SSL"})
    try:
        r=requests.get("https://crt.sh/",params={"q":d,"output":"json"},headers=H,timeout=timeout)
        if r.status_code==200:
            certs=r.json()
            results.append({"Champ":"Certificats historiques","Valeur":str(len(certs)),"Source":"crt.sh"})
            seen=set()
            for c in certs[:10]:
                cn=c.get("common_name","")
                if cn and cn not in seen: seen.add(cn); results.append({"Champ":"Cert historique","Valeur":f"{cn} (expire {c.get('not_after','')[:10]})","Source":"crt.sh"})
    except: pass
    return [x for x in results if x.get("Valeur")]

def run_subdomains(domain,timeout=10):
    results=[]; d=_clean(domain); seen=set()
    try:
        r=requests.get("https://crt.sh/",params={"q":f"%.{d}","output":"json"},headers=H,timeout=timeout)
        if r.status_code==200:
            for c in r.json():
                cn=c.get("common_name","").strip()
                if cn and cn not in seen and "*" not in cn and cn.endswith(d):
                    seen.add(cn); results.append({"Sous-domaine":cn,"Source":"crt.sh","Statut":"Detecte dans certificat"})
    except: pass
    for sub in ["www","mail","ftp","api","dev","staging","test","admin","webmail","vpn","remote","portal","blog","shop","cdn","static","assets"]:
        host=f"{sub}.{d}"
        if host in seen: continue
        try:
            ip=socket.gethostbyname(host); seen.add(host)
            results.append({"Sous-domaine":host,"Source":"DNS brute","Statut":f"Resolu -> {ip}"})
        except: pass
    return results
