import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(query,timeout=10):
    results=[]
    try:
        r=requests.get(f"https://psbdmp.ws/api/v3/search/{query}",headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            data=d.get("data",[])
            if data:
                results.append({"Source":"psbdmp.ws","Statut":f"✅ {len(data)} paste(s) trouves","URL":"https://psbdmp.ws","Details":""})
                for p in data[:10]:
                    results.append({"Source":"psbdmp.ws","Statut":"📋 Paste","URL":f"https://pastebin.com/{p.get('id','')}","Details":p.get("tags","")[:100]})
            else:
                results.append({"Source":"psbdmp.ws","Statut":"❌ Aucun resultat","URL":"","Details":""})
    except Exception as e:
        results.append({"Source":"psbdmp.ws","Statut":"⚫ Erreur","URL":"","Details":str(e)})
    try:
        r2=requests.get(f"https://pastes.io/api/v1/search?q={query}",headers=H,timeout=timeout)
        if r2.status_code==200:
            d2=r2.json()
            items=d2.get("items",[]) if isinstance(d2,dict) else []
            if items:
                results.append({"Source":"pastes.io","Statut":f"✅ {len(items)} paste(s)","URL":"https://pastes.io","Details":""})
            else:
                results.append({"Source":"pastes.io","Statut":"❌ Aucun resultat","URL":"","Details":""})
    except Exception as e:
        results.append({"Source":"pastes.io","Statut":"⚫ Erreur","URL":"","Details":str(e)})
    return results or [{"Source":"","Statut":"Aucun resultat","URL":"","Details":""}]
