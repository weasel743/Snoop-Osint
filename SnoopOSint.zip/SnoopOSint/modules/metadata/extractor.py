import os
def run(path,timeout=10):
    results=[]
    if not os.path.exists(path):
        return [{"Champ":"Erreur","Valeur":"Fichier introuvable","Source":""}]
    ext=os.path.splitext(path)[1].lower()
    size=os.path.getsize(path)
    results.append({"Champ":"Fichier","Valeur":os.path.basename(path),"Source":"OS"})
    results.append({"Champ":"Taille","Valeur":f"{size:,} octets ({size//1024} Ko)","Source":"OS"})
    results.append({"Champ":"Extension","Valeur":ext,"Source":"OS"})
    from datetime import datetime
    mtime=os.path.getmtime(path)
    results.append({"Champ":"Modifie le","Valeur":datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S"),"Source":"OS"})
    if ext==".pdf":
        try:
            import PyPDF2
            with open(path,"rb") as f:
                reader=PyPDF2.PdfReader(f)
                info=reader.metadata
                results.append({"Champ":"Pages","Valeur":str(len(reader.pages)),"Source":"PyPDF2"})
                if info:
                    for k,v in info.items():
                        if v: results.append({"Champ":str(k).replace("/",""),"Valeur":str(v)[:200],"Source":"PDF metadata"})
        except ImportError:
            results.append({"Champ":"Info","Valeur":"PyPDF2 non installe (pip install PyPDF2)","Source":""})
        except Exception as e: results.append({"Champ":"Erreur PDF","Valeur":str(e),"Source":""})
    elif ext in(".docx",".dotx"):
        try:
            import zipfile,xml.etree.ElementTree as ET
            with zipfile.ZipFile(path) as z:
                if "docProps/core.xml" in z.namelist():
                    tree=ET.parse(z.open("docProps/core.xml"))
                    ns={"cp":"http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
                        "dc":"http://purl.org/dc/elements/1.1/","dcterms":"http://purl.org/dc/terms/"}
                    root=tree.getroot()
                    for tag,label in [("dc:creator","Auteur"),("cp:lastModifiedBy","Derniere modif par"),
                                      ("dcterms:created","Cree le"),("dcterms:modified","Modifie le"),
                                      ("cp:revision","Revision"),("dc:title","Titre"),("dc:subject","Sujet"),
                                      ("dc:description","Description"),("cp:keywords","Mots-cles")]:
                        prefix,name=tag.split(":")
                        el=root.find(f"{{{ns[prefix]}}}{name}")
                        if el is not None and el.text:
                            results.append({"Champ":label,"Valeur":el.text[:200],"Source":"DOCX metadata"})
        except Exception as e: results.append({"Champ":"Erreur DOCX","Valeur":str(e),"Source":""})
    elif ext in(".xlsx",".xls"):
        try:
            import zipfile,xml.etree.ElementTree as ET
            with zipfile.ZipFile(path) as z:
                if "docProps/core.xml" in z.namelist():
                    tree=ET.parse(z.open("docProps/core.xml"))
                    root=tree.getroot()
                    ns={"cp":"http://schemas.openxmlformats.org/package/2006/metadata/core-properties","dc":"http://purl.org/dc/elements/1.1/","dcterms":"http://purl.org/dc/terms/"}
                    for tag,label in [("dc:creator","Auteur"),("cp:lastModifiedBy","Derniere modif par"),("dcterms:created","Cree le"),("dcterms:modified","Modifie le")]:
                        prefix,name=tag.split(":")
                        el=root.find(f"{{{ns[prefix]}}}{name}")
                        if el is not None and el.text:
                            results.append({"Champ":label,"Valeur":el.text[:200],"Source":"XLSX metadata"})
        except Exception as e: results.append({"Champ":"Erreur XLSX","Valeur":str(e),"Source":""})
    elif ext in(".jpg",".jpeg",".png",".gif",".bmp",".tiff",".webp"):
        try:
            from modules.image.exif_extract import run as exif_run
            return exif_run(path)
        except: pass
    return results or [{"Champ":"Info","Valeur":"Aucune metadonnee trouvee","Source":""}]
