import socket
from concurrent.futures import ThreadPoolExecutor, as_completed
PORTS={21:"FTP",22:"SSH",23:"Telnet",25:"SMTP",53:"DNS",80:"HTTP",110:"POP3",143:"IMAP",
       443:"HTTPS",445:"SMB",3306:"MySQL",3389:"RDP",5432:"PostgreSQL",5900:"VNC",
       6379:"Redis",8080:"HTTP-Alt",8443:"HTTPS-Alt",8888:"HTTP-Dev",
       27017:"MongoDB",9200:"Elasticsearch",11211:"Memcached"}
def _scan_port(host,port,timeout):
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        s.settimeout(timeout)
        r=s.connect_ex((host,port))
        banner=""
        if r==0:
            try:
                s.send(b"HEAD / HTTP/1.0\r\n\r\n")
                banner=s.recv(256).decode("utf-8","ignore").strip().split("\n")[0][:100]
            except: pass
        s.close()
        return {"Port":str(port),"Service":PORTS.get(port,"Inconnu"),"Statut":"🟢 Ouvert" if r==0 else "🔴 Ferme","Banner":banner}
    except Exception as e:
        return {"Port":str(port),"Service":PORTS.get(port,"Inconnu"),"Statut":"⚫ Erreur","Banner":str(e)[:50]}
def run(host,timeout=1,max_workers=50,progress_callback=None):
    results=[]
    clean=host.replace("https://","").replace("http://","").split("/")[0].strip()
    try:
        ip=socket.gethostbyname(clean)
        results.append({"Port":"INFO","Service":"Resolution","Statut":"✅ OK","Banner":f"{clean} -> {ip}"})
    except Exception as e:
        return [{"Port":"ERREUR","Service":"DNS","Statut":"❌","Banner":f"Impossible de resoudre {clean}: {e}"}]
    done=0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures={ex.submit(_scan_port,clean,p,timeout):p for p in PORTS}
        for fut in as_completed(futures):
            done+=1; res=fut.result(); results.append(res)
            if progress_callback:
                try: progress_callback(done,len(PORTS),res)
                except: pass
    open_ports=[r for r in results if "Ouvert" in r.get("Statut","")]
    closed=[r for r in results if "Ferme" in r.get("Statut","") or "Erreur" in r.get("Statut","")]
    info=[r for r in results if r.get("Port")=="INFO"]
    return info + open_ports + closed
