import requests
H={"User-Agent":"SnoopOSINT/1.0","Accept":"application/json"}
def run(ip,timeout=10):
    results=[]
    try:
        r=requests.get(f"http://ip-api.com/json/{ip}",params={"fields":"status,message,continent,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,isp,org,as,asname,mobile,proxy,hosting,query"},headers=H,timeout=timeout)
        d=r.json()
        if d.get("status")=="success":
            results+=[
                {"Champ":"Adresse IP","Valeur":d.get("query",ip),"Source":"ip-api.com"},
                {"Champ":"Continent","Valeur":d.get("continent",""),"Source":"ip-api.com"},
                {"Champ":"Pays","Valeur":f"{d.get('country','')} ({d.get('countryCode','')})","Source":"ip-api.com"},
                {"Champ":"Region","Valeur":d.get("regionName",""),"Source":"ip-api.com"},
                {"Champ":"Ville","Valeur":d.get("city",""),"Source":"ip-api.com"},
                {"Champ":"Code postal","Valeur":d.get("zip",""),"Source":"ip-api.com"},
                {"Champ":"Latitude","Valeur":str(d.get("lat","")),"Source":"ip-api.com"},
                {"Champ":"Longitude","Valeur":str(d.get("lon","")),"Source":"ip-api.com"},
                {"Champ":"Fuseau horaire","Valeur":d.get("timezone",""),"Source":"ip-api.com"},
                {"Champ":"ISP","Valeur":d.get("isp",""),"Source":"ip-api.com"},
                {"Champ":"Organisation","Valeur":d.get("org",""),"Source":"ip-api.com"},
                {"Champ":"AS","Valeur":d.get("as",""),"Source":"ip-api.com"},
                {"Champ":"ASN Name","Valeur":d.get("asname",""),"Source":"ip-api.com"},
                {"Champ":"Mobile","Valeur":"Oui" if d.get("mobile") else "Non","Source":"ip-api.com"},
                {"Champ":"Proxy/VPN","Valeur":"⚠️ DETECTE" if d.get("proxy") else "Non detecte","Source":"ip-api.com"},
                {"Champ":"Hebergement","Valeur":"Oui" if d.get("hosting") else "Non","Source":"ip-api.com"},
                {"Champ":"Google Maps","Valeur":f"https://maps.google.com/?q={d.get('lat')},{d.get('lon')}","Source":"ip-api.com"},
            ]
    except Exception as e:
        results.append({"Champ":"Erreur","Valeur":str(e),"Source":"ip-api.com"})
    try:
        r2=requests.get(f"https://ipinfo.io/{ip}/json",headers=H,timeout=timeout)
        if r2.status_code==200:
            d2=r2.json()
            for k,v in d2.items():
                if k not in("ip","readme") and v:
                    results.append({"Champ":f"[ipinfo] {k}","Valeur":str(v)[:200],"Source":"ipinfo.io"})
    except: pass
    try:
        r3=requests.get(f"https://internetdb.shodan.io/{ip}",headers=H,timeout=timeout)
        if r3.status_code==200:
            d3=r3.json()
            if d3.get("ports"): results.append({"Champ":"Ports ouverts (Shodan)","Valeur":", ".join(str(p) for p in d3["ports"]),"Source":"Shodan InternetDB"})
            if d3.get("cpes"): results.append({"Champ":"CPE (Shodan)","Valeur":", ".join(d3["cpes"][:5]),"Source":"Shodan InternetDB"})
            if d3.get("vulns"): results.append({"Champ":"CVE detectees","Valeur":", ".join(d3["vulns"][:5]),"Source":"Shodan InternetDB"})
            if d3.get("hostnames"): results.append({"Champ":"Hostnames","Valeur":", ".join(d3["hostnames"][:5]),"Source":"Shodan InternetDB"})
            if d3.get("tags"): results.append({"Champ":"Tags","Valeur":", ".join(d3["tags"]),"Source":"Shodan InternetDB"})
    except: pass
    return [x for x in results if x.get("Valeur")]
