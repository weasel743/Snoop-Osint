import requests, hashlib
H={"User-Agent":"SnoopOSINT/1.0"}
def run(email,timeout=10):
    results=[]
    try:
        r=requests.get("https://breachdirectory.org/api",params={"func":"auto","term":email},headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            if d.get("success") and d.get("result"):
                results.append({"Source":"BreachDirectory","Statut":"✅ TROUVE","Entrees":str(len(d["result"])),"Details":"Donnees trouvees dans des fuites"})
                for item in d["result"][:10]:
                    results.append({"Source":"BreachDirectory","Statut":"📋 Entree","Entrees":"1","Details":str(item)[:150]})
            else:
                results.append({"Source":"BreachDirectory","Statut":"❌ Non trouve","Entrees":"0","Details":"Aucune fuite detectee"})
        else:
            results.append({"Source":"BreachDirectory","Statut":"⚫ Erreur","Entrees":"0","Details":f"HTTP {r.status_code}"})
    except Exception as e:
        results.append({"Source":"BreachDirectory","Statut":"⚫ Erreur","Entrees":"0","Details":str(e)})
    # HIBP pwned passwords (anonymized k-anonymity)
    try:
        sha=hashlib.sha1(email.encode()).hexdigest().upper()
        r2=requests.get(f"https://api.pwnedpasswords.com/range/{sha[:5]}",headers=H,timeout=timeout)
        if r2.status_code==200:
            count=0
            for line in r2.text.splitlines():
                suffix,n=line.split(":")
                if sha[5:]==suffix: count=int(n); break
            if count>0:
                results.append({"Source":"HIBP Passwords","Statut":"⚠️ ATTENTION","Entrees":str(count),"Details":f"Hash SHA1 trouve {count} fois dans les fuites de mots de passe"})
    except: pass
    return results or [{"Source":"","Statut":"Aucun resultat","Entrees":"0","Details":""}]
