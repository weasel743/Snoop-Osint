import requests, hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
H = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Accept":"application/json,text/html"}
def _gravatar(email,timeout):
    h=hashlib.md5(email.lower().strip().encode()).hexdigest()
    try:
        r=requests.get(f"https://www.gravatar.com/{h}.json",headers=H,timeout=timeout)
        if r.status_code==200:
            e=r.json().get("entry",[{}])[0]
            accs=[a.get("name","") for a in e.get("accounts",[])]
            return {"Plateforme":"Gravatar","Trouve":"✅ Oui","Details":e.get("displayName","Profil")+(f" | {', '.join(accs)}" if accs else ""),"Methode":"Hash MD5"}
    except: pass
    return {"Plateforme":"Gravatar","Trouve":"❌ Non","Details":"","Methode":"Hash MD5"}
def _gravatar_avatar(email,timeout):
    h=hashlib.md5(email.lower().strip().encode()).hexdigest()
    try:
        r=requests.head(f"https://www.gravatar.com/avatar/{h}?d=404",headers=H,timeout=timeout)
        if r.status_code==200:
            return {"Plateforme":"Gravatar Avatar","Trouve":"✅ Oui","Details":f"https://www.gravatar.com/avatar/{h}","Methode":"Avatar direct"}
    except: pass
    return {"Plateforme":"Gravatar Avatar","Trouve":"❌ Non","Details":"","Methode":"Avatar direct"}
def _github(email,timeout):
    try:
        r=requests.get("https://api.github.com/search/users",params={"q":f"{email} in:email"},headers={**H,"Accept":"application/vnd.github.v3+json"},timeout=timeout)
        if r.status_code==200:
            d=r.json(); items=d.get("items",[])
            if d.get("total_count",0)>0 and items:
                return {"Plateforme":"GitHub","Trouve":"✅ Oui","Details":f"@{items[0].get('login','')}","Methode":"API publique"}
    except: pass
    return {"Plateforme":"GitHub","Trouve":"❌ Non","Details":"","Methode":"API publique"}
def _firefox(email,timeout):
    try:
        r=requests.post("https://api.accounts.firefox.com/v1/account/check",json={"email":email},headers={**H,"Content-Type":"application/json"},timeout=timeout)
        if r.status_code==200: return {"Plateforme":"Firefox Accounts","Trouve":"✅ Oui","Details":"Compte Mozilla Firefox","Methode":"API officielle"}
        if r.status_code==400: return {"Plateforme":"Firefox Accounts","Trouve":"❌ Non","Details":"","Methode":"API officielle"}
    except: pass
    return {"Plateforme":"Firefox Accounts","Trouve":"⚫ Erreur","Details":"","Methode":"API officielle"}
def _protonmail(email,timeout):
    local=email.split("@")[0]
    try:
        r=requests.get(f"https://api.protonmail.ch/pks/lookup?op=index&search={email}",headers=H,timeout=timeout)
        if r.status_code==200 and local.lower() in r.text.lower():
            return {"Plateforme":"ProtonMail","Trouve":"✅ Oui","Details":"Cle PGP publique trouvee","Methode":"PGP keyserver"}
    except: pass
    return {"Plateforme":"ProtonMail","Trouve":"❌ Non","Details":"","Methode":"PGP keyserver"}
def _twitter(email,timeout):
    try:
        r=requests.get("https://api.twitter.com/i/users/email_available.json",params={"email":email},headers=H,timeout=timeout)
        if r.status_code==200:
            if not r.json().get("valid",True):
                return {"Plateforme":"Twitter/X","Trouve":"✅ Oui","Details":"Email enregistre","Methode":"Endpoint public"}
            return {"Plateforme":"Twitter/X","Trouve":"❌ Non","Details":"","Methode":"Endpoint public"}
    except: pass
    return {"Plateforme":"Twitter/X","Trouve":"⚫ Erreur","Details":"","Methode":"Endpoint public"}
def _spotify(email,timeout):
    try:
        r=requests.get("https://spclient.wg.spotify.com/signup/public/v1/account",params={"validate":1,"email":email},headers=H,timeout=timeout)
        if r.status_code==200 and r.json().get("status")==20:
            return {"Plateforme":"Spotify","Trouve":"✅ Oui","Details":"Email enregistre","Methode":"API Signup"}
    except: pass
    return {"Plateforme":"Spotify","Trouve":"❌ Non","Details":"","Methode":"API Signup"}
def _lastpass(email,timeout):
    try:
        r=requests.get("https://lastpass.com/create_account.php",params={"check":"avail","skipcontent":1,"mistype":1,"username":email},headers=H,timeout=timeout)
        if r.status_code==200 and r.text.strip()=="0":
            return {"Plateforme":"LastPass","Trouve":"✅ Oui","Details":"Email enregistre","Methode":"Register check"}
    except: pass
    return {"Plateforme":"LastPass","Trouve":"❌ Non","Details":"","Methode":"Register check"}
def _wordpress(email,timeout):
    try:
        r=requests.post("https://public-api.wordpress.com/rest/v1.1/users/new",data={"email":email,"user_email":email,"flow":"signup"},headers=H,timeout=timeout)
        if r.status_code in(400,422) and any(w in r.text.lower() for w in ("already","taken","exists")):
            return {"Plateforme":"WordPress.com","Trouve":"✅ Oui","Details":"Email enregistre","Methode":"Fingerprint"}
    except: pass
    return {"Plateforme":"WordPress.com","Trouve":"❌ Non","Details":"","Methode":"Fingerprint"}
def _breach_directory(email,timeout):
    try:
        r=requests.get("https://breachdirectory.org/api",params={"func":"auto","term":email},headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            if d.get("success") and d.get("result"):
                return {"Plateforme":"BreachDirectory","Trouve":"✅ Oui","Details":f"{len(d['result'])} entrees dans des fuites","Methode":"API publique"}
    except: pass
    return {"Plateforme":"BreachDirectory","Trouve":"❌ Non","Details":"","Methode":"API publique"}
def _adobe(email,timeout):
    try:
        r=requests.post("https://auth.services.adobe.com/en_US/index.html",data={"email":email,"client_id":"AdobeID"},headers=H,timeout=timeout)
        if any(w in r.text.lower() for w in("already","taken","sign in")):
            return {"Plateforme":"Adobe","Trouve":"✅ Oui","Details":"Email enregistre Adobe","Methode":"Fingerprint"}
    except: pass
    return {"Plateforme":"Adobe","Trouve":"❌ Non","Details":"","Methode":"Fingerprint"}
def _jetbrains(email,timeout):
    try:
        r=requests.post("https://account.jetbrains.com/v1/auth/check",json={"email":email},headers={**H,"Content-Type":"application/json"},timeout=timeout)
        if r.status_code==200 and "exists" in r.text.lower():
            return {"Plateforme":"JetBrains","Trouve":"✅ Oui","Details":"Compte JetBrains","Methode":"Fingerprint"}
    except: pass
    return {"Plateforme":"JetBrains","Trouve":"❌ Non","Details":"","Methode":"Fingerprint"}
CHECKERS=[_gravatar,_gravatar_avatar,_github,_firefox,_protonmail,_twitter,_spotify,_lastpass,_wordpress,_breach_directory,_adobe,_jetbrains]
def run(email,timeout=10,progress_callback=None):
    results=[]; done=0
    with ThreadPoolExecutor(max_workers=len(CHECKERS)) as ex:
        futures={ex.submit(fn,email,timeout):fn.__name__ for fn in CHECKERS}
        for fut in as_completed(futures):
            done+=1; res=fut.result(); results.append(res)
            if progress_callback:
                try: progress_callback(done,len(CHECKERS),res)
                except: pass
    results.sort(key=lambda x:(0 if x["Trouve"]=="✅ Oui" else 1,x["Plateforme"]))
    return results
