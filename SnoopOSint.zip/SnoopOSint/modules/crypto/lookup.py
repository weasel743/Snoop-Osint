import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(address,timeout=10):
    results=[]
    addr=address.strip()
    is_eth=addr.startswith("0x") and len(addr)==42
    is_btc=not is_eth and len(addr) in(25,26,27,28,29,30,31,32,33,34,35)
    if is_btc:
        try:
            r=requests.get(f"https://blockchain.info/rawaddr/{addr}",headers=H,timeout=timeout)
            if r.status_code==200:
                d=r.json()
                results+=[
                    {"Champ":"Type","Valeur":"Bitcoin (BTC)","Source":"Blockchain.info"},
                    {"Champ":"Adresse","Valeur":addr,"Source":"Blockchain.info"},
                    {"Champ":"Balance","Valeur":f"{d.get('final_balance',0)/1e8:.8f} BTC","Source":"Blockchain.info"},
                    {"Champ":"Total recu","Valeur":f"{d.get('total_received',0)/1e8:.8f} BTC","Source":"Blockchain.info"},
                    {"Champ":"Total envoye","Valeur":f"{d.get('total_sent',0)/1e8:.8f} BTC","Source":"Blockchain.info"},
                    {"Champ":"Nb transactions","Valeur":str(d.get("n_tx",0)),"Source":"Blockchain.info"},
                ]
                for tx in d.get("txs",[])[:3]:
                    results.append({"Champ":"Transaction","Valeur":f"Hash: {tx.get('hash','')[:20]}... | {tx.get('result',0)/1e8:.8f} BTC","Source":"Blockchain.info"})
            elif r.status_code==500:
                results.append({"Champ":"Info","Valeur":"Adresse BTC invalide ou inconnue","Source":"Blockchain.info"})
        except Exception as e: results.append({"Champ":"Erreur BTC","Valeur":str(e),"Source":""})
        try:
            r2=requests.get(f"https://api.blockcypher.com/v1/btc/main/addrs/{addr}/balance",headers=H,timeout=timeout)
            if r2.status_code==200:
                d2=r2.json()
                results.append({"Champ":"[BlockCypher] Balance","Valeur":f"{d2.get('final_balance',0)/1e8:.8f} BTC","Source":"BlockCypher"})
                results.append({"Champ":"[BlockCypher] Transactions","Valeur":str(d2.get("n_tx",0)),"Source":"BlockCypher"})
        except: pass
    elif is_eth:
        try:
            r=requests.get("https://api.etherscan.io/api",params={"module":"account","action":"balance","address":addr,"tag":"latest"},headers=H,timeout=timeout)
            if r.status_code==200:
                d=r.json()
                bal=int(d.get("result",0))/1e18 if d.get("status")=="1" else 0
                results+=[
                    {"Champ":"Type","Valeur":"Ethereum (ETH)","Source":"Etherscan"},
                    {"Champ":"Adresse","Valeur":addr,"Source":"Etherscan"},
                    {"Champ":"Balance","Valeur":f"{bal:.6f} ETH","Source":"Etherscan"},
                ]
            r2=requests.get("https://api.etherscan.io/api",params={"module":"account","action":"txlist","address":addr,"page":1,"offset":5,"sort":"desc"},headers=H,timeout=timeout)
            if r2.status_code==200:
                d2=r2.json()
                txs=d2.get("result",[])
                results.append({"Champ":"Nb transactions","Valeur":str(len(txs)) if isinstance(txs,list) else "0","Source":"Etherscan"})
                if isinstance(txs,list):
                    for tx in txs[:3]:
                        results.append({"Champ":"Transaction","Valeur":f"Hash: {tx.get('hash','')[:20]}... | {int(tx.get('value',0))/1e18:.4f} ETH","Source":"Etherscan"})
        except Exception as e: results.append({"Champ":"Erreur ETH","Valeur":str(e),"Source":""})
    else:
        results.append({"Champ":"Info","Valeur":"Adresse crypto non reconnue. Formats: BTC (25-35 chars) ou ETH (0x + 40 chars hex)","Source":""})
    return results or [{"Champ":"Info","Valeur":"Aucun resultat","Source":""}]
