import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
H = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36","Accept":"text/html,application/xhtml+xml,*/*;q=0.8","Accept-Language":"fr-FR,fr;q=0.9"}
SITES = [
    {"name":"GitHub","url":"https://api.github.com/users/{}","check":"json","key":"login"},
    {"name":"Reddit","url":"https://www.reddit.com/user/{}/about.json","check":"json","key":"name"},
    {"name":"Dev.to","url":"https://dev.to/api/users/by_username?url={}","check":"json","key":"username"},
    {"name":"GitLab","url":"https://gitlab.com/{}","check":"absent","bad":"Page Not Found"},
    {"name":"Bitbucket","url":"https://bitbucket.org/{}","check":"absent","bad":"this user has no repositories"},
    {"name":"HackerNews","url":"https://news.ycombinator.com/user?id={}","check":"present","good":"<td>user:</td>"},
    {"name":"Steam","url":"https://steamcommunity.com/id/{}/","check":"absent","bad":"The specified profile could not be found"},
    {"name":"TikTok","url":"https://www.tiktok.com/@{}","check":"present","good":'"uniqueId"'},
    {"name":"Twitch","url":"https://www.twitch.tv/{}","check":"present","good":'"login"'},
    {"name":"Pinterest","url":"https://www.pinterest.com/{}/","check":"absent","bad":"Page Not Found"},
    {"name":"Telegram","url":"https://t.me/{}","check":"present","good":"tgme_page_title"},
    {"name":"Medium","url":"https://medium.com/@{}","check":"absent","bad":"Page not found"},
    {"name":"Last.fm","url":"https://www.last.fm/user/{}","check":"absent","bad":"User not found"},
    {"name":"Vimeo","url":"https://vimeo.com/{}","check":"absent","bad":"Page not found"},
    {"name":"SoundCloud","url":"https://soundcloud.com/{}","check":"absent","bad":"doesn't exist"},
    {"name":"Flickr","url":"https://www.flickr.com/people/{}/","check":"absent","bad":"Page Not Found"},
    {"name":"Dribbble","url":"https://dribbble.com/{}","check":"absent","bad":"page is gone"},
    {"name":"Behance","url":"https://www.behance.net/{}","check":"absent","bad":"can't find"},
    {"name":"Ko-fi","url":"https://ko-fi.com/{}","check":"status"},
    {"name":"Pastebin","url":"https://pastebin.com/u/{}","check":"absent","bad":"Not Found"},
    {"name":"ProductHunt","url":"https://www.producthunt.com/@{}","check":"absent","bad":"not found"},
    {"name":"Fiverr","url":"https://www.fiverr.com/{}","check":"absent","bad":"Page Not Found"},
    {"name":"Letterboxd","url":"https://letterboxd.com/{}","check":"absent","bad":"Sorry"},
    {"name":"Imgur","url":"https://imgur.com/user/{}","check":"absent","bad":"Page not found"},
    {"name":"VK","url":"https://vk.com/{}","check":"absent","bad":"Page not found"},
    {"name":"Bluesky","url":"https://bsky.app/profile/{}","check":"absent","bad":"not found"},
    {"name":"DockerHub","url":"https://hub.docker.com/u/{}","check":"status"},
    {"name":"PyPI","url":"https://pypi.org/user/{}/","check":"absent","bad":"404"},
    {"name":"Gravatar","url":"https://en.gravatar.com/{}","check":"absent","bad":"does not exist"},
    {"name":"Codeberg","url":"https://codeberg.org/{}","check":"absent","bad":"Not Found"},
    {"name":"TryHackMe","url":"https://tryhackme.com/p/{}","check":"absent","bad":"404"},
    {"name":"Codeforces","url":"https://codeforces.com/profile/{}","check":"absent","bad":"not found"},
    {"name":"LeetCode","url":"https://leetcode.com/{}","check":"absent","bad":"doesn't exist"},
    {"name":"Quora","url":"https://www.quora.com/profile/{}","check":"absent","bad":"Page Not Found"},
    {"name":"Itch.io","url":"https://itch.io/profile/{}","check":"absent","bad":"not found"},
    {"name":"Replit","url":"https://replit.com/@{}","check":"absent","bad":"404"},
    {"name":"Codepen","url":"https://codepen.io/{}","check":"absent","bad":"404"},
    {"name":"About.me","url":"https://about.me/{}","check":"absent","bad":"404"},
    {"name":"Bandcamp","url":"https://bandcamp.com/{}","check":"absent","bad":"404"},
    {"name":"Mastodon","url":"https://mastodon.social/@{}","check":"absent","bad":"doesn't exist"},
    {"name":"Wattpad","url":"https://www.wattpad.com/user/{}","check":"absent","bad":"Uh oh"},
    {"name":"Disqus","url":"https://disqus.com/by/{}/","check":"absent","bad":"Page Not Found"},
    {"name":"500px","url":"https://500px.com/p/{}","check":"absent","bad":"404"},
    {"name":"AngelList","url":"https://angel.co/u/{}","check":"absent","bad":"404"},
    {"name":"Mixcloud","url":"https://www.mixcloud.com/{}/","check":"absent","bad":"404"},
    {"name":"Thingiverse","url":"https://www.thingiverse.com/{}","check":"absent","bad":"404"},
    {"name":"SpeakerDeck","url":"https://speakerdeck.com/{}","check":"absent","bad":"404"},
    {"name":"Instructables","url":"https://www.instructables.com/member/{}","check":"absent","bad":"not found"},
    {"name":"Keybase","url":"https://keybase.io/{}","check":"absent","bad":"404"},
    {"name":"Academia.edu","url":"https://independent.academia.edu/{}","check":"absent","bad":"404"},
    {"name":"Hackernoon","url":"https://hackernoon.com/u/{}","check":"absent","bad":"404"},
    {"name":"NPM","url":"https://www.npmjs.com/~{}","check":"absent","bad":"404"},
    {"name":"Freelancer","url":"https://www.freelancer.com/u/{}","check":"absent","bad":"404"},
    {"name":"Sourcehut","url":"https://sr.ht/~{}","check":"absent","bad":"Not found"},
]
def _check(username, site, timeout):
    url = site["url"].format(username)
    check = site.get("check","status")
    try:
        r = requests.get(url, headers=H, timeout=timeout, allow_redirects=True)
        if check == "json":
            if r.status_code == 404: return _res(site,url,False,404)
            if r.status_code == 200:
                try:
                    found = site["key"] in str(r.json())
                    return _res(site,url,found,r.status_code)
                except: pass
            return _res(site,url,False,r.status_code)
        elif check == "present":
            if r.status_code == 404: return _res(site,url,False,404)
            found = site.get("good","") in r.text
            return _res(site,url,found,r.status_code)
        elif check == "absent":
            if r.status_code == 404: return _res(site,url,False,404)
            bad = site.get("bad","")
            found = r.status_code == 200 and bad.lower() not in r.text.lower()
            return _res(site,url,found,r.status_code)
        else:
            return _res(site,url,r.status_code==200,r.status_code)
    except requests.exceptions.Timeout: return _res(site,url,False,0,"Timeout")
    except Exception as e: return _res(site,url,False,0,str(e)[:40])
def _res(site,url,found,code,err=""):
    return {"Plateforme":site["name"],"URL":url,
            "Statut":"✅ Trouve" if found else ("⚫ Erreur" if err else "❌ Non trouve"),
            "Code":str(code),"Erreur":err}
def run(username, timeout=10, max_workers=30, progress_callback=None):
    results=[]; done=0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures={ex.submit(_check,username,s,timeout):s for s in SITES}
        for fut in as_completed(futures):
            done+=1; res=fut.result(); results.append(res)
            if progress_callback:
                try: progress_callback(done,len(SITES),res)
                except: pass
    results.sort(key=lambda x:(0 if "Trouve" in x["Statut"] and "Non" not in x["Statut"] else 1,x["Plateforme"]))
    return results
