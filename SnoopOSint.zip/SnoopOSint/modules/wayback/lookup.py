import requests
H={"User-Agent":"SnoopOSINT/1.0"}
def run(url,timeout=15):
    results=[]
    clean=url.replace("https://","").replace("http://","").split("/")[0].strip()
    try:
        r=requests.get("http://archive.org/wayback/available",params={"url":clean},headers=H,timeout=timeout)
        if r.status_code==200:
            snap=r.json().get("archived_snapshots",{}).get("closest",{})
            if snap:
                results.append({"Champ":"Dernier snapshot","Valeur":snap.get("timestamp","")[:8],"Source":"Wayback Machine"})
                results.append({"Champ":"URL snapshot","Valeur":snap.get("url",""),"Source":"Wayback Machine"})
                results.append({"Champ":"Statut","Valeur":snap.get("status",""),"Source":"Wayback Machine"})
            else:
                results.append({"Champ":"Info","Valeur":"Aucun snapshot disponible","Source":"Wayback Machine"})
    except Exception as e:
        results.append({"Champ":"Erreur","Valeur":str(e),"Source":""})
    try:
        r2=requests.get("http://web.archive.org/cdx/search/cdx",
            params={"url":clean,"output":"json","limit":20,"fl":"timestamp,statuscode,mimetype","collapse":"timestamp:6","from":"2000","to":"2030"},
            headers=H,timeout=timeout)
        if r2.status_code==200:
            lines=r2.json()
            if len(lines)>1:
                results.append({"Champ":"Snapshots trouves","Valeur":str(len(lines)-1),"Source":"CDX API"})
                for line in lines[1:6]:
                    ts,code,mime=line
                    results.append({"Champ":f"Snapshot {ts[:6]}","Valeur":f"HTTP {code} | {mime} | https://web.archive.org/web/{ts}/{clean}","Source":"CDX API"})
    except: pass
    return results or [{"Champ":"Info","Valeur":"Aucun resultat Wayback Machine","Source":""}]
