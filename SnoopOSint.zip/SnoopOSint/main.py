#!/usr/bin/env python3
"""
⚡ Snoop OSINT v1.0.0
Outil OSINT open source avec corrélation automatique et sources françaises officielles
"""
import sys
import os

# Ensure the project root is in Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    try:
        from PyQt6.QtWidgets import QApplication, QSplashScreen
        from PyQt6.QtCore import Qt, QTimer
        from PyQt6.QtGui import QColor, QPixmap, QPainter, QFont
    except ImportError:
        print("ERREUR: PyQt6 n'est pas installé.")
        print("Installez-le avec: pip install PyQt6")
        input("Appuyez sur Entrée pour quitter...")
        sys.exit(1)

    app = QApplication(sys.argv)
    app.setApplicationName("Snoop OSINT")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("SnoopOSINT")

    # Splash screen
    splash_px = QPixmap(500, 280)
    splash_px.fill(QColor("#0A0E17"))
    p = QPainter(splash_px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    # Background gradient effect
    p.fillRect(0, 0, 500, 4, QColor("#7C3AED"))
    f = QFont("Segoe UI", 32); f.setBold(True); p.setFont(f)
    p.setPen(QColor("#7C3AED"))
    p.drawText(splash_px.rect().adjusted(0,-40,0,0), Qt.AlignmentFlag.AlignCenter, "⚡ Snoop OSINT")
    f2 = QFont("Segoe UI", 11); p.setFont(f2); p.setPen(QColor("#A78BFA"))
    p.drawText(splash_px.rect().adjusted(0,30,0,0), Qt.AlignmentFlag.AlignCenter, "v1.0.0")
    f3 = QFont("Segoe UI", 9); p.setFont(f3); p.setPen(QColor("#4A5C70"))
    p.drawText(splash_px.rect().adjusted(0,80,0,0), Qt.AlignmentFlag.AlignCenter, "Corrélation automatique • Sources françaises • 0 clef API")
    p.end()
    splash = QSplashScreen(splash_px, Qt.WindowType.WindowStaysOnTopHint)
    splash.show(); app.processEvents()

    # Apply theme
    try:
        from core.theme_manager import ThemeManager
        from core.config_manager import ConfigManager
        cfg = ConfigManager()
        tm = ThemeManager()
        tm.apply(app)
    except Exception as e:
        print(f"Avertissement thème: {e}")

    # Load main window
    try:
        from ui.main_window import MainWindow
        window = MainWindow(app)
    except Exception as e:
        import traceback; traceback.print_exc()
        print(f"ERREUR lors du chargement: {e}")
        splash.close()
        input("Appuyez sur Entrée pour quitter...")
        sys.exit(1)

    # Show window after splash
    def show_main():
        splash.finish(window)
        window.show()
        window.raise_()

    QTimer.singleShot(1200, show_main)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
