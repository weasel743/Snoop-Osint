from core.config_manager import ConfigManager
class ThemeManager:
    def __init__(self): self.cfg = ConfigManager()
    def apply(self,app,name=None):
        name = name or self.cfg.get("app","theme",default="violet")
        t = self.cfg.get_theme(name)
        app.setStyleSheet(self._qss(t))
        self.cfg.set(name,"app","theme"); self.cfg.save()
    def _qss(self,t):
        a=t.get("accent","#7C3AED"); ah=t.get("accent_hover","#6D28D9"); al=t.get("accent_light","#A78BFA")
        bg=t.get("bg_primary","#0A0E17"); bg2=t.get("bg_secondary","#0D1726"); bd=t.get("border","#1A2A44")
        tx=t.get("text_primary","#EEF3FC"); tx2=t.get("text_secondary","#8AA0B8")
        s=t.get("success","#34D399"); w=t.get("warning","#FBBF24"); d=t.get("danger","#F87171")
        return f"""
QWidget{{background:{bg};color:{tx};font-family:'Segoe UI',Arial;font-size:10pt;border:none;outline:none}}
QMainWindow,QDialog{{background:{bg}}}
QPushButton{{background:{a};color:white;border:none;border-radius:6px;padding:6px 16px;font-weight:bold;min-height:28px}}
QPushButton:hover{{background:{ah}}}
QPushButton:pressed{{background:{ah}}}
QPushButton:disabled{{background:{bd};color:{tx2}}}
QPushButton#secondary{{background:{bg2};color:{tx2};border:1px solid {bd}}}
QPushButton#secondary:hover{{background:{bg};color:{tx};border-color:{a}}}
QLineEdit,QTextEdit,QPlainTextEdit{{background:{bg2};color:{tx};border:1px solid {bd};border-radius:6px;padding:5px 10px}}
QLineEdit:focus,QTextEdit:focus,QPlainTextEdit:focus{{border:1px solid {a}}}
QTableWidget{{background:{bg2};color:{tx};border:1px solid {bd};border-radius:6px;gridline-color:{bd};selection-background-color:{a}33}}
QTableWidget::item{{padding:4px 8px}}
QTableWidget::item:hover{{background:{a}22}}
QTableWidget::item:selected{{background:{a}44;color:{tx}}}
QHeaderView::section{{background:{bg};color:{tx2};border:none;border-bottom:1px solid {bd};padding:6px 10px;font-weight:bold;font-size:9pt}}
QScrollBar:vertical{{background:{bg};width:7px;border-radius:3px}}
QScrollBar::handle:vertical{{background:{bd};border-radius:3px;min-height:20px}}
QScrollBar::handle:vertical:hover{{background:{a}}}
QScrollBar:horizontal{{background:{bg};height:7px;border-radius:3px}}
QScrollBar::handle:horizontal{{background:{bd};border-radius:3px}}
QScrollBar::handle:horizontal:hover{{background:{a}}}
QScrollBar::add-line,QScrollBar::sub-line{{width:0;height:0}}
QComboBox{{background:{bg2};color:{tx};border:1px solid {bd};border-radius:6px;padding:5px 10px}}
QComboBox:hover{{border:1px solid {a}}}
QComboBox::drop-down{{border:none;width:20px}}
QComboBox QAbstractItemView{{background:{bg2};color:{tx};border:1px solid {bd};selection-background-color:{a}}}
QGroupBox{{border:1px solid {bd};border-radius:6px;margin-top:10px;padding-top:10px;color:{al};font-size:9pt;font-weight:bold}}
QGroupBox::title{{subcontrol-origin:margin;padding:0 6px;background:{bg};color:{al}}}
QCheckBox{{color:{tx};spacing:6px}}
QCheckBox::indicator{{width:16px;height:16px;border:1px solid {bd};border-radius:3px;background:{bg2}}}
QCheckBox::indicator:checked{{background:{a};border:1px solid {a}}}
QSlider::groove:horizontal{{background:{bd};height:4px;border-radius:2px}}
QSlider::handle:horizontal{{background:{a};width:14px;height:14px;border-radius:7px;margin:-5px 0}}
QSlider::sub-page:horizontal{{background:{a};border-radius:2px}}
QSpinBox{{background:{bg2};color:{tx};border:1px solid {bd};border-radius:6px;padding:4px 8px}}
QProgressBar{{background:{bd};border-radius:4px;border:none;text-align:center;color:{tx}}}
QProgressBar::chunk{{background:{a};border-radius:4px}}
QScrollArea{{border:none;background:transparent}}
QSplitter::handle{{background:{bd}}}
QToolTip{{background:{bg2};color:{tx};border:1px solid {a};border-radius:4px;padding:4px 8px}}
QLabel{{background:transparent;color:{tx}}}
QLabel#accent{{color:{al};font-weight:bold}}
QLabel#success{{color:{s}}}
QLabel#warning{{color:{w}}}
QLabel#danger{{color:{d}}}
QLabel#secondary{{color:{tx2}}}
"""
