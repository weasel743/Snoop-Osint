import sqlite3, json, os
from datetime import datetime
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
class Database:
    _instance = None
    def __new__(cls):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            cls._instance._init = False
        return cls._instance
    def __init__(self):
        if not self._init:
            p = os.path.join(BASE_DIR,"data","snoop.db")
            os.makedirs(os.path.dirname(p),exist_ok=True)
            self.conn = sqlite3.connect(p,check_same_thread=False)
            self.conn.row_factory = sqlite3.Row
            self._create(); self._init = True
    def _create(self):
        self.conn.executescript("""
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY AUTOINCREMENT,module TEXT,query TEXT,results TEXT,result_count INTEGER DEFAULT 0,timestamp TEXT);
        CREATE TABLE IF NOT EXISTS graph_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,seed TEXT,nodes TEXT,edges TEXT,timestamp TEXT,summary TEXT);
        CREATE INDEX IF NOT EXISTS idx_hist ON history(timestamp);
        """); self.conn.commit()
    def save_result(self,module,query,results):
        self.conn.execute("INSERT INTO history(module,query,results,result_count,timestamp) VALUES(?,?,?,?,?)",
            (module,query,json.dumps(results,ensure_ascii=False),len(results) if isinstance(results,list) else 1,
             datetime.now().strftime("%Y-%m-%d %H:%M:%S"))); self.conn.commit()
    def save_graph(self,seed,nodes,edges,summary=""):
        self.conn.execute("INSERT INTO graph_sessions(seed,nodes,edges,timestamp,summary) VALUES(?,?,?,?,?)",
            (seed,json.dumps(nodes,ensure_ascii=False),json.dumps(edges,ensure_ascii=False),
             datetime.now().strftime("%Y-%m-%d %H:%M:%S"),summary)); self.conn.commit()
    def get_history(self,limit=500,module=None):
        if module: rows=self.conn.execute("SELECT * FROM history WHERE module=? ORDER BY timestamp DESC LIMIT ?",(module,limit)).fetchall()
        else: rows=self.conn.execute("SELECT * FROM history ORDER BY timestamp DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]
    def get_graphs(self,limit=50):
        rows=self.conn.execute("SELECT id,seed,timestamp,summary FROM graph_sessions ORDER BY timestamp DESC LIMIT ?",(limit,)).fetchall()
        return [dict(r) for r in rows]
    def get_graph(self,gid):
        row=self.conn.execute("SELECT * FROM graph_sessions WHERE id=?",(gid,)).fetchone()
        if row:
            d=dict(row); d["nodes"]=json.loads(d["nodes"]); d["edges"]=json.loads(d["edges"]); return d
        return None
    def clear_history(self): self.conn.execute("DELETE FROM history"); self.conn.commit()
    def get_stats(self):
        total=self.conn.execute("SELECT COUNT(*) as c FROM history").fetchone()["c"]
        by_mod=self.conn.execute("SELECT module,COUNT(*) as c FROM history GROUP BY module ORDER BY c DESC").fetchall()
        graphs=self.conn.execute("SELECT COUNT(*) as c FROM graph_sessions").fetchone()["c"]
        return {"total":total,"by_module":[dict(r) for r in by_mod],"graphs":graphs}
