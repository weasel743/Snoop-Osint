import json, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
class ConfigManager:
    _instance = None
    def __new__(cls):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
        return cls._instance
    def __init__(self):
        if not self._loaded:
            self.config = {}; self.themes = {}
            self._load(); self._loaded = True
    def _load(self):
        try:
            with open(os.path.join(BASE_DIR,"config","settings.json"),encoding="utf-8") as f:
                self.config = json.load(f)
        except: self.config = self._defaults()
        try:
            with open(os.path.join(BASE_DIR,"config","themes.json"),encoding="utf-8") as f:
                self.themes = json.load(f)
        except: self.themes = {}
    def save(self):
        p = os.path.join(BASE_DIR,"config","settings.json")
        with open(p,"w",encoding="utf-8") as f:
            json.dump(self.config,f,indent=2,ensure_ascii=False)
    def get(self,*keys,default=None):
        d = self.config
        for k in keys:
            if isinstance(d,dict) and k in d: d=d[k]
            else: return default
        return d
    def set(self,value,*keys):
        d = self.config
        for k in keys[:-1]: d=d.setdefault(k,{})
        d[keys[-1]] = value
    def get_theme(self,name=None):
        name = name or self.get("app","theme",default="violet")
        return self.themes.get(name,self.themes.get("violet",{}))
    def get_language(self): return self.get("app","language",default="fr")
    def get_timeout(self): return self.get("search","timeout",default=15)
    def get_proxy(self):
        p = self.get("proxy",default={})
        if p.get("enabled"): return {k:p[k] for k in ("http","https") if p.get(k)}
        return {}
    def _defaults(self):
        return {"app":{"version":"1.0.0","language":"fr","theme":"violet"},
                "ui":{"window":{"width":1400,"height":850,"maximized":False},
                      "animation":{"enabled":True,"type":"lightning","speed":1.0,"intensity":0.7},
                      "font_size":10,"toast_notifications":True},
                "search":{"timeout":15,"max_threads":50,"auto_save_history":True},
                "correlation":{"max_depth":3,"max_nodes":60},
                "proxy":{"enabled":False,"http":"","https":""},
                "api_keys":{"shodan":"","hibp":"","virustotal":""}}
