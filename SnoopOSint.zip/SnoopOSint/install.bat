@echo off
chcp 65001 >nul 2>&1
title Snoop OSINT v1.0.0 - Installation
echo.
echo  Snoop OSINT v1.0.0 - Installation
echo  ====================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERREUR] Python n'est pas installe ou pas dans le PATH.
    echo  Telechargez Python 3.10+ sur https://python.org
    echo  IMPORTANT: Cochez "Add Python to PATH" lors de l'installation.
    echo.
    pause
    exit /b 1
)

echo  Python detecte :
python --version
echo.
echo  Installation des dependances...
echo.

pip install PyQt6 --quiet
pip install requests --quiet
pip install phonenumbers --quiet
pip install python-whois --quiet
pip install dnspython --quiet
pip install Pillow --quiet
pip install beautifulsoup4 --quiet
pip install lxml --quiet
pip install reportlab --quiet
pip install exifread --quiet

echo.
echo  Installation terminee !
echo  Lancez l'application avec start.bat
echo.
pause
