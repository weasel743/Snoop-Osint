# ⚡ Snoop OSINT v1.0.0

> **L'outil OSINT open source le plus complet pour Windows — Corrélation automatique, Sources françaises officielles, 0 clef API requise**

---

## 🚀 Installation rapide

```bash
# 1. Téléchargez et extrayez l'archive
# 2. Double-cliquez sur install.bat
# 3. Double-cliquez sur start.bat
```

**Ou manuellement :**
```bash
pip install PyQt6 requests phonenumbers python-whois dnspython Pillow beautifulsoup4 lxml reportlab exifread
python main.py
```

---

## 🧩 Modules (27 onglets)

### Recherche principale
| Module | Description |
|--------|------------|
| 🔗 Corrélation | Exploration automatique en profondeur email→domain→ip→github |
| 👤 Username | 54+ plateformes — GitHub, Reddit, TikTok, Telegram, Steam... |
| 📧 Email | 12 checkers — Gravatar, GitHub, Firefox, ProtonMail, Spotify... |
| 📱 Téléphone | Décodage complet — pays, opérateur, type, fuseau |
| 🌐 Adresse IP | ip-api + ipinfo + Shodan InternetDB + ARIN RDAP |
| 🏠 Domaine | WHOIS + DNS + SSL/crt.sh + Sous-domaines |

### Analyse
| Module | Description |
|--------|------------|
| 🖼️ Image EXIF | GPS, appareil, dates, coordonnées Google Maps |
| 📄 Métadonnées | PDF, DOCX, XLSX, images |
| 🐙 GitHub | Profil, repos, emails commits, orgs, langages |
| ₿ Crypto | Bitcoin (blockchain.info + BlockCypher) + Ethereum (Etherscan) |
| 🌍 Géolocalisation | Triple source IP — carte directe |

### Avancé
| Module | Description |
|--------|------------|
| 🔓 Fuites | BreachDirectory + HIBP k-anonymity |
| 📋 Paste Sites | psbdmp.ws + pastes.io |
| 🕰️ Wayback Machine | Snapshots + CDX API historique |
| 🔌 Port Scanner | 20 ports courants, banner grabbing, parallèle |
| 🔍 Dorking | 12 dorks Google/DuckDuckGo générés automatiquement |
| 🛡️ Shodan | InternetDB gratuit — ports, CVE, hostnames |

### 🇫🇷 France (exclusif)
| Module | Description |
|--------|------------|
| 🏛️ BODACC | Entreprises françaises officielles + opendatasoft |
| 📋 Infogreffe | Dirigeants + formes juridiques via data.gouv.fr |
| 📒 Pages Jaunes | Annuaire professionnel — scraping |
| 🇫🇷 Data.gouv.fr | Datasets ouverts + RNA associations |

### Outils
| Module | Description |
|--------|------------|
| 🕸️ Graphe | Force-directed, drag, zoom, sauvegarde en BDD |
| 📅 Timeline | Historique groupé par date |
| 📦 Batch | Multi-cibles, tous modules |
| 📋 Historique | Filtre, export, effacement |
| ⚙️ Paramètres | Thèmes, langue, timeout, clefs API |

---

## 🎨 Thèmes
7 thèmes intégrés: violet, blue, green, cyan, gold, matrix, light

## 🌐 Langues
Français et English (extensible)

## 📤 Exports
CSV · JSON · PDF · HTML pour chaque module

---

## 🏗️ Structure

```
SnoopOSINT/
├── main.py              # Point d'entrée
├── install.bat          # Installation Windows
├── start.bat            # Lancement Windows
├── config/              # settings.json, themes.json, langues
├── core/                # ConfigManager, Database, ThemeManager...
├── modules/             # 18 modules OSINT
│   ├── username/        # 54+ plateformes
│   ├── email/           # 12 checkers
│   ├── france/          # BODACC, Infogreffe, Pages Jaunes, Data.gouv
│   ├── correlation/     # Moteur de corrélation QThread
│   └── ...
├── ui/
│   ├── main_window.py   # Fenêtre principale
│   ├── views/           # 27 vues
│   ├── widgets/         # SnoopTable, Toast, ProgressRing
│   └── animations/      # Lightning, Particles
└── plugins/             # example_plugin.py — extensible
```

---

## 🔌 Créer un plugin

```python
PLUGIN_NAME = "Mon Plugin"
PLUGIN_ID   = "mon_plugin"
PLUGIN_DESC = "Description"

def run(query, timeout=10, progress_callback=None):
    # Votre logique ici
    return [{"Champ": "Valeur", "Source": "MonPlugin"}]
```

---

## 🔑 Clefs API (optionnelles)

Snoop OSINT fonctionne **sans aucune clef API**.

Clefs optionnelles pour fonctionnalités étendues :
- **Shodan** — résultats complets (vs InternetDB gratuit)
- **HIBP** — Have I Been Pwned complet
- **VirusTotal** — analyse de domaines/IPs

---

## ⚡ Caractéristiques techniques

- **PyQt6** — Interface native Windows haute performance
- **QThread** — Toutes les recherches asynchrones, UI jamais bloquée
- **SQLite** — Historique et graphes persistants
- **Force-directed graph** — Algorithme maison, déplaçable
- **54+ sites username** — Vérification HTML par site, 0 faux positif

---

**Discord:** https://discord.gg/VVpAvbE9k4 | **Version:** 1.0.0
