from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QScrollArea,QFrame
from PyQt6.QtCore import Qt,QTimer,pyqtSignal
from PyQt6.QtGui import QFont,QColor
from core.database import Database
from core.config_manager import ConfigManager

QUICK_MODULES=[
    ("🔗","Corrélation","correlation"),("👤","Username","username"),("📧","Email","email"),
    ("📱","Téléphone","phone"),("🌐","IP","ip"),("🏠","Domaine","domain"),
    ("🔓","Fuites","breach"),("📋","Paste Sites","paste"),("🕰️","Wayback","wayback"),
    ("🏛️","BODACC","bodacc"),("📋","Infogreffe","infogreffe"),("📒","Pages Jaunes","pagesjaunes"),
    ("🇫🇷","Data.gouv","datafr"),("🐙","GitHub","social"),("₿","Crypto","crypto"),
    ("🔌","Port Scan","portscan"),("🔍","Dorking","dorking"),("🛡️","Shodan","shodan"),
]

class ModuleButton(QPushButton):
    def __init__(self,icon,label,mid,parent=None):
        super().__init__(parent)
        self.setFixedSize(110,80); self.mid=mid
        self.setStyleSheet("""QPushButton{background:#0D1726;border:1px solid #1A2A44;border-radius:8px;color:#8AA0B8}
            QPushButton:hover{background:rgba(124,58,237,0.15);border:1px solid #7C3AED;color:#EEF3FC}""")
        lay=QVBoxLayout(self); lay.setAlignment(Qt.AlignmentFlag.AlignCenter); lay.setSpacing(4)
        il=QLabel(icon); il.setAlignment(Qt.AlignmentFlag.AlignCenter)
        il.setStyleSheet("font-size:22px;background:transparent;color:inherit;border:none;")
        lay.addWidget(il)
        tl=QLabel(label); tl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        tl.setStyleSheet("font-size:9px;background:transparent;color:inherit;border:none;")
        lay.addWidget(tl)

class DashboardView(QWidget):
    navigate_to = pyqtSignal(str)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.db=Database(); self.cfg=ConfigManager()
        self._build_ui()

    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(20,20,20,20); lay.setSpacing(16)

        # Titre
        title=QLabel("⚡ Snoop OSINT")
        f=QFont("Segoe UI",22); f.setBold(True); title.setFont(f)
        title.setStyleSheet("color:#7C3AED;background:transparent;")
        lay.addWidget(title)

        sub=QLabel("Corrélation automatique  •  Sources françaises officielles  •  0 clef API requise  •  v1.0.0")
        sub.setStyleSheet("color:#8AA0B8;background:transparent;font-size:11px;")
        lay.addWidget(sub)

        # Stats
        stats_w=QWidget(); stats_l=QHBoxLayout(stats_w)
        stats_l.setContentsMargins(0,0,0,0); stats_l.setSpacing(12)
        self.stat_labels={}
        for key,icon,label,color in [
            ("searches","🔍","Recherches","#7C3AED"),
            ("modules","🧩","Modules","#34D399"),
            ("keys","🔑","Clefs requises","#FBBF24"),
            ("graphs","🕸️","Graphes","#60A5FA"),
        ]:
            card=QFrame()
            card.setStyleSheet("background:#0D1726;border:1px solid #1A2A44;border-radius:8px;")
            cl=QVBoxLayout(card); cl.setContentsMargins(16,12,16,12)
            il=QLabel(icon); il.setStyleSheet("font-size:20px;background:transparent;")
            cl.addWidget(il)
            vl=QLabel("0")
            vl.setStyleSheet(f"font-size:24px;font-weight:bold;color:{color};background:transparent;")
            cl.addWidget(vl)
            ll=QLabel(label); ll.setStyleSheet("font-size:10px;color:#8AA0B8;background:transparent;")
            cl.addWidget(ll)
            self.stat_labels[key]=vl; stats_l.addWidget(card)
        self.stat_labels["modules"].setText("27")
        self.stat_labels["keys"].setText("0")
        lay.addWidget(stats_w)

        # Accès rapide
        qa_title=QLabel("🚀 Accès rapide")
        f2=QFont("Segoe UI",12); f2.setBold(True); qa_title.setFont(f2)
        qa_title.setStyleSheet("color:#EEF3FC;background:transparent;")
        lay.addWidget(qa_title)

        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFixedHeight(210)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        grid_w=QWidget(); grid=QGridLayout(grid_w)
        grid.setSpacing(8); grid.setContentsMargins(0,0,0,0)
        for i,(icon,label,mid) in enumerate(QUICK_MODULES):
            btn=ModuleButton(icon,label,mid)
            btn.clicked.connect(lambda _,m=mid: self.navigate_to.emit(m))
            grid.addWidget(btn, i//9, i%9)
        scroll.setWidget(grid_w); lay.addWidget(scroll)

        # Historique récent
        hist_title=QLabel("📋 Recherches récentes")
        hist_title.setFont(f2)
        hist_title.setStyleSheet("color:#EEF3FC;background:transparent;")
        lay.addWidget(hist_title)

        self.hist_container=QFrame()
        self.hist_container.setStyleSheet("background:#0D1726;border:1px solid #1A2A44;border-radius:8px;")
        self.hist_lay=QVBoxLayout(self.hist_container)
        self.hist_lay.setContentsMargins(0,4,0,4); self.hist_lay.setSpacing(0)

        scroll2=QScrollArea(); scroll2.setWidgetResizable(True); scroll2.setFixedHeight(180)
        scroll2.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        scroll2.setWidget(self.hist_container)
        lay.addWidget(scroll2)

        # Bannière info
        banner=QLabel(
            "✨ v1.0.0 — Corrélation automatique, Sources françaises (BODACC, Infogreffe, Pages Jaunes, "
            "Data.gouv.fr), Graphe interactif force-directed, Wayback Machine, Port Scanner, 54+ sites username"
        )
        banner.setWordWrap(True)
        banner.setStyleSheet(
            "background:rgba(124,58,237,0.1);color:#A78BFA;"
            "border:1px solid rgba(124,58,237,0.3);border-radius:8px;padding:10px;font-size:11px;"
        )
        lay.addWidget(banner)

    def _clear_hist_layout(self):
        # Supprime proprement tous les widgets du layout historique
        while self.hist_lay.count():
            item = self.hist_lay.takeAt(0)
            if item is None:
                break
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _refresh(self):
        try:
            stats=self.db.get_stats()
            self.stat_labels["searches"].setText(str(stats.get("total",0)))
            self.stat_labels["graphs"].setText(str(stats.get("graphs",0)))
        except: pass

        self._clear_hist_layout()

        try:
            history=self.db.get_history(limit=10)
        except:
            history=[]

        if not history:
            lbl=QLabel("  Aucune recherche pour l'instant.")
            lbl.setStyleSheet("color:#4A5C70;background:transparent;padding:12px;")
            self.hist_lay.addWidget(lbl)
        else:
            for h in history:
                row=QWidget()
                row.setStyleSheet("background:transparent;border-bottom:1px solid #0F1929;")
                rl=QHBoxLayout(row); rl.setContentsMargins(12,5,12,5); rl.setSpacing(10)

                mod=QLabel(str(h.get("module","")))
                mod.setStyleSheet("background:rgba(124,58,237,0.15);color:#A78BFA;border-radius:3px;padding:1px 8px;font-size:9px;min-width:80px;")
                rl.addWidget(mod)

                q=QLabel(str(h.get("query","")))
                q.setStyleSheet("color:#C8D8EC;background:transparent;font-size:11px;")
                rl.addWidget(q,1)

                rc=QLabel(f"{h.get('result_count',0)} résultats")
                rc.setStyleSheet("color:#4A5C70;background:transparent;font-size:10px;")
                rl.addWidget(rc)

                ts=QLabel(str(h.get("timestamp",""))[:16])
                ts.setStyleSheet("color:#2A3A50;background:transparent;font-size:10px;")
                rl.addWidget(ts)

                self.hist_lay.addWidget(row)

        self.hist_lay.addStretch()

    def showEvent(self, e):
        super().showEvent(e)
        try:
            self._refresh()
        except Exception as ex:
            print(f"[Dashboard] refresh error: {ex}")

    def set_accent(self, c):
        pass
