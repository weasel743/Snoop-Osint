from ui.views.base_view import BaseView
from modules.france.datafr import run
class DataFrView(BaseView):
    def __init__(self,p=None): super().__init__("🇫🇷 Data.gouv.fr",p)
    def _get_title(self): return "🇫🇷 Data.gouv.fr — Donnees ouvertes officielles"
    def _get_placeholder(self): return "Mot-cle de recherche"
    def _get_search_fn(self,q): return run,[q]
