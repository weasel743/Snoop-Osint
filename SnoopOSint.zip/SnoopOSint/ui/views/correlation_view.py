from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTextEdit, QSplitter, QSpinBox)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QFont, QColor
from ui.views.graph_view import GraphCanvas
from ui.widgets.toast import Toast
from modules.correlation.engine import CorrelationEngine, detect_type
from core.config_manager import ConfigManager
from core.database import Database

class CorrelationView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.cfg=ConfigManager(); self.db=Database()
        self._engine=None; self._nodes=[]; self._edges=[]
        self.toast=Toast(self)
        self._build_ui()

    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        # Header
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("🔗 Corrélation automatique"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;")
        hl.addWidget(t); hl.addStretch()
        self.node_badge=QLabel(""); self.node_badge.setStyleSheet("background:rgba(124,58,237,0.15);color:#A78BFA;border-radius:4px;padding:2px 10px;font-size:11px;"); self.node_badge.hide()
        hl.addWidget(self.node_badge); lay.addWidget(h)
        # Controls
        c=QWidget(); c.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        cl=QHBoxLayout(c); cl.setContentsMargins(16,10,16,10); cl.setSpacing(8)
        self.seed_input=QLineEdit(); self.seed_input.setPlaceholderText("Email, username, IP, domaine...")
        self.seed_input.setMinimumHeight(36); self.seed_input.returnPressed.connect(self._start)
        cl.addWidget(self.seed_input)
        depth_label=QLabel("Profondeur:"); depth_label.setStyleSheet("color:#8AA0B8;background:transparent;font-size:10px;")
        cl.addWidget(depth_label)
        self.depth_spin=QSpinBox(); self.depth_spin.setRange(1,5); self.depth_spin.setValue(3); self.depth_spin.setMaximumWidth(60)
        cl.addWidget(self.depth_spin)
        self.btn_start=QPushButton("▶  Démarrer"); self.btn_start.setMinimumHeight(36); self.btn_start.setMinimumWidth(130)
        self.btn_start.clicked.connect(self._start); cl.addWidget(self.btn_start)
        self.btn_stop=QPushButton("⏹ Stop"); self.btn_stop.setObjectName("secondary"); self.btn_stop.setMinimumHeight(36)
        self.btn_stop.clicked.connect(self._stop); self.btn_stop.hide(); cl.addWidget(self.btn_stop)
        self.btn_save=QPushButton("💾 Sauvegarder"); self.btn_save.setObjectName("secondary"); self.btn_save.setMinimumHeight(36)
        self.btn_save.clicked.connect(self._save); self.btn_save.hide(); cl.addWidget(self.btn_save)
        self.btn_clear=QPushButton("🗑 Effacer"); self.btn_clear.setObjectName("secondary"); self.btn_clear.setMinimumHeight(36)
        self.btn_clear.clicked.connect(self._clear); cl.addWidget(self.btn_clear)
        lay.addWidget(c)
        # Splitter
        sp=QSplitter(Qt.Orientation.Horizontal)
        self.canvas=GraphCanvas(); sp.addWidget(self.canvas)
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(8,8,8,8)
        lbl=QLabel("📋 Log en temps réel"); lbl.setStyleSheet("color:#A78BFA;font-weight:bold;background:transparent;font-size:11px;"); rl.addWidget(lbl)
        self.log=QTextEdit(); self.log.setReadOnly(True); self.log.setMaximumWidth(280)
        self.log.setStyleSheet("background:#0D1726;color:#8AA0B8;border:1px solid #1A2A44;border-radius:6px;font-family:Consolas;font-size:10px;")
        rl.addWidget(self.log)
        sp.addWidget(right); sp.setSizes([1000,280])
        lay.addWidget(sp,1)
        # Status
        self.status=QLabel("Entrez une valeur et cliquez Demarrer")
        self.status.setStyleSheet("background:#0D1726;color:#8AA0B8;padding:4px 16px;font-size:10px;border-top:1px solid #1A2A44;"); self.status.setFixedHeight(24)
        lay.addWidget(self.status)

    def set_query(self,q): self.seed_input.setText(q); QTimer.singleShot(100,self._start)

    def _start(self):
        seed=self.seed_input.text().strip()
        if not seed: return
        self._nodes=[]; self._edges=[]; self.canvas.clear()
        self.log.clear(); self.log.append(f"🎯 Cible: {seed}"); self.log.append(f"📡 Type detecte: {detect_type(seed)}")
        self.btn_start.setEnabled(False); self.btn_stop.show(); self.btn_save.hide()
        t=detect_type(seed); self.status.setText(f"Exploration de {seed} ({t})...")
        self._engine=CorrelationEngine(seed,max_depth=self.depth_spin.value(),max_nodes=self.cfg.get("correlation","max_nodes",default=60),timeout=self.cfg.get_timeout())
        self._engine.node_found.connect(self._on_node)
        self._engine.edge_found.connect(self._on_edge)
        self._engine.progress.connect(self._on_progress)
        self._engine.finished_signal.connect(self._on_finished)
        self._engine.start()

    def _stop(self):
        if self._engine: self._engine.stop()
        self._on_finished(self._nodes,self._edges)

    def _on_node(self,node):
        self._nodes.append(node)
        self.canvas.add_node(node)
        self.log.append(f"  ✅ [{node['type']}] {node['value'][:50]}")
        self.node_badge.setText(f"{len(self._nodes)} nœuds"); self.node_badge.show()
        self.status.setText(f"Exploration... {len(self._nodes)} noeuds trouves")

    def _on_edge(self,edge):
        self._edges.append(edge)
        self.canvas.add_edge(edge)
        self.log.append(f"  🔗 {edge['src'][:30]} → {edge['dst'][:30]}")

    def _on_progress(self,msg):
        self.log.append(f"  📡 {msg}")
        self.log.ensureCursorVisible()

    def _on_finished(self,nodes,edges):
        self._nodes=nodes; self._edges=edges
        self.btn_start.setEnabled(True); self.btn_stop.hide()
        if nodes: self.btn_save.show()
        self.status.setText(f"Terminé — {len(nodes)} noeuds, {len(edges)} connexions")
        self.log.append(f"\n✅ Terminé: {len(nodes)} noeuds | {len(edges)} connexions")
        self.canvas.fit_view()

    def _save(self):
        if not self._nodes: return
        seed=self.seed_input.text().strip()
        summary=f"{len(self._nodes)} noeuds, {len(self._edges)} connexions"
        self.db.save_graph(seed,self._nodes,self._edges,summary)
        self.toast.show_message("Graphe sauvegarde","success")

    def _clear(self):
        self._nodes=[]; self._edges=[]
        self.canvas.clear(); self.log.clear()
        self.seed_input.clear(); self.node_badge.hide()
        self.btn_save.hide(); self.status.setText("Pret")

    def set_accent(self,color):
        pass
