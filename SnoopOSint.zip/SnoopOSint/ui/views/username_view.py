from ui.views.base_view import BaseView
from modules.username.sherlock import run
class UsernameView(BaseView):
    def __init__(self,p=None): super().__init__("👤 Nom d'utilisateur",p)
    def _get_title(self): return "👤 Recherche par nom d'utilisateur — 55+ plateformes"
    def _get_placeholder(self): return "ex: john_doe"
    def _get_search_fn(self,q): return run,[q]
