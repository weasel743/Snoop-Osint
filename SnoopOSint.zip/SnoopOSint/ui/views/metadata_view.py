from PyQt6.QtWidgets import QPushButton, QFileDialog
from ui.views.base_view import BaseView
from modules.metadata.extractor import run
class MetadataView(BaseView):
    def __init__(self,p=None): super().__init__("📄 Metadonnees",p)
    def _get_title(self): return "📄 Extraction de metadonnees — PDF, DOCX, XLSX, Images"
    def _get_placeholder(self): return "Chemin du fichier ou cliquez Parcourir"
    def _build_extra_controls(self):
        btn=QPushButton("📂 Parcourir")
        btn.setObjectName("secondary")
        btn.clicked.connect(self._browse)
        return [btn]
    def _browse(self):
        p,_=QFileDialog.getOpenFileName(self,"Choisir un fichier","","Fichiers (*.pdf *.docx *.xlsx *.jpg *.jpeg *.png *.gif *.bmp *.tiff)")
        if p: self.search_input.setText(p)
    def _get_search_fn(self,q): return run,[q]
