from PyQt6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QTextEdit,QComboBox,QProgressBar,QSplitter)
from PyQt6.QtCore import Qt,QThread,pyqtSignal
from PyQt6.QtGui import QFont
from ui.widgets.table import SnoopTable
from core.database import Database
from core.config_manager import ConfigManager

MODULES_AVAILABLE={"username":"modules.username.sherlock","email":"modules.email.checker",
    "ip":"modules.ip.lookup","domain":"modules.domain.lookup","phone":"modules.phone.lookup",
    "github":"modules.social.github_scan","crypto":"modules.crypto.lookup",
    "breach":"modules.breach.lookup","paste":"modules.paste.lookup","wayback":"modules.wayback.lookup",
    "portscan":"modules.portscan.scanner","bodacc":"modules.france.bodacc",
    "infogreffe":"modules.france.infogreffe","datafr":"modules.france.datafr"}

class BatchWorker(QThread):
    item_done=pyqtSignal(str,str,list,int,int)
    finished=pyqtSignal()
    def __init__(self,targets,module,timeout=10):
        super().__init__(); self.targets=targets; self.module=module; self.timeout=timeout; self._stop=False
    def stop(self): self._stop=True
    def run(self):
        import importlib
        mod_path=MODULES_AVAILABLE.get(self.module,"modules.ip.lookup")
        try: mod=importlib.import_module(mod_path)
        except: self.finished.emit(); return
        fn=getattr(mod,"run",None)
        if not fn: self.finished.emit(); return
        for i,target in enumerate(self.targets):
            if self._stop: break
            target=target.strip()
            if not target: continue
            try: result=fn(target,timeout=self.timeout)
            except Exception as e: result=[{"Erreur":str(e)}]
            self.item_done.emit(target,self.module,result,i+1,len(self.targets))
        self.finished.emit()

class BatchView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.db=Database(); self.cfg=ConfigManager(); self._worker=None; self._results=[]; self._build_ui()
    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("📦 Batch — Recherche multi-cibles"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;"); hl.addWidget(t); hl.addStretch(); lay.addWidget(h)
        ctrl=QWidget(); ctrl.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        cl=QHBoxLayout(ctrl); cl.setContentsMargins(16,10,16,10); cl.setSpacing(8)
        cl.addWidget(QLabel("Module:"))
        self.mod_combo=QComboBox()
        for k in MODULES_AVAILABLE: self.mod_combo.addItem(k)
        cl.addWidget(self.mod_combo)
        self.btn_start=QPushButton("▶ Lancer"); self.btn_start.setMinimumHeight(32); self.btn_start.clicked.connect(self._start); cl.addWidget(self.btn_start)
        self.btn_stop=QPushButton("⏹ Stop"); self.btn_stop.setObjectName("secondary"); self.btn_stop.setMinimumHeight(32); self.btn_stop.clicked.connect(self._stop); self.btn_stop.hide(); cl.addWidget(self.btn_stop)
        cl.addStretch(); lay.addWidget(ctrl)
        self.progress=QProgressBar(); self.progress.setFixedHeight(3); self.progress.setTextVisible(False); self.progress.setStyleSheet("QProgressBar{border:none;background:#1A2A44}QProgressBar::chunk{background:#7C3AED}"); lay.addWidget(self.progress)
        sp=QSplitter(Qt.Orientation.Horizontal)
        left=QWidget(); ll=QVBoxLayout(left); ll.setContentsMargins(8,8,8,8)
        ll.addWidget(QLabel("Cibles (une par ligne):"))
        self.targets_edit=QTextEdit(); self.targets_edit.setPlaceholderText("example.com\ngoogle.com\n8.8.8.8"); ll.addWidget(self.targets_edit)
        sp.addWidget(left)
        right=QWidget(); rl=QVBoxLayout(right); rl.setContentsMargins(0,0,0,0)
        self.table=SnoopTable(); rl.addWidget(self.table)
        sp.addWidget(right); sp.setSizes([250,750]); lay.addWidget(sp,1)
        self.status=QLabel(""); self.status.setStyleSheet("background:#0D1726;color:#8AA0B8;padding:4px 16px;font-size:10px;border-top:1px solid #1A2A44;"); self.status.setFixedHeight(24); lay.addWidget(self.status)
    def _start(self):
        targets=[t for t in self.targets_edit.toPlainText().split("\n") if t.strip()]
        if not targets: return
        self._results=[]; self.table.setRowCount(0); self.progress.setValue(0)
        self.btn_start.setEnabled(False); self.btn_stop.show()
        self.status.setText(f"0/{len(targets)} cibles traitées...")
        module=self.mod_combo.currentText()
        self._worker=BatchWorker(targets,module,self.cfg.get_timeout())
        self._worker.item_done.connect(self._on_item)
        self._worker.finished.connect(self._on_done)
        self._worker.start()
    def _stop(self):
        if self._worker: self._worker.stop()
    def _on_item(self,target,module,results,done,total):
        self.progress.setValue(int(done/total*100))
        self.status.setText(f"{done}/{total} — {target}")
        for r in results:
            row={"Cible":target,"Module":module}
            if isinstance(r,dict): row.update(r)
            else: row["Resultat"]=str(r)
            self._results.append(row)
        self.table.load(self._results)
        try: self.db.save_result(f"batch_{module}",target,results)
        except: pass
    def _on_done(self):
        self.btn_start.setEnabled(True); self.btn_stop.hide()
        self.status.setText(f"Terminé — {len(self._results)} résultats")
    def set_accent(self,c): pass
