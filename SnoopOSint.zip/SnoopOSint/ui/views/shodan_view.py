from ui.views.base_view import BaseView
from modules.ip.lookup import run as ip_run
def run_shodan(target, timeout=10, progress_callback=None):
    import requests
    H={"User-Agent":"SnoopOSINT/1.0"}
    results=[]
    clean=target.replace("https://","").replace("http://","").split("/")[0].strip()
    import socket
    try:
        ip=socket.gethostbyname(clean)
        if progress_callback: progress_callback(1,3)
    except: ip=clean
    try:
        r=requests.get(f"https://internetdb.shodan.io/{ip}",headers=H,timeout=timeout)
        if r.status_code==200:
            d=r.json()
            results.append({"Champ":"IP","Valeur":ip,"Source":"Shodan InternetDB"})
            if d.get("ports"): results.append({"Champ":"Ports ouverts","Valeur":", ".join(str(p) for p in d["ports"]),"Source":"Shodan InternetDB"})
            if d.get("hostnames"): results.append({"Champ":"Hostnames","Valeur":", ".join(d["hostnames"][:5]),"Source":"Shodan InternetDB"})
            if d.get("cpes"): results.append({"Champ":"CPE","Valeur":", ".join(d["cpes"][:5]),"Source":"Shodan InternetDB"})
            if d.get("vulns"): results.append({"Champ":"CVE detectees","Valeur":", ".join(d["vulns"][:5]),"Source":"Shodan InternetDB"})
            if d.get("tags"): results.append({"Champ":"Tags","Valeur":", ".join(d["tags"]),"Source":"Shodan InternetDB"})
            if not any(v for v in [d.get("ports"),d.get("hostnames"),d.get("cpes")]): results.append({"Champ":"Info","Valeur":"Aucune donnee Shodan pour cette IP","Source":"Shodan InternetDB"})
        if progress_callback: progress_callback(2,3)
    except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"Shodan"})
    extras=ip_run(ip,timeout)
    results+=extras
    if progress_callback: progress_callback(3,3)
    return results
class ShodanView(BaseView):
    def __init__(self,p=None): super().__init__("🛡️ Shodan",p)
    def _get_title(self): return "🛡️ Shodan — InternetDB (gratuit) + Geolocalisation IP"
    def _get_placeholder(self): return "Adresse IP ou domaine"
    def _get_search_fn(self,q): return run_shodan,[q]
