from ui.views.base_view import BaseView
from modules.portscan.scanner import run
class PortScanView(BaseView):
    def __init__(self,p=None): super().__init__("🔌 Port Scanner",p)
    def _get_title(self): return "🔌 Port Scanner — 20 ports courants avec banner grabbing"
    def _get_placeholder(self): return "ex: example.com ou 8.8.8.8"
    def _get_search_fn(self,q): return run,[q]
