from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QComboBox,QMessageBox
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from ui.widgets.table import SnoopTable
from core.database import Database
import json

class HistoryView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.db=Database(); self._all=[]; self._build_ui(); self._load()
    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("📋 Historique des recherches"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;"); hl.addWidget(t); hl.addStretch()
        self.count_lbl=QLabel(""); self.count_lbl.setStyleSheet("color:#8AA0B8;background:transparent;font-size:11px;"); hl.addWidget(self.count_lbl)
        lay.addWidget(h)
        bar=QWidget(); bar.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        bl=QHBoxLayout(bar); bl.setContentsMargins(16,8,16,8); bl.setSpacing(8)
        self.search=QLineEdit(); self.search.setPlaceholderText("🔍 Filtrer..."); self.search.textChanged.connect(self._filter)
        bl.addWidget(self.search)
        self.mod_filter=QComboBox(); self.mod_filter.addItem("Tous les modules"); self.mod_filter.currentTextChanged.connect(self._filter)
        bl.addWidget(self.mod_filter)
        btn_r=QPushButton("🔄 Actualiser"); btn_r.setObjectName("secondary"); btn_r.clicked.connect(self._load); bl.addWidget(btn_r)
        btn_c=QPushButton("🗑 Tout effacer"); btn_c.setObjectName("secondary"); btn_c.clicked.connect(self._clear_all); bl.addWidget(btn_c)
        lay.addWidget(bar)
        self.table=SnoopTable(); lay.addWidget(self.table,1)
        self.status=QLabel(""); self.status.setStyleSheet("background:#0D1726;color:#8AA0B8;padding:4px 16px;font-size:10px;border-top:1px solid #1A2A44;"); self.status.setFixedHeight(24)
        lay.addWidget(self.status)
    def _load(self):
        self._all=self.db.get_history(limit=500)
        mods=sorted(set(h["module"] for h in self._all))
        self.mod_filter.clear(); self.mod_filter.addItem("Tous les modules")
        for m in mods: self.mod_filter.addItem(m)
        self._filter()
    def _filter(self):
        q=self.search.text().lower(); mod=self.mod_filter.currentText()
        filtered=[h for h in self._all if
            (mod=="Tous les modules" or h["module"]==mod) and
            (not q or q in h.get("query","").lower() or q in h.get("module","").lower())]
        display=[{"Module":h["module"],"Requete":h["query"],"Resultats":str(h.get("result_count",0)),"Date":h.get("timestamp","")[:16]} for h in filtered]
        self.table.load(display)
        self.count_lbl.setText(f"{len(filtered)} entrée(s)")
        self.status.setText(f"{len(filtered)} entrées affichées sur {len(self._all)} total")
    def _clear_all(self):
        if QMessageBox.question(self,"Confirmer","Effacer tout l'historique ?",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)==QMessageBox.StandardButton.Yes:
            self.db.clear_history(); self._load()
    def showEvent(self,e): super().showEvent(e); self._load()
    def set_accent(self,c): pass
