from ui.views.base_view import BaseView, WorkerThread
import requests
def run_dorking(domain, timeout=5, progress_callback=None):
    dorks=[
        ("Site complet",f"site:{domain}"),
        ("Fichiers PDF",f"site:{domain} ext:pdf"),
        ("Fichiers sensibles",f"site:{domain} ext:xls OR ext:xlsx OR ext:csv"),
        ("Fichiers config",f"site:{domain} ext:env OR ext:cfg OR ext:conf OR ext:ini"),
        ("Fichiers backup",f"site:{domain} ext:bak OR ext:old OR ext:backup"),
        ("Repertoires ouverts",f'intitle:"index of" site:{domain}'),
        ("Pages login",f"site:{domain} inurl:login OR inurl:admin OR inurl:signin"),
        ("Emails exposes",f"site:{domain} intext:@{domain}"),
        ("WordPress",f"site:{domain} inurl:wp-admin OR inurl:wp-login"),
        ("PHP errors",f'site:{domain} "Warning: mysql_" OR "Fatal error"'),
        ("Sous-domaines",f"site:*.{domain} -www"),
        ("GitHub code",f'site:github.com "{domain}"'),
    ]
    results=[]
    for i,(name,q) in enumerate(dorks):
        results.append({"Dork":name,"Requete":q,"Lien Google":f"https://www.google.com/search?q={requests.utils.quote(q)}","Lien DuckDuckGo":f"https://duckduckgo.com/?q={requests.utils.quote(q)}"})
        if progress_callback: progress_callback(i+1,len(dorks))
    return results
class DorkingView(BaseView):
    def __init__(self,p=None): super().__init__("🔍 Google Dorking",p)
    def _get_title(self): return "🔍 Google Dorking — Generation de dorks"
    def _get_placeholder(self): return "ex: example.com"
    def _get_search_fn(self,q): return run_dorking,[q]
