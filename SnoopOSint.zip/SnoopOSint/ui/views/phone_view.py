from ui.views.base_view import BaseView
from modules.phone.lookup import run
class PhoneView(BaseView):
    def __init__(self,p=None): super().__init__("📱 Telephone",p)
    def _get_title(self): return "📱 Analyse de numero de telephone"
    def _get_placeholder(self): return "ex: +33612345678"
    def _get_search_fn(self,q): return run,[q]
