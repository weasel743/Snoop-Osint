from PyQt6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,
    QComboBox,QCheckBox,QSpinBox,QGroupBox,QLineEdit,QDoubleSpinBox,QScrollArea,QMessageBox)
from PyQt6.QtCore import Qt,pyqtSignal
from PyQt6.QtGui import QFont
from core.config_manager import ConfigManager
from core.language_manager import LanguageManager

class SettingsView(QWidget):
    theme_changed=pyqtSignal(str)
    language_changed=pyqtSignal(str)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.cfg=ConfigManager(); self.lang=LanguageManager()
        self._build_ui()

    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("⚙️ Paramètres"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;"); hl.addWidget(t); hl.addStretch()
        self.btn_save=QPushButton("💾 Sauvegarder"); self.btn_save.clicked.connect(self._save); hl.addWidget(self.btn_save)
        lay.addWidget(h)

        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setStyleSheet("border:none;background:transparent;")
        content=QWidget(); cl=QVBoxLayout(content); cl.setContentsMargins(24,20,24,20); cl.setSpacing(16)

        # Apparence
        ap=self._group("🎨 Apparence")
        # Thème
        t_row=self._row("Thème:")
        self.theme_combo=QComboBox()
        for name in self.cfg.themes: self.theme_combo.addItem(name)
        self.theme_combo.setCurrentText(self.cfg.get("app","theme",default="violet"))
        self.theme_combo.currentTextChanged.connect(lambda t:self.theme_changed.emit(t))
        t_row.addWidget(self.theme_combo); ap.addLayout(t_row)
        # Langue
        l_row=self._row("Langue:")
        self.lang_combo=QComboBox()
        for code,name in self.lang.get_languages().items(): self.lang_combo.addItem(name,code)
        idx=list(self.lang.get_languages().keys()).index(self.cfg.get_language())
        self.lang_combo.setCurrentIndex(idx)
        self.lang_combo.currentIndexChanged.connect(lambda i:self.language_changed.emit(self.lang_combo.itemData(i)))
        l_row.addWidget(self.lang_combo); ap.addLayout(l_row)
        # Animation
        anim_row=self._row("Animation:")
        self.anim_cb=QCheckBox("Activée"); self.anim_cb.setChecked(self.cfg.get("ui","animation","enabled",default=True))
        anim_row.addWidget(self.anim_cb)
        self.anim_type=QComboBox()
        for a in ["lightning","matrix","particles","neural","grid","waves","gradient"]: self.anim_type.addItem(a)
        self.anim_type.setCurrentText(self.cfg.get("ui","animation","type",default="lightning"))
        anim_row.addWidget(self.anim_type); ap.addLayout(anim_row)
        cl.addWidget(ap)

        # Recherche
        sr=self._group("🔍 Recherche")
        t_row2=self._row("Timeout (secondes):")
        self.timeout_spin=QSpinBox(); self.timeout_spin.setRange(3,60); self.timeout_spin.setValue(self.cfg.get_timeout())
        t_row2.addWidget(self.timeout_spin); sr.addLayout(t_row2)
        th_row=self._row("Threads max:")
        self.threads_spin=QSpinBox(); self.threads_spin.setRange(5,100); self.threads_spin.setValue(self.cfg.get("search","max_threads",default=50))
        th_row.addWidget(self.threads_spin); sr.addLayout(th_row)
        hist_row=self._row("Sauvegarder l'historique:")
        self.auto_hist=QCheckBox(); self.auto_hist.setChecked(self.cfg.get("search","auto_save_history",default=True))
        hist_row.addWidget(self.auto_hist); sr.addLayout(hist_row)
        cl.addWidget(sr)

        # Clefs API
        ak=self._group("🔑 Clefs API (optionnelles)")
        for key,label in [("shodan","Shodan API Key"),("hibp","Have I Been Pwned API Key"),("virustotal","VirusTotal API Key")]:
            row=self._row(f"{label}:")
            inp=QLineEdit(); inp.setPlaceholderText("(optionnelle)"); inp.setEchoMode(QLineEdit.EchoMode.Password)
            inp.setText(self.cfg.get("api_keys",key,default=""))
            inp.setObjectName(f"api_{key}"); row.addWidget(inp); ak.addLayout(row)
        cl.addWidget(ak)

        # Proxy
        px=self._group("🔒 Proxy")
        pr_row=self._row("Proxy:")
        self.proxy_cb=QCheckBox("Activé"); self.proxy_cb.setChecked(self.cfg.get("proxy","enabled",default=False))
        pr_row.addWidget(self.proxy_cb); px.addLayout(pr_row)
        for k,l in [("http","HTTP Proxy"),("https","HTTPS Proxy")]:
            row=self._row(f"{l}:")
            inp=QLineEdit(); inp.setPlaceholderText("http://127.0.0.1:8080")
            inp.setText(self.cfg.get("proxy",k,default="")); inp.setObjectName(f"proxy_{k}")
            row.addWidget(inp); px.addLayout(row)
        cl.addWidget(px)

        cl.addStretch(); scroll.setWidget(content); lay.addWidget(scroll,1)

    def _group(self,title):
        g=QGroupBox(title); l=QVBoxLayout(g); return l

    def _row(self,label):
        lay=QHBoxLayout()
        lbl=QLabel(label); lbl.setMinimumWidth(160); lbl.setStyleSheet("color:#8AA0B8;background:transparent;")
        lay.addWidget(lbl); return lay

    def _save(self):
        self.cfg.set(self.theme_combo.currentText(),"app","theme")
        self.cfg.set(self.lang_combo.itemData(self.lang_combo.currentIndex()),"app","language")
        self.cfg.set(self.anim_cb.isChecked(),"ui","animation","enabled")
        self.cfg.set(self.anim_type.currentText(),"ui","animation","type")
        self.cfg.set(self.timeout_spin.value(),"search","timeout")
        self.cfg.set(self.threads_spin.value(),"search","max_threads")
        self.cfg.set(self.auto_hist.isChecked(),"search","auto_save_history")
        self.cfg.set(self.proxy_cb.isChecked(),"proxy","enabled")
        for w in self.findChildren(QLineEdit):
            if w.objectName().startswith("api_"):
                key=w.objectName()[4:]; self.cfg.set(w.text(),"api_keys",key)
            elif w.objectName().startswith("proxy_"):
                key=w.objectName()[6:]; self.cfg.set(w.text(),"proxy",key)
        self.cfg.save()
        QMessageBox.information(self,"Paramètres","Paramètres sauvegardés.\nRedémarrez pour appliquer les changements de langue.")

    def set_accent(self,c): pass
