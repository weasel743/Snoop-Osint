from ui.views.base_view import BaseView
from modules.france.bodacc import run
class BodaccView(BaseView):
    def __init__(self,p=None): super().__init__("🏛️ BODACC",p)
    def _get_title(self): return "🏛️ BODACC — Entreprises francaises officielles"
    def _get_placeholder(self): return "Nom d'entreprise ou SIREN"
    def _get_search_fn(self,q): return run,[q]
