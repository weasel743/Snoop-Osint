from ui.views.base_view import BaseView
from modules.breach.lookup import run
class BreachView(BaseView):
    def __init__(self,p=None): super().__init__("🔓 Fuites de donnees",p)
    def _get_title(self): return "🔓 Recherche de fuites de donnees"
    def _get_placeholder(self): return "ex: email@example.com"
    def _get_search_fn(self,q): return run,[q]
