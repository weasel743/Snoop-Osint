from PyQt6.QtWidgets import QTabWidget, QWidget, QVBoxLayout, QComboBox
from ui.views.base_view import BaseView, WorkerThread
from modules.domain.lookup import run_whois, run_dns, run_ssl, run_subdomains
from ui.widgets.table import SnoopTable

class DomainView(BaseView):
    def __init__(self,p=None):
        self._mode="whois"
        super().__init__("🏠 Domaine",p)
    def _get_title(self): return "🏠 Analyse de domaine — WHOIS, DNS, SSL, Sous-domaines"
    def _get_placeholder(self): return "ex: example.com"
    def _build_extra_controls(self):
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["WHOIS","DNS","SSL","Sous-domaines"])
        self.mode_combo.currentTextChanged.connect(lambda t: setattr(self,"_mode",t.lower().replace("-","_").replace("ous-domaines","ubdomains")))
        self.mode_combo.setMaximumWidth(140)
        return [self.mode_combo]
    def _get_search_fn(self,q):
        fn_map={"whois":run_whois,"dns":run_dns,"ssl":run_ssl,"sous-domaines":run_subdomains,"subdomains":run_subdomains}
        mode=self.mode_combo.currentText().lower().strip()
        fn=fn_map.get(mode,run_whois)
        return fn,[q]
