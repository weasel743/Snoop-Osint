from PyQt6.QtWidgets import QPushButton, QFileDialog
from ui.views.base_view import BaseView
from modules.image.exif_extract import run
import os
class ImageView(BaseView):
    def __init__(self,p=None): super().__init__("🖼️ Image EXIF",p)
    def _get_title(self): return "🖼️ Extraction EXIF — Images, GPS, Metadonnees"
    def _get_placeholder(self): return "Chemin du fichier image ou cliquez Parcourir"
    def _build_extra_controls(self):
        btn=QPushButton("📂 Parcourir")
        btn.setObjectName("secondary")
        btn.clicked.connect(self._browse)
        return [btn]
    def _browse(self):
        p,_=QFileDialog.getOpenFileName(self,"Choisir une image","","Images (*.jpg *.jpeg *.png *.gif *.bmp *.tiff *.webp *.heic)")
        if p: self.search_input.setText(p)
    def _get_search_fn(self,q): return run,[q]
