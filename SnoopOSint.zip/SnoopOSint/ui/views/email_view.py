from ui.views.base_view import BaseView
from modules.email.checker import run
class EmailView(BaseView):
    def __init__(self,p=None): super().__init__("📧 Email",p)
    def _get_title(self): return "📧 Analyse d'adresse email — 12 checkers"
    def _get_placeholder(self): return "ex: john@example.com"
    def _get_search_fn(self,q): return run,[q]
