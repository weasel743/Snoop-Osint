from ui.views.base_view import BaseView
from modules.france.infogreffe import run
class InfogreffeView(BaseView):
    def __init__(self,p=None): super().__init__("📋 Infogreffe",p)
    def _get_title(self): return "📋 Infogreffe — Dirigeants et informations legales"
    def _get_placeholder(self): return "Nom d'entreprise ou SIREN"
    def _get_search_fn(self,q): return run,[q]
