from ui.views.base_view import BaseView
from modules.social.github_scan import run
class SocialView(BaseView):
    def __init__(self,p=None): super().__init__("🐙 GitHub",p)
    def _get_title(self): return "🐙 Scan GitHub — Profil, repos, emails, organisations"
    def _get_placeholder(self): return "ex: torvalds"
    def _get_search_fn(self,q): return run,[q]
