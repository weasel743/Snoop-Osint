from ui.views.base_view import BaseView
from modules.paste.lookup import run
class PasteView(BaseView):
    def __init__(self,p=None): super().__init__("📋 Paste Sites",p)
    def _get_title(self): return "📋 Recherche sur Paste Sites — Pastebin, pastes.io..."
    def _get_placeholder(self): return "email, username, IP, domaine..."
    def _get_search_fn(self,q): return run,[q]
