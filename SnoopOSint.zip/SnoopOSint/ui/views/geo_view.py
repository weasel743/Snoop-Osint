from ui.views.base_view import BaseView
from modules.ip.lookup import run
class GeoView(BaseView):
    def __init__(self,p=None): super().__init__("🌍 Geolocalisation",p)
    def _get_title(self): return "🌍 Geolocalisation IP — ip-api.com + ipinfo.io + Shodan"
    def _get_placeholder(self): return "Adresse IP (ex: 8.8.8.8)"
    def _get_search_fn(self,q): return run,[q]
