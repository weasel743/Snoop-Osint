from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QScrollArea
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont,QColor
from core.database import Database

class TimelineView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.db=Database(); self._build_ui(); self._load()
    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0)
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("📅 Timeline"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;"); hl.addWidget(t); hl.addStretch()
        btn=QPushButton("🔄 Actualiser"); btn.setObjectName("secondary"); btn.clicked.connect(self._load); hl.addWidget(btn)
        lay.addWidget(h)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setStyleSheet("border:none;")
        self.content=QWidget(); self.content_lay=QVBoxLayout(self.content)
        self.content_lay.setContentsMargins(24,16,24,16); self.content_lay.setSpacing(0)
        scroll.setWidget(self.content); lay.addWidget(scroll,1)
    def _load(self):
        for i in range(self.content_lay.count()):
            item=self.content_lay.itemAt(i)
            if item and item.widget(): item.widget().deleteLater()
        history=self.db.get_history(limit=200)
        if not history:
            lbl=QLabel("Aucune recherche dans l'historique.\nLancez des recherches pour voir la timeline.")
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter); lbl.setStyleSheet("color:#4A5C70;font-size:13px;")
            self.content_lay.addWidget(lbl); self.content_lay.addStretch(); return
        # Group by date
        from collections import defaultdict
        by_date=defaultdict(list)
        for h in history: by_date[h.get("timestamp","")[:10]].append(h)
        MOD_COLORS={"username":"#7C3AED","email":"#2563EB","ip":"#059669","domain":"#0891B2","breach":"#DC2626","crypto":"#D97706","bodacc":"#DB2777","correlation":"#8B5CF6"}
        for date in sorted(by_date.keys(),reverse=True):
            dl=QLabel(f"📅  {date}"); f=QFont("Segoe UI",11); f.setBold(True); dl.setFont(f)
            dl.setStyleSheet("color:#A78BFA;background:transparent;padding:12px 0 4px 0;"); self.content_lay.addWidget(dl)
            line=QWidget(); line.setFixedHeight(1); line.setStyleSheet("background:#1A2A44;"); self.content_lay.addWidget(line)
            for h in by_date[date]:
                row=QWidget(); row.setStyleSheet("background:transparent;")
                rl=QHBoxLayout(row); rl.setContentsMargins(12,6,12,6); rl.setSpacing(10)
                color=MOD_COLORS.get(h.get("module",""),"#8AA0B8")
                dot=QLabel("●"); dot.setStyleSheet(f"color:{color};background:transparent;font-size:14px;min-width:16px;"); rl.addWidget(dot)
                time_lbl=QLabel(h.get("timestamp","")[-8:-3] if h.get("timestamp") else ""); time_lbl.setStyleSheet("color:#4A5C70;background:transparent;font-size:10px;min-width:40px;"); rl.addWidget(time_lbl)
                mod=QLabel(h.get("module","")); mod.setStyleSheet(f"background:rgba(124,58,237,0.15);color:#A78BFA;border-radius:3px;padding:1px 8px;font-size:9px;min-width:80px;"); rl.addWidget(mod)
                q=QLabel(h.get("query","")); q.setStyleSheet("color:#C8D8EC;background:transparent;font-size:11px;"); rl.addWidget(q,1)
                rc=QLabel(f"{h.get('result_count',0)} résultats"); rc.setStyleSheet(f"color:{color};background:transparent;font-size:10px;"); rl.addWidget(rc)
                self.content_lay.addWidget(row)
        self.content_lay.addStretch()
    def showEvent(self,e): super().showEvent(e); self._load()
    def set_accent(self,c): pass
