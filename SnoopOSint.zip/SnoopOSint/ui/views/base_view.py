from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLineEdit,
    QPushButton, QLabel, QFileDialog, QApplication, QSplitter)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont
from ui.widgets.table import SnoopTable
from ui.widgets.progress_ring import ProgressRing
from core.config_manager import ConfigManager
from core.language_manager import LanguageManager
from core.database import Database
from core.report_generator import ReportGenerator
import os

class WorkerThread(QThread):
    result_ready = pyqtSignal(list)
    progress_update = pyqtSignal(int, int, object)
    error_occurred = pyqtSignal(str)
    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn = fn; self.args = args; self.kwargs = kwargs
    def run(self):
        try:
            def cb(done, total, item=None):
                self.progress_update.emit(done, total, item)
            self.kwargs["progress_callback"] = cb
            result = self.fn(*self.args, **self.kwargs)
            if result is None: result = []
            self.result_ready.emit(result)
        except Exception as e:
            self.error_occurred.emit(str(e))
            self.result_ready.emit([])

class BaseView(QWidget):
    search_done = pyqtSignal(str, list)

    def __init__(self, module_name, parent=None):
        super().__init__(parent)
        self.module_name = module_name
        self.cfg = ConfigManager()
        self.lang = LanguageManager()
        self.db = Database()
        self._worker = None
        self._results = []
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # Header
        header = QWidget()
        header.setObjectName("header")
        header.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        h_lay = QHBoxLayout(header)
        h_lay.setContentsMargins(16, 10, 16, 10)

        self.title_label = QLabel(self._get_title())
        f = QFont("Segoe UI", 14); f.setBold(True)
        self.title_label.setFont(f)
        self.title_label.setStyleSheet("color:#EEF3FC;background:transparent;")
        h_lay.addWidget(self.title_label)
        h_lay.addStretch()

        self.result_badge = QLabel("")
        self.result_badge.setStyleSheet("background:rgba(52,211,153,0.15);color:#34D399;border-radius:4px;padding:2px 10px;font-size:11px;")
        self.result_badge.hide()
        h_lay.addWidget(self.result_badge)

        lay.addWidget(header)

        # Search bar
        search_bar = QWidget()
        search_bar.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        s_lay = QHBoxLayout(search_bar)
        s_lay.setContentsMargins(16, 10, 16, 10)
        s_lay.setSpacing(8)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(self._get_placeholder())
        self.search_input.setMinimumHeight(36)
        self.search_input.returnPressed.connect(self._start_search)
        s_lay.addWidget(self.search_input)

        self.btn_search = QPushButton(self.lang.t("buttons","search"))
        self.btn_search.setMinimumHeight(36)
        self.btn_search.setMinimumWidth(110)
        self.btn_search.clicked.connect(self._start_search)
        s_lay.addWidget(self.btn_search)

        self.btn_stop = QPushButton(self.lang.t("buttons","stop"))
        self.btn_stop.setObjectName("secondary")
        self.btn_stop.setMinimumHeight(36)
        self.btn_stop.clicked.connect(self._stop_search)
        self.btn_stop.hide()
        s_lay.addWidget(self.btn_stop)

        self.btn_clear = QPushButton(self.lang.t("buttons","clear"))
        self.btn_clear.setObjectName("secondary")
        self.btn_clear.setMinimumHeight(36)
        self.btn_clear.clicked.connect(self._clear)
        s_lay.addWidget(self.btn_clear)

        extra = self._build_extra_controls()
        if extra:
            for w in extra: s_lay.addWidget(w)

        lay.addWidget(search_bar)

        # Filter bar
        filter_bar = QWidget()
        filter_bar.setStyleSheet("background:#0A0E17;border-bottom:1px solid #1A2A44;")
        f_lay = QHBoxLayout(filter_bar)
        f_lay.setContentsMargins(16, 6, 16, 6)
        f_lay.setSpacing(8)

        f_icon = QLabel("🔍")
        f_icon.setStyleSheet("background:transparent;font-size:12px;")
        f_lay.addWidget(f_icon)

        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Filtrer les resultats...")
        self.filter_input.setMaximumHeight(28)
        self.filter_input.textChanged.connect(self._apply_filter)
        f_lay.addWidget(self.filter_input)

        self.ring = ProgressRing(size=32)
        f_lay.addWidget(self.ring)

        self.progress_label = QLabel("")
        self.progress_label.setStyleSheet("color:#8AA0B8;font-size:10px;background:transparent;")
        f_lay.addWidget(self.progress_label)

        f_lay.addStretch()

        for label, fn in [("CSV", self._export_csv), ("JSON", self._export_json), ("PDF", self._export_pdf), ("HTML", self._export_html)]:
            btn = QPushButton(label)
            btn.setObjectName("secondary")
            btn.setMaximumHeight(26)
            btn.setMaximumWidth(50)
            btn.clicked.connect(fn)
            f_lay.addWidget(btn)

        lay.addWidget(filter_bar)

        # Table
        self.table = SnoopTable()
        lay.addWidget(self.table, 1)

        # Status bar
        self.status_bar = QLabel("")
        self.status_bar.setStyleSheet("background:#0D1726;color:#8AA0B8;padding:4px 16px;font-size:10px;border-top:1px solid #1A2A44;")
        self.status_bar.setFixedHeight(24)
        lay.addWidget(self.status_bar)

    def _get_title(self): return self.module_name
    def _get_placeholder(self): return "Entrez une valeur..."
    def _build_extra_controls(self): return []

    def _start_search(self):
        query = self.search_input.text().strip()
        if not query: return
        self._results = []
        self.table.setRowCount(0)
        self.result_badge.hide()
        self.filter_input.clear()
        self.ring.set_value(0)
        self.progress_label.setText("Recherche en cours...")
        self.btn_search.setEnabled(False)
        self.btn_stop.show()
        self.status_bar.setText(f"Recherche: {query}...")
        fn, args = self._get_search_fn(query)
        self._worker = WorkerThread(fn, *args, timeout=self.cfg.get_timeout())
        self._worker.result_ready.connect(self._on_result)
        self._worker.progress_update.connect(self._on_progress)
        self._worker.error_occurred.connect(self._on_error)
        self._worker.start()

    def _get_search_fn(self, query):
        raise NotImplementedError

    def _stop_search(self):
        if self._worker and self._worker.isRunning():
            self._worker.terminate()
        self._on_done()

    def _on_progress(self, done, total, item=None):
        self.ring.set_value(done, total)
        pct = int(done/max(total,1)*100)
        self.progress_label.setText(f"{done}/{total} ({pct}%)")
        if item and isinstance(item, dict):
            status = item.get("Statut", item.get("status", ""))
            name = item.get("Plateforme", item.get("platform", ""))
            if name: self.status_bar.setText(f"✔ {name}: {status}")

    def _on_result(self, data):
        self._results = data if data else []
        self.table.load(self._results)
        self._on_done()
        count = len(self._results)
        self.result_badge.setText(f"{count} resultat{'s' if count>1 else ''}")
        self.result_badge.show()
        self.status_bar.setText(f"Terminé — {count} résultat(s)")
        if self.cfg.get("search","auto_save_history",default=True):
            try: self.db.save_result(self.module_name, self.search_input.text().strip(), self._results)
            except: pass
        self.search_done.emit(self.module_name, self._results)

    def _on_error(self, msg):
        self.status_bar.setText(f"Erreur: {msg}")
        self._on_done()

    def _on_done(self):
        self.btn_search.setEnabled(True)
        self.btn_stop.hide()
        self.progress_label.setText("")
        self.ring.set_value(100)

    def _clear(self):
        self.search_input.clear()
        self.filter_input.clear()
        self.table.setRowCount(0)
        self._results = []
        self.result_badge.hide()
        self.ring.set_value(0)
        self.status_bar.setText("")

    def _apply_filter(self, text):
        self.table.filter(text)

    def set_query(self, query):
        self.search_input.setText(query)
        QTimer.singleShot(100, self._start_search)

    def set_accent(self, color):
        self.ring.set_accent(color)

    def _export_csv(self):
        if not self._results: return
        path, _ = QFileDialog.getSaveFileName(self, "Exporter CSV", "", "CSV (*.csv)")
        if path: ReportGenerator(self.module_name, self.search_input.text(), self._results).export_csv(path)

    def _export_json(self):
        if not self._results: return
        path, _ = QFileDialog.getSaveFileName(self, "Exporter JSON", "", "JSON (*.json)")
        if path: ReportGenerator(self.module_name, self.search_input.text(), self._results).export_json(path)

    def _export_pdf(self):
        if not self._results: return
        path, _ = QFileDialog.getSaveFileName(self, "Exporter PDF", "", "PDF (*.pdf)")
        if path: ReportGenerator(self.module_name, self.search_input.text(), self._results).export_pdf(path)

    def _export_html(self):
        if not self._results: return
        path, _ = QFileDialog.getSaveFileName(self, "Exporter HTML", "", "HTML (*.html)")
        if path:
            p = ReportGenerator(self.module_name, self.search_input.text(), self._results).export_html(path)
            import webbrowser; webbrowser.open(f"file://{os.path.abspath(p)}")
