from ui.views.base_view import BaseView
from modules.crypto.lookup import run
class CryptoView(BaseView):
    def __init__(self,p=None): super().__init__("₿ Crypto",p)
    def _get_title(self): return "₿ Analyse de portefeuille — Bitcoin (BTC) et Ethereum (ETH)"
    def _get_placeholder(self): return "Adresse BTC (1... / 3... / bc1...) ou ETH (0x...)"
    def _get_search_fn(self,q): return run,[q]
