from ui.views.base_view import BaseView
from modules.wayback.lookup import run
class WaybackView(BaseView):
    def __init__(self,p=None): super().__init__("🕰️ Wayback Machine",p)
    def _get_title(self): return "🕰️ Wayback Machine — Historique des pages web"
    def _get_placeholder(self): return "ex: example.com ou https://example.com/page"
    def _get_search_fn(self,q): return run,[q]
