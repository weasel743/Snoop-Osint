from ui.views.base_view import BaseView
from modules.ip.lookup import run
class IPView(BaseView):
    def __init__(self,p=None): super().__init__("🌐 Adresse IP",p)
    def _get_title(self): return "🌐 Analyse d'adresse IP — Geolocalisation, ISP, Shodan"
    def _get_placeholder(self): return "ex: 8.8.8.8"
    def _get_search_fn(self,q): return run,[q]
