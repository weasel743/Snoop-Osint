from ui.views.base_view import BaseView
from modules.france.pagesjaunes import run
class PagesJaunesView(BaseView):
    def __init__(self,p=None): super().__init__("📒 Pages Jaunes",p)
    def _get_title(self): return "📒 Pages Jaunes — Annuaire professionnel France"
    def _get_placeholder(self): return "Nom, activite ou numero"
    def _get_search_fn(self,q): return run,[q]
