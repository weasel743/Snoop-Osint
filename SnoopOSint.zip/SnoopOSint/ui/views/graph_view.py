from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox, QSizePolicy
from PyQt6.QtCore import Qt, QRectF, QPointF, QTimer
from PyQt6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QRadialGradient
import math, random
from core.database import Database

NODE_COLORS = {
    "email":"#7C3AED","username":"#2563EB","domain":"#0891B2","ip":"#059669",
    "phone":"#D97706","name":"#DB2777","platform":"#34D399","breach":"#DC2626",
    "crypto":"#F59E0B","org":"#8B5CF6","location":"#6B7280","url":"#0EA5E9",
    "btc":"#F59E0B","eth":"#627EEA","isp":"#64748B","default":"#7C3AED"
}

class GraphCanvas(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.nodes={}; self.edges=[]; self._positions={}
        self._dragging=None; self._drag_offset=QPointF()
        self._scale=1.0; self._offset=QPointF(0,0)
        self._pan_start=None; self._pan_offset=QPointF()
        self.setMinimumSize(400,300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
        self.setMouseTracking(True)
        self._anim_timer=QTimer(); self._anim_timer.timeout.connect(self._layout_step); self._anim_timer.start(50)

    def clear(self):
        self.nodes={}; self.edges=[]; self._positions={}; self.update()

    def add_node(self,node):
        nid=node["id"]
        if nid not in self.nodes:
            self.nodes[nid]=node
            cx=self.width()/2 or 400; cy=self.height()/2 or 300
            angle=random.uniform(0,2*math.pi); dist=random.uniform(50,200)
            self._positions[nid]=QPointF(cx+math.cos(angle)*dist,cy+math.sin(angle)*dist)
        self.update()

    def add_edge(self,edge):
        if not any(e["src"]==edge["src"] and e["dst"]==edge["dst"] for e in self.edges):
            self.edges.append(edge)
        self.update()

    def _layout_step(self):
        if len(self.nodes)<2: return
        nids=list(self._positions.keys()); k=80
        forces={n:QPointF(0,0) for n in nids}
        for i,n1 in enumerate(nids):
            for n2 in nids[i+1:]:
                p1=self._positions[n1]; p2=self._positions[n2]
                dx=p1.x()-p2.x(); dy=p1.y()-p2.y()
                dist=max(math.sqrt(dx*dx+dy*dy),1)
                rep=k*k/dist
                fx=rep*dx/dist; fy=rep*dy/dist
                forces[n1]+=QPointF(fx,fy); forces[n2]-=QPointF(fx,fy)
        for e in self.edges:
            s=e["src"]; d=e["dst"]
            if s not in self._positions or d not in self._positions: continue
            p1=self._positions[s]; p2=self._positions[d]
            dx=p2.x()-p1.x(); dy=p2.y()-p1.y()
            dist=max(math.sqrt(dx*dx+dy*dy),1)
            att=(dist-k)*0.05
            fx=att*dx/dist; fy=att*dy/dist
            forces[s]+=QPointF(fx,fy); forces[d]-=QPointF(fx,fy)
        changed=False
        for n in nids:
            f=forces[n]; mag=math.sqrt(f.x()**2+f.y()**2)
            if mag>0.5:
                step=min(mag,5); self._positions[n]+=QPointF(f.x()/mag*step,f.y()/mag*step); changed=True
        if changed: self.update()

    def fit_view(self):
        if not self._positions: return
        xs=[p.x() for p in self._positions.values()]; ys=[p.y() for p in self._positions.values()]
        min_x,max_x=min(xs),max(xs); min_y,max_y=min(ys),max(ys)
        w=self.width(); h=self.height()
        span_x=max(max_x-min_x,1); span_y=max(max_y-min_y,1)
        self._scale=min(0.9*w/span_x,0.9*h/span_y,2.0)
        cx=(min_x+max_x)/2; cy=(min_y+max_y)/2
        self._offset=QPointF(w/2-cx*self._scale,h/2-cy*self._scale)
        self.update()

    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(),QColor("#0A0E17"))
        if not self.nodes:
            p.setPen(QColor("#1A2A44")); f=QFont(); f.setPointSize(14); p.setFont(f)
            p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,"🕸️  Aucun graphe\nLancez une corrélation")
            return
        p.save(); p.translate(self._offset); p.scale(self._scale,self._scale)
        # Edges
        for e in self.edges:
            s=e.get("src"); d=e.get("dst")
            if s not in self._positions or d not in self._positions: continue
            p1=self._positions[s]; p2=self._positions[d]
            pen=QPen(QColor("#1A2A44"),1); p.setPen(pen); p.drawLine(p1,p2)
            # Arrow
            dx=p2.x()-p1.x(); dy=p2.y()-p1.y()
            dist=max(math.sqrt(dx*dx+dy*dy),1)
            mx=p1.x()+dx*0.5; my=p1.y()+dy*0.5
            p.setPen(QPen(QColor("#4A5C70"),8)); p.drawPoint(QPointF(mx,my))
            if e.get("label"):
                p.setPen(QColor("#4A5C70")); f=QFont(); f.setPointSize(6); p.setFont(f)
                p.drawText(QPointF(mx+4,my-4),e["label"][:15])
        # Nodes
        for nid,node in self.nodes.items():
            pos=self._positions.get(nid)
            if not pos: continue
            ntype=node.get("type","default")
            color=QColor(NODE_COLORS.get(ntype,NODE_COLORS["default"]))
            r=18
            grad=QRadialGradient(pos,r); grad.setColorAt(0,color.lighter(130)); grad.setColorAt(1,color)
            p.setBrush(QBrush(grad)); p.setPen(QPen(color.lighter(150),1.5))
            p.drawEllipse(pos,r,r)
            icons={"email":"@","username":"U","domain":"🌐","ip":"IP","breach":"!","crypto":"₿","org":"🏢","name":"N","platform":"P","location":"📍","url":"🔗"}
            ic=icons.get(ntype,"?")
            p.setPen(QColor("white")); f=QFont(); f.setPointSize(8); f.setBold(True); p.setFont(f)
            p.drawText(QRectF(pos.x()-r,pos.y()-r,2*r,2*r),Qt.AlignmentFlag.AlignCenter,ic)
            label=str(node.get("value",""))[:20]
            p.setPen(QColor("#8AA0B8")); f2=QFont(); f2.setPointSize(6); p.setFont(f2)
            p.drawText(QPointF(pos.x()-40,pos.y()+r+12),label)
        p.restore()

    def wheelEvent(self,e):
        factor=1.1 if e.angleDelta().y()>0 else 0.9
        self._scale=max(0.1,min(self._scale*factor,5.0)); self.update()

    def mousePressEvent(self,e):
        if e.button()==Qt.MouseButton.LeftButton:
            pos=self._to_scene(e.position())
            for nid,npos in self._positions.items():
                if (npos-pos).manhattanLength()<20:
                    self._dragging=nid; self._drag_offset=npos-pos; return
            self._pan_start=e.position(); self._pan_offset=self._offset
        elif e.button()==Qt.MouseButton.RightButton:
            self.fit_view()

    def mouseMoveEvent(self,e):
        if self._dragging:
            self._positions[self._dragging]=self._to_scene(e.position())+self._drag_offset; self.update()
        elif self._pan_start:
            delta=e.position()-self._pan_start; self._offset=self._pan_offset+delta; self.update()

    def mouseReleaseEvent(self,e):
        self._dragging=None; self._pan_start=None

    def _to_scene(self,pos):
        return QPointF((pos.x()-self._offset.x())/self._scale,(pos.y()-self._offset.y())/self._scale)

class GraphView(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.db=Database(); self._build_ui()

    def _build_ui(self):
        lay=QVBoxLayout(self); lay.setContentsMargins(0,0,0,0); lay.setSpacing(0)
        # Header
        h=QWidget(); h.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        hl=QHBoxLayout(h); hl.setContentsMargins(16,10,16,10)
        t=QLabel("🕸️ Graphe de corrélation"); f=QFont("Segoe UI",14); f.setBold(True); t.setFont(f)
        t.setStyleSheet("color:#EEF3FC;background:transparent;"); hl.addWidget(t); hl.addStretch()
        self.graph_combo=QComboBox(); self.graph_combo.setMinimumWidth(250)
        self.graph_combo.currentIndexChanged.connect(self._load_selected); hl.addWidget(self.graph_combo)
        btn_r=QPushButton("🔄 Actualiser"); btn_r.setObjectName("secondary"); btn_r.clicked.connect(self._refresh); hl.addWidget(btn_r)
        btn_f=QPushButton("⊡ Centrer"); btn_f.setObjectName("secondary"); btn_f.clicked.connect(lambda:self.canvas.fit_view()); hl.addWidget(btn_f)
        lay.addWidget(h)
        # Legend
        leg=QWidget(); leg.setStyleSheet("background:#0A0E17;border-bottom:1px solid #1A2A44;"); leg.setFixedHeight(32)
        ll=QHBoxLayout(leg); ll.setContentsMargins(16,4,16,4); ll.setSpacing(12)
        for ntype,color in list(NODE_COLORS.items())[:8]:
            dot=QLabel(f"● {ntype}"); dot.setStyleSheet(f"color:{color};background:transparent;font-size:10px;"); ll.addWidget(dot)
        ll.addStretch(); lay.addWidget(leg)
        self.canvas=GraphCanvas(); lay.addWidget(self.canvas,1)
        self.status=QLabel("Clic droit: centrer | Molette: zoom | Drag: deplacer nœuds")
        self.status.setStyleSheet("background:#0D1726;color:#8AA0B8;padding:4px 16px;font-size:10px;border-top:1px solid #1A2A44;"); self.status.setFixedHeight(24)
        lay.addWidget(self.status)
        self._refresh()

    def _refresh(self):
        self.graph_combo.clear(); self._graphs=self.db.get_graphs()
        for g in self._graphs: self.graph_combo.addItem(f"[{g['timestamp'][:16]}] {g['seed'][:40]}",g["id"])
        if self._graphs: self._load_selected(0)

    def _load_selected(self,idx):
        if idx<0 or idx>=len(self._graphs): return
        gid=self._graphs[idx]["id"]
        g=self.db.get_graph(gid)
        if not g: return
        self.canvas.clear()
        for n in g.get("nodes",[]): self.canvas.add_node(n)
        for e in g.get("edges",[]): self.canvas.add_edge(e)
        self.canvas.fit_view()
        self.status.setText(f"Graphe: {g['seed']} | {len(g['nodes'])} noeuds | {len(g['edges'])} connexions")

    def set_accent(self,c): pass
