from PyQt6.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView, QAbstractItemView, QMenu
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFont, QCursor
import re

class SnoopTable(QTableWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._ctx_menu)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.horizontalHeader().setStretchLastSection(True)
        self.verticalHeader().setVisible(False)
        self.verticalHeader().setDefaultSectionSize(30)
        self.setSortingEnabled(True)
        self.setShowGrid(False)
        self._raw = []

    def load(self, data):
        self._raw = data
        if not data: self.setRowCount(0); self.setColumnCount(0); return
        keys = list(data[0].keys()) if isinstance(data[0], dict) else ["Valeur"]
        self.setColumnCount(len(keys))
        self.setHorizontalHeaderLabels(keys)
        self.setRowCount(len(data))
        url_re = re.compile(r"^https?://")
        for row, item in enumerate(data):
            values = list(item.values()) if isinstance(item, dict) else [str(item)]
            for col, val in enumerate(values):
                v = str(val) if val is not None else ""
                cell = QTableWidgetItem(v)
                cell.setToolTip(v)
                if "✅" in v or "Trouve" in v and "Non" not in v:
                    cell.setForeground(QColor("#34D399"))
                elif "❌" in v or "Non" in v:
                    cell.setForeground(QColor("#8AA0B8"))
                elif "⚠️" in v or "DETECTE" in v:
                    cell.setForeground(QColor("#FBBF24"))
                elif "⚫" in v or "Erreur" in v:
                    cell.setForeground(QColor("#F87171"))
                elif url_re.match(v):
                    cell.setForeground(QColor("#A78BFA"))
                    f = cell.font(); f.setUnderline(True); cell.setFont(f)
                self.setItem(row, col, cell)
        self.resizeColumnsToContents()

    def _ctx_menu(self, pos):
        item = self.itemAt(pos)
        if not item: return
        menu = QMenu(self)
        menu.addAction("Copier la cellule", lambda: self._copy_cell(item))
        menu.addAction("Copier la ligne", lambda: self._copy_row(item.row()))
        v = item.text()
        if v.startswith("http"):
            import webbrowser
            menu.addAction("Ouvrir dans le navigateur", lambda: webbrowser.open(v))
        menu.exec(QCursor.pos())

    def _copy_cell(self, item):
        from PyQt6.QtWidgets import QApplication
        QApplication.clipboard().setText(item.text())

    def _copy_row(self, row):
        from PyQt6.QtWidgets import QApplication
        vals = [self.item(row, c).text() if self.item(row, c) else "" for c in range(self.columnCount())]
        QApplication.clipboard().setText(" | ".join(vals))

    def mouseDoubleClickEvent(self, e):
        item = self.currentItem()
        if item and item.text().startswith("http"):
            import webbrowser; webbrowser.open(item.text())
        super().mouseDoubleClickEvent(e)

    def filter(self, text):
        for row in range(self.rowCount()):
            match = not text or any(
                text.lower() in (self.item(row, c).text().lower() if self.item(row, c) else "")
                for c in range(self.columnCount()))
            self.setRowHidden(row, not match)
