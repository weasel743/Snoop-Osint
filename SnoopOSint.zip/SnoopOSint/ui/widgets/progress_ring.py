from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QRectF
from PyQt6.QtGui import QPainter, QPen, QColor, QFont

class ProgressRing(QWidget):
    def __init__(self, parent=None, size=60):
        super().__init__(parent)
        self._value = 0; self._max = 100
        self._accent = "#7C3AED"
        self.setFixedSize(size, size)

    def set_value(self, v, mx=100):
        self._value = v; self._max = mx; self.update()

    def set_accent(self, color):
        self._accent = color; self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w = self.width(); h = self.height()
        margin = 6
        rect = QRectF(margin, margin, w - 2*margin, h - 2*margin)
        # Background ring
        pen = QPen(QColor("#1A2A44"), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(pen); p.drawArc(rect, 0, 360*16)
        # Progress ring
        pct = self._value / max(self._max, 1)
        pen2 = QPen(QColor(self._accent), 5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        p.setPen(pen2)
        span = int(-pct * 360 * 16)
        p.drawArc(rect, 90*16, span)
        # Text
        p.setPen(QColor("#EEF3FC"))
        f = QFont(); f.setPointSize(9); f.setBold(True); p.setFont(f)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"{int(pct*100)}%")
