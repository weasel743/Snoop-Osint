from PyQt6.QtWidgets import QLabel, QWidget, QHBoxLayout
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QColor, QPalette

class Toast(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        self.label = QLabel()
        self.label.setStyleSheet("color: #EEF3FC; background: transparent; font-size: 12px;")
        lay.addWidget(self.label)
        self.setStyleSheet("background: #1A2A44; border: 1px solid #7C3AED; border-radius: 8px;")
        self._opacity = 1.0
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._fade_out)

    def show_message(self, msg, duration=3000, mtype="info"):
        colors = {"success":"#34D399","error":"#F87171","warning":"#FBBF24","info":"#A78BFA"}
        icons = {"success":"✅","error":"❌","warning":"⚠️","info":"ℹ️"}
        self.label.setText(f"{icons.get(mtype,'ℹ️')} {msg}")
        self.label.setStyleSheet(f"color:{colors.get(mtype,'#EEF3FC')};background:transparent;font-size:12px;font-weight:bold")
        self.adjustSize()
        if self.parent():
            p = self.parent()
            x = p.width() - self.width() - 20
            y = p.height() - self.height() - 20
            self.move(x, y)
        self.show()
        self.raise_()
        self._timer.start(duration)

    def _fade_out(self):
        self.hide()
