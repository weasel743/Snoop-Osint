import random,math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt,QTimer,QPointF
from PyQt6.QtGui import QPainter,QColor

class ParticlesAnimation(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self._accent="#7C3AED"; self._particles=[]
        self._timer=QTimer(self); self._timer.timeout.connect(self._update)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground,True)
    def set_accent(self,c): self._accent=c
    def start(self):
        self._spawn(); self._timer.start(33); self.show()
    def stop(self): self._timer.stop()
    def _spawn(self):
        w=max(self.width(),400); h=max(self.height(),300)
        for _ in range(40):
            self._particles.append({"x":random.uniform(0,w),"y":random.uniform(0,h),
                "vx":random.uniform(-0.3,0.3),"vy":random.uniform(-0.3,0.3),
                "r":random.uniform(1.5,4),"alpha":random.randint(60,180)})
    def _update(self):
        w=max(self.width(),400); h=max(self.height(),300)
        for p in self._particles:
            p["x"]=(p["x"]+p["vx"])%w; p["y"]=(p["y"]+p["vy"])%h
        self.update()
    def paintEvent(self,e):
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c=QColor(self._accent)
        for pt in self._particles:
            c.setAlpha(pt["alpha"]); p.setBrush(c); p.setPen(Qt.PenStyle.NoPen)
            p.drawEllipse(QPointF(pt["x"],pt["y"]),pt["r"],pt["r"])
