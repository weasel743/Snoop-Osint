from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QColor

class BaseAnimation(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self._accent="#7C3AED"; self._running=False
        self._timer=QTimer(self); self._timer.timeout.connect(self._tick)
        self.setAttribute(0x01,True)  # WA_OpaquePaintEvent

    def set_accent(self,color): self._accent=color; self.update()
    def start(self): self._running=True; self._timer.start(50); self.show()
    def stop(self): self._running=False; self._timer.stop(); self.hide()
    def _tick(self): self.update()
