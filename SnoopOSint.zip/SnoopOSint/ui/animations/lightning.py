import random,math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt,QTimer,QPointF
from PyQt6.QtGui import QPainter,QPen,QColor

class LightningAnimation(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self._accent="#7C3AED"; self._bolts=[]; self._timer=QTimer(self)
        self._timer.timeout.connect(self._update); self._frame=0
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground,True)
    def set_accent(self,c): self._accent=c
    def start(self): self._timer.start(80); self.show()
    def stop(self): self._timer.stop()
    def _update(self):
        self._frame+=1
        if self._frame%3==0: self._gen_bolt()
        self._bolts=[b for b in self._bolts if b["life"]>0]
        for b in self._bolts: b["life"]-=1
        self.update()
    def _gen_bolt(self):
        if not self.isVisible(): return
        w=self.width(); h=self.height()
        if w<10 or h<10: return
        x=random.randint(0,w); pts=[QPointF(x,0)]
        y=0
        while y<h:
            x+=random.randint(-30,30); y+=random.randint(10,30)
            pts.append(QPointF(max(0,min(w,x)),y))
        self._bolts.append({"points":pts,"life":random.randint(3,8),"alpha":random.randint(80,180)})
    def paintEvent(self,e):
        if not self._bolts: return
        p=QPainter(self); p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c=QColor(self._accent)
        for b in self._bolts:
            pts=b["points"]
            alpha=int(b["alpha"]*(b["life"]/8))
            c.setAlpha(alpha); pen=QPen(c,1); p.setPen(pen)
            for i in range(len(pts)-1): p.drawLine(pts[i],pts[i+1])
