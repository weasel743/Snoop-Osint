from PyQt6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QLineEdit, QStackedWidget, QSplitter, QFrame,
    QScrollArea, QApplication, QSizePolicy)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QColor, QIcon

from core.config_manager import ConfigManager
from core.language_manager import LanguageManager
from core.theme_manager import ThemeManager
from ui.widgets.toast import Toast

# Import all views
from ui.views.dashboard_view import DashboardView
from ui.views.correlation_view import CorrelationView
from ui.views.username_view import UsernameView
from ui.views.email_view import EmailView
from ui.views.phone_view import PhoneView
from ui.views.ip_view import IPView
from ui.views.domain_view import DomainView
from ui.views.image_view import ImageView
from ui.views.metadata_view import MetadataView
from ui.views.social_view import SocialView
from ui.views.crypto_view import CryptoView
from ui.views.geo_view import GeoView
from ui.views.breach_view import BreachView
from ui.views.paste_view import PasteView
from ui.views.wayback_view import WaybackView
from ui.views.portscan_view import PortScanView
from ui.views.dorking_view import DorkingView
from ui.views.shodan_view import ShodanView
from ui.views.bodacc_view import BodaccView
from ui.views.infogreffe_view import InfogreffeView
from ui.views.pagesjaunes_view import PagesJaunesView
from ui.views.datafr_view import DataFrView
from ui.views.graph_view import GraphView
from ui.views.timeline_view import TimelineView
from ui.views.batch_view import BatchView
from ui.views.history_view import HistoryView
from ui.views.settings_view import SettingsView

SIDEBAR_ITEMS = [
    ("nav_dashboard","🏠","Tableau de bord","dashboard",None),
    ("nav_correlation","🔗","Corrélation","correlation",None),
    ("sep1","SEP","RECHERCHE","",None),
    ("nav_username","👤","Username","username",None),
    ("nav_email","📧","Email","email",None),
    ("nav_phone","📱","Téléphone","phone",None),
    ("nav_ip","🌐","Adresse IP","ip",None),
    ("nav_domain","🏠","Domaine","domain",None),
    ("sep2","SEP","ANALYSE","",None),
    ("nav_image","🖼️","Image EXIF","image",None),
    ("nav_metadata","📄","Métadonnées","metadata",None),
    ("nav_social","🐙","GitHub","social",None),
    ("nav_crypto","₿","Crypto","crypto",None),
    ("nav_geo","🌍","Géolocalisation","geo",None),
    ("sep3","SEP","AVANCÉ","",None),
    ("nav_breach","🔓","Fuites","breach",None),
    ("nav_paste","📋","Paste Sites","paste",None),
    ("nav_wayback","🕰️","Wayback Machine","wayback",None),
    ("nav_portscan","🔌","Port Scanner","portscan",None),
    ("nav_dorking","🔍","Dorking","dorking",None),
    ("nav_shodan","🛡️","Shodan","shodan",None),
    ("sep4","SEP","🇫🇷 FRANCE","",None),
    ("nav_bodacc","🏛️","BODACC","bodacc",None),
    ("nav_infogreffe","📋","Infogreffe","infogreffe",None),
    ("nav_pagesjaunes","📒","Pages Jaunes","pagesjaunes",None),
    ("nav_datafr","🇫🇷","Data.gouv.fr","datafr",None),
    ("sep5","SEP","OUTILS","",None),
    ("nav_graph","🕸️","Graphe","graph",None),
    ("nav_timeline","📅","Timeline","timeline",None),
    ("nav_batch","📦","Batch","batch",None),
    ("nav_history","📋","Historique","history",None),
    ("nav_settings","⚙️","Paramètres","settings",None),
]

class SidebarButton(QPushButton):
    def __init__(self, icon, label, mid, parent=None):
        super().__init__(parent)
        self.mid = mid; self._active = False
        self.setFixedHeight(38); self.setCheckable(True)
        self.setText(f"  {icon}  {label}")
        self.setStyleSheet(self._style(False))

    def _style(self, active):
        if active:
            return """QPushButton{background:rgba(124,58,237,0.18);color:#EEF3FC;border:none;border-radius:6px;
                text-align:left;padding-left:8px;font-size:10pt;border-left:3px solid #7C3AED}
                QPushButton:hover{background:rgba(124,58,237,0.25)}"""
        return """QPushButton{background:transparent;color:#8AA0B8;border:none;border-radius:6px;
                text-align:left;padding-left:8px;font-size:10pt}
                QPushButton:hover{background:rgba(255,255,255,0.05);color:#C8D8EC}"""

    def set_active(self, v):
        self._active = v
        self.setChecked(v)
        self.setStyleSheet(self._style(v))

class MainWindow(QMainWindow):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self.cfg = ConfigManager()
        self.lang = LanguageManager()
        self.theme_mgr = ThemeManager()
        self._views = {}
        self._nav_btns = {}
        self._current = "dashboard"
        self.toast = Toast(self)
        self._build()
        self._apply_window_settings()
        self.lang.register(self._on_lang_change)

    def _build(self):
        self.setWindowTitle("⚡ Snoop OSINT v1.0.0")
        central = QWidget(); self.setCentralWidget(central)
        main_lay = QHBoxLayout(central); main_lay.setContentsMargins(0,0,0,0); main_lay.setSpacing(0)
        # Sidebar
        sidebar = self._build_sidebar()
        main_lay.addWidget(sidebar)
        # Main content
        right = QWidget()
        right_lay = QVBoxLayout(right); right_lay.setContentsMargins(0,0,0,0); right_lay.setSpacing(0)
        # Top bar
        topbar = self._build_topbar()
        right_lay.addWidget(topbar)
        # Stack
        self.stack = QStackedWidget()
        right_lay.addWidget(self.stack, 1)
        main_lay.addWidget(right, 1)
        # Create all views
        self._register_views()
        # Navigate to dashboard
        self.navigate("dashboard")

    def _build_sidebar(self):
        sb = QWidget(); sb.setFixedWidth(210)
        sb.setStyleSheet("background:#0D1726;border-right:1px solid #1A2A44;")
        lay = QVBoxLayout(sb); lay.setContentsMargins(8,0,8,8); lay.setSpacing(0)
        # Logo
        logo_w = QWidget(); logo_w.setFixedHeight(56)
        logo_lay = QHBoxLayout(logo_w); logo_lay.setContentsMargins(10,0,10,0)
        logo = QLabel("⚡ Snoop OSINT")
        f = QFont("Segoe UI", 12); f.setBold(True); logo.setFont(f)
        logo.setStyleSheet("color:#7C3AED;background:transparent;")
        logo_lay.addWidget(logo); lay.addWidget(logo_w)
        ver = QLabel("v1.0.0"); ver.setStyleSheet("color:#2A3A50;font-size:9px;background:transparent;padding-left:12px;")
        lay.addWidget(ver)
        # Scroll area for nav items
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent}QScrollBar{width:3px}")
        nav_w = QWidget(); nav_w.setStyleSheet("background:transparent;")
        nav_lay = QVBoxLayout(nav_w); nav_lay.setContentsMargins(0,4,0,4); nav_lay.setSpacing(1)
        for item_id, icon, label, mid, _ in SIDEBAR_ITEMS:
            if icon == "SEP":
                sep_lbl = QLabel(label)
                sep_lbl.setStyleSheet("color:#2A3A50;font-size:8px;font-weight:bold;padding:10px 10px 2px;background:transparent;letter-spacing:2px;")
                nav_lay.addWidget(sep_lbl)
            else:
                btn = SidebarButton(icon, label, mid)
                btn.clicked.connect(lambda _, m=mid: self.navigate(m))
                self._nav_btns[mid] = btn
                nav_lay.addWidget(btn)
        nav_lay.addStretch()
        scroll.setWidget(nav_w); lay.addWidget(scroll, 1)
        return sb

    def _build_topbar(self):
        tb = QWidget(); tb.setFixedHeight(48)
        tb.setStyleSheet("background:#0A0E17;border-bottom:1px solid #1A2A44;")
        lay = QHBoxLayout(tb); lay.setContentsMargins(16,6,16,6); lay.setSpacing(8)
        # Global search
        self.global_search = QLineEdit()
        self.global_search.setPlaceholderText("🔍 Recherche globale — email, IP, username, domaine...")
        self.global_search.setMinimumHeight(30)
        self.global_search.setMaximumWidth(500)
        self.global_search.setStyleSheet("QLineEdit{background:#0D1726;border:1px solid #1A2A44;border-radius:15px;padding:4px 14px;color:#8AA0B8}QLineEdit:focus{border:1px solid #7C3AED;color:#EEF3FC}")
        self.global_search.returnPressed.connect(self._global_search)
        lay.addWidget(self.global_search); lay.addStretch()
        # Theme switcher
        theme_lbl = QLabel("Thème:"); theme_lbl.setStyleSheet("color:#4A5C70;font-size:10px;background:transparent;")
        lay.addWidget(theme_lbl)
        from PyQt6.QtWidgets import QComboBox
        self.theme_combo = QComboBox(); self.theme_combo.setMaximumWidth(80); self.theme_combo.setMaximumHeight(28)
        for name in self.cfg.themes: self.theme_combo.addItem(name)
        self.theme_combo.setCurrentText(self.cfg.get("app","theme",default="violet"))
        self.theme_combo.currentTextChanged.connect(self._change_theme)
        lay.addWidget(self.theme_combo)
        # Language
        from PyQt6.QtWidgets import QComboBox
        lang_lbl = QLabel("Langue:"); lang_lbl.setStyleSheet("color:#4A5C70;font-size:10px;background:transparent;"); lay.addWidget(lang_lbl)
        self.lang_combo = QComboBox(); self.lang_combo.setMaximumWidth(80); self.lang_combo.setMaximumHeight(28)
        for code,name in self.lang.get_languages().items(): self.lang_combo.addItem(name,code)
        self.lang_combo.setCurrentIndex(list(self.lang.get_languages().keys()).index(self.lang.current))
        self.lang_combo.currentIndexChanged.connect(lambda i: self.lang.switch(self.lang_combo.itemData(i)))
        lay.addWidget(self.lang_combo)
        return tb

    def _register_views(self):
        view_classes = {
            "dashboard": DashboardView,
            "correlation": CorrelationView,
            "username": UsernameView,
            "email": EmailView,
            "phone": PhoneView,
            "ip": IPView,
            "domain": DomainView,
            "image": ImageView,
            "metadata": MetadataView,
            "social": SocialView,
            "crypto": CryptoView,
            "geo": GeoView,
            "breach": BreachView,
            "paste": PasteView,
            "wayback": WaybackView,
            "portscan": PortScanView,
            "dorking": DorkingView,
            "shodan": ShodanView,
            "bodacc": BodaccView,
            "infogreffe": InfogreffeView,
            "pagesjaunes": PagesJaunesView,
            "datafr": DataFrView,
            "graph": GraphView,
            "timeline": TimelineView,
            "batch": BatchView,
            "history": HistoryView,
            "settings": SettingsView,
        }
        for mid, cls in view_classes.items():
            try:
                view = cls()
                # Connect special signals
                if hasattr(view, "navigate_to"):
                    view.navigate_to.connect(self.navigate)
                if hasattr(view, "theme_changed"):
                    view.theme_changed.connect(self._change_theme)
                if hasattr(view, "language_changed"):
                    view.language_changed.connect(self.lang.switch)
                self._views[mid] = view
                self.stack.addWidget(view)
            except Exception as e:
                # Fallback placeholder
                placeholder = QLabel(f"Module {mid}\n\nErreur: {e}")
                placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
                placeholder.setStyleSheet("color:#F87171;font-size:13px;")
                self._views[mid] = placeholder
                self.stack.addWidget(placeholder)

        # Apply current accent to all views
        theme = self.cfg.get_theme()
        accent = theme.get("accent","#7C3AED")
        for v in self._views.values():
            if hasattr(v, "set_accent"):
                try: v.set_accent(accent)
                except: pass

    def navigate(self, mid):
        if mid not in self._views: return
        # Deactivate current
        if self._current in self._nav_btns:
            self._nav_btns[self._current].set_active(False)
        self._current = mid
        if mid in self._nav_btns:
            self._nav_btns[mid].set_active(True)
        view = self._views[mid]
        self.stack.setCurrentWidget(view)

    def _global_search(self):
        query = self.global_search.text().strip()
        if not query: return
        from modules.correlation.engine import detect_type
        detected = detect_type(query)
        module_map = {"email":"email","ip":"ip","domain":"domain","phone":"phone",
                      "username":"username","btc":"crypto","eth":"crypto","url":"domain"}
        target = module_map.get(detected, "username")
        self.navigate(target)
        view = self._views.get(target)
        if view and hasattr(view, "set_query"):
            QTimer.singleShot(100, lambda: view.set_query(query))
        self.global_search.clear()

    def _change_theme(self, name):
        self.theme_mgr.apply(self.app, name)
        theme = self.cfg.get_theme(name)
        accent = theme.get("accent","#7C3AED")
        for v in self._views.values():
            if hasattr(v, "set_accent"):
                try: v.set_accent(accent)
                except: pass
        if self.theme_combo.currentText() != name:
            self.theme_combo.blockSignals(True)
            self.theme_combo.setCurrentText(name)
            self.theme_combo.blockSignals(False)
        self.toast.show_message(f"Thème: {name}","info")

    def _on_lang_change(self):
        self.toast.show_message("Langue changée. Redémarrez pour appliquer.","info")

    def _apply_window_settings(self):
        w = self.cfg.get("ui","window","width",default=1400)
        h = self.cfg.get("ui","window","height",default=850)
        self.resize(w, h)
        if self.cfg.get("ui","window","maximized",default=False):
            self.showMaximized()

    def closeEvent(self, e):
        self.cfg.set(self.width(),"ui","window","width")
        self.cfg.set(self.height(),"ui","window","height")
        self.cfg.set(self.isMaximized(),"ui","window","maximized")
        self.cfg.save(); super().closeEvent(e)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if hasattr(self,"toast"):
            self.toast.move(self.width()-self.toast.width()-20, self.height()-self.toast.height()-20)
