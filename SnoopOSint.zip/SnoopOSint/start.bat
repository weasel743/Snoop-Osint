@echo off
chcp 65001 >nul 2>&1
title Snoop OSINT v1.0.0
cd /d "%~dp0"

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERREUR] Python non trouve. Lancez d'abord install.bat
    pause
    exit /b 1
)

python main.py
if %errorlevel% neq 0 (
    echo.
    echo [ERREUR] L'application a plante.
    echo Lancez install.bat pour reinstaller les dependances.
    echo.
    pause
)
