@echo off
title Snoop OSINT
color 0D
echo.
echo  ⚡  Demarrage de Snoop OSINT...
echo.
python main.py
