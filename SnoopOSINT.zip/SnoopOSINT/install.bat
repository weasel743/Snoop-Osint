@echo off
title Snoop OSINT - Installation
color 0D

echo.
echo  ╔══════════════════════════════════════╗
echo  ║       ⚡  SNOOP OSINT  v3.0.0        ║
echo  ║           Installation               ║
echo  ╚══════════════════════════════════════╝
echo.

echo [1/3] Verification de Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo  ❌ Python non trouve.
    echo  👉 Telecharge Python sur https://python.org
    echo     et coche "Add Python to PATH" pendant l'installation.
    pause
    exit
)
echo  ✅ Python detecte.
echo.

echo [2/3] Mise a jour de pip...
python -m pip install --upgrade pip --quiet
echo  ✅ pip a jour.
echo.

echo [3/3] Installation des dependances...
pip install -r requirements.txt
echo.

echo  ╔══════════════════════════════════════╗
echo  ║      ✅  Installation terminee !     ║
echo  ║      Lance start.bat pour demarrer   ║
echo  ╚══════════════════════════════════════╝
echo.
pause
