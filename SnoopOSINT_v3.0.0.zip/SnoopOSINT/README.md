# ⚡ Snoop OSINT v3

![Version](https://img.shields.io/badge/version-3.0.0-7C3AED?style=flat-square)
![Python](https://img.shields.io/badge/python-3.10%2B-blue?style=flat-square)
![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)
![API Keys](https://img.shields.io/badge/clefs%20API-0%20requises-34D399?style=flat-square)

> **L'outil OSINT open source avec corrélation automatique et sources françaises officielles.**

## 🆕 Ce qui est unique dans Snoop OSINT v3

| Fonctionnalité | Autres outils | Snoop OSINT v3 |
|---|---|---|
| Corrélation automatique | ❌ | ✅ |
| Vue graphe interactive | ❌ gratuit | ✅ |
| Sources françaises (BODACC, Infogreffe) | ❌ | ✅ |
| Timeline automatique | ❌ | ✅ |
| Interface GUI moderne | Maltego (1000€/an) | ✅ Gratuit |
| 0 clef API requise | Partiel | ✅ Total |

## 🚀 Installation

```bash
git clone https://github.com/votre-repo/snoop-osint.git
cd snoop-osint
pip install -r requirements.txt
python main.py
```

## 📦 Modules

**Recherche** : Username (50+ sites), Email (9 checkers), Téléphone, IP, Domaine

**Analyse** : EXIF/Métadonnées, GitHub, Crypto BTC/ETH, Fuites, Paste Sites, Port Scan, DNS, SSL, Dorking, Shodan

**France** : BODACC, Infogreffe, Pages Jaunes, Data.gouv.fr

**Outils** : Corrélation auto, Graphe interactif, Timeline, Batch, Historique, Plugins

## ⚠️ Usage légal uniquement

Cet outil est destiné à la recherche OSINT légale et éthique. Utilisez-le uniquement sur des cibles que vous êtes autorisé à analyser.

## 📄 License MIT
