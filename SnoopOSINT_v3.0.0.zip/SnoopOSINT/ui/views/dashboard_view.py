from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout, QPushButton
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from core.database import Database

class StatCard(QFrame):
    def __init__(self, icon, label, value, color="#7C3AED", parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"QFrame{{background:#0D1726;border:1px solid #1A2A44;border-radius:8px;}}")
        l = QVBoxLayout(self); l.setContentsMargins(16,12,16,12)
        l.addWidget(QLabel(icon, styleSheet="font-size:20px;background:transparent;"))
        self._v = QLabel(str(value), styleSheet=f"font-size:20pt;font-weight:900;color:{color};background:transparent;")
        l.addWidget(self._v)
        l.addWidget(QLabel(label, styleSheet="color:#8AA0B8;font-size:9pt;background:transparent;"))
    def set_value(self, v): self._v.setText(str(v))

class DashboardView(QWidget):
    navigate = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.db = Database(); self._setup_ui()
        QTimer.singleShot(200, self._refresh)
    def _setup_ui(self):
        l = QVBoxLayout(self); l.setContentsMargins(24,20,24,20); l.setSpacing(18)
        hero = QLabel("⚡ Snoop OSINT")
        hero.setStyleSheet("font-size:26pt;font-weight:900;color:#7C3AED;background:transparent;letter-spacing:2px;")
        l.addWidget(hero)
        sub = QLabel("Corrélation automatique • Sources françaises officielles • 0 clef API requise • Open Source")
        sub.setStyleSheet("color:#8AA0B8;font-size:10pt;background:transparent;")
        l.addWidget(sub)
        # Stats
        g = QGridLayout(); g.setSpacing(10)
        self._cards = {}
        for i,(k,ic,lb,v,c) in enumerate([
            ("total","🔍","Recherches","0","#7C3AED"),
            ("modules","🧩","Modules","30+","#34D399"),
            ("nokey","🔑","Clefs requises","0","#FBBF24"),
            ("graphs","🕸️","Graphes sauvés","0","#60A5FA")]):
            card = StatCard(ic,lb,v,c); g.addWidget(card,0,i); self._cards[k] = card
        l.addLayout(g)
        # Quick access
        ql = QLabel("🚀 Accès rapide"); ql.setStyleSheet("font-size:12pt;font-weight:bold;color:#EEF3FC;background:transparent;")
        l.addWidget(ql)
        qg = QGridLayout(); qg.setSpacing(6)
        modules = [
            ("🔗","Corrélation","correlation"),("👤","Username","username"),
            ("📧","Email","email"),("📱","Téléphone","phone"),
            ("🌐","IP","ip"),("🌐","Domaine","domain"),
            ("🔓","Fuites","breach"),("📋","Paste Sites","paste"),
            ("🏛️","BODACC","bodacc"),("📋","Infogreffe","infogreffe"),
            ("📒","Pages Jaunes","pagesjaunes"),("🇫🇷","Data.gouv","datafr"),
            ("🐙","GitHub","social"),("₿","Crypto","crypto"),
            ("🔌","Port Scan","portscan"),("📦","Batch","batch"),
        ]
        for i,(ic,lb,vid) in enumerate(modules):
            b = QPushButton(f"{ic}\n{lb}")
            b.setFixedHeight(54)
            b.setStyleSheet("QPushButton{background:#0D1726;border:1px solid #1A2A44;border-radius:8px;color:#8AA0B8;font-size:9pt}QPushButton:hover{background:rgba(124,58,237,0.15);border:1px solid #7C3AED;color:#EEF3FC}")
            b.clicked.connect(lambda _,v=vid: self.navigate.emit(v)); qg.addWidget(b,i//4,i%4)
        l.addLayout(qg)
        info = QLabel("✨ Nouveau dans v3 : moteur de corrélation automatique, sources françaises (BODACC, Infogreffe, Pages Jaunes, Data.gouv.fr), vue graphe interactive, timeline automatique")
        info.setWordWrap(True)
        info.setStyleSheet("background:rgba(124,58,237,0.1);border:1px solid rgba(124,58,237,0.3);border-radius:8px;padding:12px;color:#A78BFA;font-size:9pt;")
        l.addWidget(info); l.addStretch()
    def _refresh(self):
        try:
            s = self.db.get_stats(); self._cards["total"].set_value(s["total"])
            graphs = self.db.get_graphs(limit=100); self._cards["graphs"].set_value(len(graphs))
        except: pass
    def showEvent(self, e): super().showEvent(e); self._refresh()
