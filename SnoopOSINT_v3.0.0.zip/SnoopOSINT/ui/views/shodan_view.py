from ui.views.base_view import BaseView, WorkerThread
import requests

HEADERS = {"User-Agent": "Mozilla/5.0"}

def search_shodan(query, api_key="", timeout=10):
    results = []
    if api_key:
        try:
            resp = requests.get("https://api.shodan.io/shodan/host/search",
                params={"key": api_key, "query": query, "limit": 20},
                headers=HEADERS, timeout=timeout)
            if resp.status_code == 200:
                data = resp.json()
                for m in data.get("matches", []):
                    results.append({
                        "IP": m.get("ip_str",""),
                        "Port": str(m.get("port","")),
                        "Organisation": m.get("org",""),
                        "OS": m.get("os",""),
                        "Pays": m.get("location",{}).get("country_name",""),
                        "Banner": (m.get("data","") or "")[:80]
                    })
        except Exception as e:
            results.append({"IP":"Erreur","Port":"","Organisation":str(e),"OS":"","Pays":"","Banner":""})
    else:
        results.append({"IP":"Clef Shodan requise","Port":"","Organisation":"Ajoutez votre clef dans Paramètres",
            "OS":"","Pays":"","Banner":"Gratuit sur shodan.io"})
        try:
            resp = requests.get(f"https://internetdb.shodan.io/{query}", headers=HEADERS, timeout=timeout)
            if resp.status_code == 200:
                d = resp.json()
                for port in d.get("ports", []):
                    results.append({"IP":query,"Port":str(port),"Organisation":d.get("hostnames",[""])[0] if d.get("hostnames") else "",
                        "OS":"","Pays":"","Banner":""})
                for cpe in d.get("cpes",[])[:5]:
                    results.append({"IP":query,"Port":"CPE","Organisation":cpe,"OS":"","Pays":"","Banner":""})
                for vuln in d.get("vulns",[])[:5]:
                    results.append({"IP":query,"Port":"VULN","Organisation":vuln,"OS":"","Pays":"🔴 CVE","Banner":""})
        except Exception:
            pass
    return results

class ShodanView(BaseView):
    MODULE_NAME = "shodan"
    TITLE = "Shodan"
    ICON = "🛡️"
    COLUMNS = ["IP", "Port", "Organisation", "OS", "Pays", "Banner"]
    PLACEHOLDER = "ex: 8.8.8.8 ou apache"

    def _run(self, query):
        api_key = self.cfg.get("api_keys", "shodan", default="")
        self._worker = WorkerThread(search_shodan, query, api_key=api_key, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
