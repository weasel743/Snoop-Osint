from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QLineEdit, QPushButton, QComboBox, QCheckBox,
                              QSlider, QGroupBox, QScrollArea, QColorDialog,
                              QSpinBox, QTabWidget, QFrame)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor
from core.config_manager import ConfigManager
from core.language_manager import LanguageManager, AVAILABLE_LANGUAGES
from core.theme_manager import ThemeManager
from ui.widgets.toast import show_toast


class SettingsView(QWidget):
    theme_changed = pyqtSignal(str)
    language_changed = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cfg = ConfigManager()
        self.lang = LanguageManager()
        self.theme_mgr = ThemeManager()
        self._setup_ui()

    def _setup_ui(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(20, 16, 20, 16)
        outer.setSpacing(12)

        title = QLabel("⚙️ Paramètres")
        title.setStyleSheet("font-size: 15pt; font-weight: bold; color: #EEF3FC; background: transparent;")
        outer.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        layout = QVBoxLayout(container)
        layout.setSpacing(16)

        # --- Apparence ---
        grp_appear = QGroupBox("🎨 Apparence")
        appear_layout = QVBoxLayout(grp_appear)

        row = QHBoxLayout()
        row.addWidget(QLabel("Thème:"))
        self.theme_combo = QComboBox()
        themes = ["violet","blue","green","red","orange","cyan","pink","gold","matrix","light"]
        for t in themes:
            self.theme_combo.addItem(t.capitalize(), t)
        current = self.cfg.get("app", "theme", default="violet")
        for i in range(self.theme_combo.count()):
            if self.theme_combo.itemData(i) == current:
                self.theme_combo.setCurrentIndex(i)
                break
        self.theme_combo.currentIndexChanged.connect(self._apply_theme)
        row.addWidget(self.theme_combo)
        btn_custom = QPushButton("🎨 Thème custom")
        btn_custom.setObjectName("secondary")
        btn_custom.clicked.connect(self._custom_theme)
        row.addWidget(btn_custom)
        row.addStretch()
        appear_layout.addLayout(row)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Langue:"))
        self.lang_combo = QComboBox()
        for code, name in AVAILABLE_LANGUAGES.items():
            self.lang_combo.addItem(name, code)
        cur_lang = self.cfg.get_language()
        for i in range(self.lang_combo.count()):
            if self.lang_combo.itemData(i) == cur_lang:
                self.lang_combo.setCurrentIndex(i)
                break
        self.lang_combo.currentIndexChanged.connect(self._apply_lang)
        row2.addWidget(self.lang_combo)
        row2.addStretch()
        appear_layout.addLayout(row2)

        row3 = QHBoxLayout()
        row3.addWidget(QLabel("Taille police:"))
        self.font_spin = QSpinBox()
        self.font_spin.setRange(8, 18)
        self.font_spin.setValue(self.cfg.get("ui", "font_size", default=10))
        row3.addWidget(self.font_spin)
        row3.addStretch()
        appear_layout.addLayout(row3)

        layout.addWidget(grp_appear)

        # --- Animations ---
        grp_anim = QGroupBox("✨ Animations")
        anim_layout = QVBoxLayout(grp_anim)

        row_anim = QHBoxLayout()
        self.anim_enabled = QCheckBox("Activer les animations")
        self.anim_enabled.setChecked(self.cfg.get("ui", "animation", "enabled", default=True))
        row_anim.addWidget(self.anim_enabled)
        row_anim.addStretch()
        anim_layout.addLayout(row_anim)

        row_type = QHBoxLayout()
        row_type.addWidget(QLabel("Type:"))
        self.anim_type = QComboBox()
        for t in ["lightning","matrix","particles","neural","grid","waves","gradient"]:
            self.anim_type.addItem(t.capitalize(), t)
        cur_type = self.cfg.get("ui", "animation", "type", default="lightning")
        for i in range(self.anim_type.count()):
            if self.anim_type.itemData(i) == cur_type:
                self.anim_type.setCurrentIndex(i)
                break
        row_type.addWidget(self.anim_type)
        row_type.addStretch()
        anim_layout.addLayout(row_type)

        row_speed = QHBoxLayout()
        row_speed.addWidget(QLabel("Vitesse:"))
        self.anim_speed = QSlider(Qt.Orientation.Horizontal)
        self.anim_speed.setRange(1, 20)
        self.anim_speed.setValue(int(self.cfg.get("ui", "animation", "speed", default=1.0) * 10))
        row_speed.addWidget(self.anim_speed)
        self.speed_lbl = QLabel(f"{self.anim_speed.value()/10:.1f}x")
        self.anim_speed.valueChanged.connect(lambda v: self.speed_lbl.setText(f"{v/10:.1f}x"))
        row_speed.addWidget(self.speed_lbl)
        row_speed.addStretch()
        anim_layout.addLayout(row_speed)

        row_int = QHBoxLayout()
        row_int.addWidget(QLabel("Intensité:"))
        self.anim_intensity = QSlider(Qt.Orientation.Horizontal)
        self.anim_intensity.setRange(1, 10)
        self.anim_intensity.setValue(int(self.cfg.get("ui", "animation", "intensity", default=0.7) * 10))
        row_int.addWidget(self.anim_intensity)
        self.int_lbl = QLabel(f"{self.anim_intensity.value()/10:.1f}")
        self.anim_intensity.valueChanged.connect(lambda v: self.int_lbl.setText(f"{v/10:.1f}"))
        row_int.addWidget(self.int_lbl)
        row_int.addStretch()
        anim_layout.addLayout(row_int)

        layout.addWidget(grp_anim)

        # --- Recherche ---
        grp_search = QGroupBox("🔍 Recherche")
        search_layout = QVBoxLayout(grp_search)

        row_t = QHBoxLayout()
        row_t.addWidget(QLabel("Timeout (secondes):"))
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(3, 120)
        self.timeout_spin.setValue(self.cfg.get("search", "timeout", default=15))
        row_t.addWidget(self.timeout_spin)
        row_t.addStretch()
        search_layout.addLayout(row_t)

        row_th = QHBoxLayout()
        row_th.addWidget(QLabel("Threads max:"))
        self.threads_spin = QSpinBox()
        self.threads_spin.setRange(1, 100)
        self.threads_spin.setValue(self.cfg.get("search", "max_threads", default=50))
        row_th.addWidget(self.threads_spin)
        row_th.addStretch()
        search_layout.addLayout(row_th)

        self.auto_history = QCheckBox("Sauvegarder l'historique automatiquement")
        self.auto_history.setChecked(self.cfg.get("search", "auto_save_history", default=True))
        search_layout.addWidget(self.auto_history)

        self.toast_notifs = QCheckBox("Notifications toast")
        self.toast_notifs.setChecked(self.cfg.get("ui", "toast_notifications", default=True))
        search_layout.addWidget(self.toast_notifs)

        layout.addWidget(grp_search)

        # --- API Keys ---
        grp_api = QGroupBox("🔑 Clefs API (optionnelles)")
        api_layout = QVBoxLayout(grp_api)
        self._api_fields = {}
        api_keys_info = [
            ("shodan", "Shodan", "https://shodan.io — clef gratuite disponible"),
            ("virustotal", "VirusTotal", "https://virustotal.com — clef API gratuite"),
            ("hibp", "HIBP", "https://haveibeenpwned.com — payant (optionnel)"),
            ("hunter", "Hunter.io", "https://hunter.io — clef gratuite disponible"),
        ]
        for key, label, hint in api_keys_info:
            row_api = QHBoxLayout()
            row_api.addWidget(QLabel(f"{label}:"))
            field = QLineEdit()
            field.setEchoMode(QLineEdit.EchoMode.Password)
            field.setText(self.cfg.get("api_keys", key, default=""))
            field.setPlaceholderText(hint)
            self._api_fields[key] = field
            row_api.addWidget(field)
            eye_btn = QPushButton("👁")
            eye_btn.setFixedWidth(32)
            eye_btn.setObjectName("secondary")
            eye_btn.clicked.connect(lambda _, f=field: f.setEchoMode(
                QLineEdit.EchoMode.Normal if f.echoMode() == QLineEdit.EchoMode.Password
                else QLineEdit.EchoMode.Password
            ))
            row_api.addWidget(eye_btn)
            api_layout.addLayout(row_api)
        layout.addWidget(grp_api)

        # --- Proxy ---
        grp_proxy = QGroupBox("🔌 Proxy")
        proxy_layout = QVBoxLayout(grp_proxy)
        self.proxy_enabled = QCheckBox("Activer le proxy")
        self.proxy_enabled.setChecked(self.cfg.get("proxy", "enabled", default=False))
        proxy_layout.addWidget(self.proxy_enabled)
        for key, label in [("http", "HTTP"), ("https", "HTTPS"), ("socks5", "SOCKS5")]:
            row_px = QHBoxLayout()
            row_px.addWidget(QLabel(f"{label}:"))
            field = QLineEdit()
            field.setPlaceholderText(f"ex: {label.lower()}://127.0.0.1:8080")
            field.setText(self.cfg.get("proxy", key, default=""))
            setattr(self, f"proxy_{key}", field)
            row_px.addWidget(field)
            proxy_layout.addLayout(row_px)
        layout.addWidget(grp_proxy)

        layout.addStretch()
        scroll.setWidget(container)
        outer.addWidget(scroll, 1)

        # Boutons bas
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        btn_reset = QPushButton("↺ Réinitialiser")
        btn_reset.setObjectName("secondary")
        btn_reset.clicked.connect(self._reset)
        btn_row.addWidget(btn_reset)
        btn_save = QPushButton("💾 Sauvegarder")
        btn_save.clicked.connect(self._save)
        btn_row.addWidget(btn_save)
        outer.addLayout(btn_row)

    def _apply_theme(self, idx):
        t = self.theme_combo.itemData(idx)
        self.theme_changed.emit(t)

    def _apply_lang(self, idx):
        code = self.lang_combo.itemData(idx)
        self.lang.switch(code)
        self.language_changed.emit(code)

    def _custom_theme(self):
        color = QColorDialog.getColor(QColor("#7C3AED"), self, "Choisir la couleur accent")
        if color.isValid():
            hex_color = color.name()
            self.cfg.set({"name": "Custom", "accent": hex_color,
                          "accent_hover": hex_color, "accent_light": hex_color,
                          "bg_primary": "#0A0E17", "bg_secondary": "#0D1726",
                          "bg_card": "#0D1726", "border": "#1A2A44",
                          "text_primary": "#EEF3FC", "text_secondary": "#8AA0B8",
                          "success": "#34D399", "warning": "#FBBF24", "danger": "#F87171"},
                         "themes", "custom")
            self.cfg.set("custom", "app", "theme")
            self.cfg.save()
            from PyQt6.QtWidgets import QApplication
            app = QApplication.instance()
            if app:
                self.theme_mgr.apply_theme(app, "custom")
            show_toast(self.window(), f"Thème custom: {hex_color}", "success")

    def _save(self):
        self.cfg.set(self.timeout_spin.value(), "search", "timeout")
        self.cfg.set(self.threads_spin.value(), "search", "max_threads")
        self.cfg.set(self.auto_history.isChecked(), "search", "auto_save_history")
        self.cfg.set(self.toast_notifs.isChecked(), "ui", "toast_notifications")
        self.cfg.set(self.font_spin.value(), "ui", "font_size")
        self.cfg.set(self.anim_enabled.isChecked(), "ui", "animation", "enabled")
        self.cfg.set(self.anim_type.currentData(), "ui", "animation", "type")
        self.cfg.set(self.anim_speed.value() / 10, "ui", "animation", "speed")
        self.cfg.set(self.anim_intensity.value() / 10, "ui", "animation", "intensity")
        for key, field in self._api_fields.items():
            self.cfg.set(field.text(), "api_keys", key)
        self.cfg.set(self.proxy_enabled.isChecked(), "proxy", "enabled")
        self.cfg.set(self.proxy_http.text(), "proxy", "http")
        self.cfg.set(self.proxy_https.text(), "proxy", "https")
        self.cfg.set(self.proxy_socks5.text(), "proxy", "socks5")
        self.cfg.save()
        show_toast(self.window(), "Paramètres sauvegardés ✅", "success")

    def _reset(self):
        self.cfg.config = self.cfg._defaults()
        self.cfg.save()
        show_toast(self.window(), "Paramètres réinitialisés", "info")
