from ui.views.base_view import BaseView, WorkerThread
from modules.ip import ipapi


class IpView(BaseView):
    MODULE_NAME = "ip"
    TITLE = "Adresse IP"
    ICON = "🌐"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: 8.8.8.8"

    def _run(self, query):
        self._worker = WorkerThread(ipapi.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
