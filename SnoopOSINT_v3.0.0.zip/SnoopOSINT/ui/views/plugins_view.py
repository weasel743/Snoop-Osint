from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QPushButton, QFileDialog, QFrame)
from PyQt6.QtCore import Qt
from core.plugin_loader import PluginLoader
from ui.widgets.toast import show_toast
import shutil, os

class PluginsView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.loader = PluginLoader()
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20,16,20,16)
        layout.setSpacing(12)
        title = QLabel("🧩 Plugins")
        title.setStyleSheet("font-size:15pt;font-weight:bold;color:#EEF3FC;background:transparent;")
        layout.addWidget(title)
        desc = QLabel("Ajoutez des modules personnalisés au format .py dans le dossier plugins/")
        desc.setStyleSheet("color:#8AA0B8;background:transparent;")
        layout.addWidget(desc)
        ctrl = QHBoxLayout()
        btn_add = QPushButton("➕ Ajouter un plugin")
        btn_add.clicked.connect(self._add_plugin)
        ctrl.addWidget(btn_add)
        btn_refresh = QPushButton("🔄 Recharger")
        btn_refresh.setObjectName("secondary")
        btn_refresh.clicked.connect(self._refresh)
        ctrl.addWidget(btn_refresh)
        ctrl.addStretch()
        layout.addLayout(ctrl)
        self._list_container = QVBoxLayout()
        layout.addLayout(self._list_container)
        layout.addStretch()
        self._refresh()

    def _refresh(self):
        while self._list_container.count():
            item = self._list_container.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.loader = PluginLoader()
        for p in self.loader.get_plugins():
            card = QFrame()
            card.setStyleSheet("background:#0D1726;border:1px solid #1A2A44;border-radius:8px;padding:4px;")
            row = QHBoxLayout(card)
            icon = "✅" if p.get("enabled") else "❌"
            info = QLabel(f"{icon} <b>{p.get('name','')}</b> v{p.get('version','?')} — {p.get('description','')[:80]}")
            info.setTextFormat(Qt.TextFormat.RichText)
            info.setStyleSheet("background:transparent;color:#EEF3FC;")
            row.addWidget(info, 1)
            self._list_container.addWidget(card)
        if not self.loader.get_plugins():
            empty = QLabel("Aucun plugin installé. Ajoutez des fichiers .py dans plugins/")
            empty.setStyleSheet("color:#4A5C70;background:transparent;padding:20px;")
            self._list_container.addWidget(empty)

    def _add_plugin(self):
        path, _ = QFileDialog.getOpenFileName(self,"Ajouter plugin","","Python (*.py)")
        if path:
            BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            dest = os.path.join(BASE_DIR,"plugins",os.path.basename(path))
            shutil.copy2(path, dest)
            self._refresh()
            show_toast(self.window(),"Plugin ajouté","success")
