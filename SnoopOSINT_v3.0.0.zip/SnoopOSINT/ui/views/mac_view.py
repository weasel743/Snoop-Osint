from ui.views.base_view import BaseView, WorkerThread
import requests

HEADERS = {"User-Agent":"Mozilla/5.0"}

def lookup_mac(mac, timeout=10):
    results = []
    clean = mac.replace(":","").replace("-","").replace(".","").upper()[:6]
    results.append({"Champ":"Adresse MAC","Valeur":mac,"Source":"Local"})
    results.append({"Champ":"OUI (6 premiers hex)","Valeur":clean,"Source":"Local"})
    try:
        resp = requests.get(f"https://api.maclookup.app/v2/macs/{mac}",
            headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            d = resp.json()
            results.append({"Champ":"Fabricant","Valeur":d.get("company","Inconnu"),"Source":"maclookup.app"})
            results.append({"Champ":"Pays","Valeur":d.get("country",""),"Source":"maclookup.app"})
            results.append({"Champ":"Type","Valeur":"Privé" if d.get("isPrivate") else "Public","Source":"maclookup.app"})
    except Exception:
        pass
    try:
        resp2 = requests.get(f"https://api.macvendors.com/{mac}",headers=HEADERS,timeout=timeout)
        if resp2.status_code == 200:
            results.append({"Champ":"Vendeur (backup)","Valeur":resp2.text.strip(),"Source":"macvendors.com"})
    except Exception:
        pass
    return results

class MacView(BaseView):
    MODULE_NAME = "mac"
    TITLE = "Adresse MAC"
    ICON = "💻"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: 00:1A:2B:3C:4D:5E"

    def _run(self, query):
        self._worker = WorkerThread(lookup_mac, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
