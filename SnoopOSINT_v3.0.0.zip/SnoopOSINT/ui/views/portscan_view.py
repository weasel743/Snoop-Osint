from ui.views.base_view import BaseView, WorkerThread
from modules.portscan import port_scanner

class PortscanView(BaseView):
    MODULE_NAME = "portscan"
    TITLE = "Port Scanner"
    ICON = "🔌"
    COLUMNS = ["Port", "Service", "Statut", "Banner"]
    PLACEHOLDER = "ex: 192.168.1.1 ou domaine.com"

    def _run(self, query):
        self._worker = WorkerThread(port_scanner.run, query, timeout=0.8,
                                    max_workers=self.cfg.get("search","max_threads",default=30))
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
