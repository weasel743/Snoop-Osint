from PyQt6.QtWidgets import QLabel
from ui.views.base_view import BaseView, WorkerThread
import requests, re

HEADERS = {"User-Agent": "Mozilla/5.0"}

def search_person(name, timeout=10):
    results = []
    try:
        resp = requests.get(f"https://en.wikipedia.org/w/api.php",
            params={"action":"query","list":"search","srsearch":name,"format":"json","srlimit":5},
            headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for item in data.get("query",{}).get("search",[]):
                results.append({"Source":"Wikipedia","Titre":item.get("title",""),
                    "Extrait":re.sub("<[^>]+>","",item.get("snippet",""))[:150],
                    "URL":f"https://en.wikipedia.org/wiki/{item.get('title','').replace(' ','_')}"})
    except Exception:
        pass
    try:
        resp2 = requests.get(f"https://www.wikidata.org/w/api.php",
            params={"action":"wbsearchentities","search":name,"format":"json","language":"fr","limit":5},
            headers=HEADERS, timeout=timeout)
        if resp2.status_code == 200:
            data2 = resp2.json()
            for item in data2.get("search",[]):
                results.append({"Source":"Wikidata","Titre":item.get("label",""),
                    "Extrait":item.get("description","")[:150],
                    "URL":f"https://www.wikidata.org/wiki/{item.get('id','')}"})
    except Exception:
        pass
    return results

class PersonView(BaseView):
    MODULE_NAME = "person"
    TITLE = "Personne"
    ICON = "🔎"
    COLUMNS = ["Source", "Titre", "Extrait", "URL"]
    PLACEHOLDER = "ex: Elon Musk ou Marie Curie"

    def _run(self, query):
        self._worker = WorkerThread(search_person, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
