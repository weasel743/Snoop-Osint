from ui.views.base_view import BaseView, WorkerThread
from modules.domain import ssl_info

class SslView(BaseView):
    MODULE_NAME = "ssl"
    TITLE = "SSL / Certificats"
    ICON = "🔐"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: example.com"

    def _run(self, query):
        self._worker = WorkerThread(ssl_info.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
