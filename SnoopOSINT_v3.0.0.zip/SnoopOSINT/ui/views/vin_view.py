from ui.views.base_view import BaseView, WorkerThread
import requests

HEADERS = {"User-Agent":"Mozilla/5.0"}

WMI = {
    "1G":"General Motors USA","1F":"Ford USA","1C":"Chrysler USA","2G":"General Motors Canada",
    "3G":"General Motors Mexico","JH":"Honda Japan","JT":"Toyota Japan","VW":"Volkswagen Germany",
    "WBA":"BMW Germany","WDB":"Mercedes-Benz Germany","ZFF":"Ferrari Italy","SAL":"Land Rover UK",
}

def decode_vin(vin, timeout=10):
    vin = vin.upper().strip()
    results = []
    if len(vin) != 17:
        return [{"Champ":"Erreur","Valeur":"Le VIN doit contenir 17 caractères","Source":"Local"}]
    results.append({"Champ":"VIN","Valeur":vin,"Source":"Local"})
    wmi = vin[:3]
    for code, make in WMI.items():
        if vin.startswith(code):
            results.append({"Champ":"Constructeur","Valeur":make,"Source":"WMI DB"})
            break
    year_chars = "ABCDEFGHJKLMNPRSTVWXY123456789"
    year_digit = vin[9]
    if year_digit in year_chars:
        base_year = 1980
        yr = base_year + year_chars.index(year_digit)
        results.append({"Champ":"Année modèle","Valeur":str(yr),"Source":"Décodage VIN"})
    results.append({"Champ":"Pays fabrication","Valeur":_country(vin[0]),"Source":"Décodage VIN"})
    results.append({"Champ":"Type véhicule","Valeur":vin[4],"Source":"Décodage VIN"})
    results.append({"Champ":"Numéro série","Valeur":vin[11:],"Source":"Décodage VIN"})
    try:
        resp = requests.get(f"https://vpic.nhtsa.dot.gov/api/vehicles/decodevinvalues/{vin}",
            params={"format":"json"}, headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for r in data.get("Results",[{}]):
                for k,v in r.items():
                    if v and v not in ("","0","Not Applicable") and k not in ("ErrorCode","ErrorText","SuggestedVIN"):
                        results.append({"Champ":k,"Valeur":str(v)[:200],"Source":"NHTSA"})
    except Exception:
        pass
    return results

def _country(c):
    m = {"1":"USA","2":"Canada","3":"Mexico","J":"Japan","S":"UK","V":"France","W":"Germany","Z":"Italy"}
    return m.get(c,"Inconnu")

class VinView(BaseView):
    MODULE_NAME = "vin"
    TITLE = "VIN / Véhicule"
    ICON = "🚗"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: 1HGBH41JXMN109186"

    def _run(self, query):
        self._worker = WorkerThread(decode_vin, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
