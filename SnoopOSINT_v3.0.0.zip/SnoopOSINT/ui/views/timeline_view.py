"""
Vue Timeline — reconstitue une chronologie à partir des résultats
"""
import re
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QScrollArea, QFrame, QLineEdit, QPushButton)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QPainter, QPen, QFont
from core.database import Database


class TimelineEvent(QFrame):
    def __init__(self, date, title, source, color="#7C3AED", parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QFrame{{background:#0D1726;border:none;border-left:3px solid {color};
                    border-radius:0 6px 6px 0;margin-left:20px;}}
        """)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 12, 8)
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{color};font-size:16px;background:transparent;margin-left:-24px;")
        layout.addWidget(dot)
        info = QVBoxLayout()
        date_lbl = QLabel(date[:10] if date else "Date inconnue")
        date_lbl.setStyleSheet(f"color:{color};font-size:9pt;font-weight:bold;background:transparent;")
        info.addWidget(date_lbl)
        title_lbl = QLabel(title[:100])
        title_lbl.setStyleSheet("color:#EEF3FC;font-size:10pt;background:transparent;")
        info.addWidget(title_lbl)
        src_lbl = QLabel(f"Source: {source}")
        src_lbl.setStyleSheet("color:#4A5C70;font-size:8pt;background:transparent;")
        info.addWidget(src_lbl)
        layout.addLayout(info, 1)


class TimelineView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.db = Database()
        self._events = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        title = QLabel("📅 Timeline")
        title.setStyleSheet("font-size:15pt;font-weight:bold;color:#EEF3FC;background:transparent;")
        layout.addWidget(title)

        desc = QLabel("Chronologie automatique des informations trouvées sur une cible")
        desc.setStyleSheet("color:#8AA0B8;background:transparent;")
        layout.addWidget(desc)

        ctrl = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Nom, email, username ou domaine...")
        self.search_input.setMinimumHeight(36)
        self.search_input.returnPressed.connect(self._build_timeline)
        ctrl.addWidget(self.search_input, 1)
        btn = QPushButton("📅 Construire la timeline")
        btn.setMinimumHeight(36)
        btn.clicked.connect(self._build_timeline)
        ctrl.addWidget(btn)
        layout.addLayout(ctrl)

        self.count_lbl = QLabel("")
        self.count_lbl.setStyleSheet("color:#8AA0B8;font-size:9pt;background:transparent;")
        layout.addWidget(self.count_lbl)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent}")
        self._container = QWidget()
        self._container.setStyleSheet("background:transparent;")
        self._timeline_layout = QVBoxLayout(self._container)
        self._timeline_layout.setSpacing(4)
        self._timeline_layout.setContentsMargins(0, 0, 0, 0)
        scroll.setWidget(self._container)
        layout.addWidget(scroll, 1)

    def _build_timeline(self):
        query = self.search_input.text().strip()
        if not query: return
        while self._timeline_layout.count():
            item = self._timeline_layout.takeAt(0)
            if item.widget(): item.widget().deleteLater()
        history = self.db.search_history(query)
        events = []
        import json
        for h in history:
            try:
                results = json.loads(h.get("results","[]"))
                for r in (results if isinstance(results, list) else []):
                    if not isinstance(r, dict): continue
                    for k, v in r.items():
                        if "date" in k.lower() or "created" in k.lower() or "modified" in k.lower():
                            v = str(v)
                            date_match = re.search(r'\d{4}[-/]\d{2}[-/]\d{2}', v)
                            if date_match:
                                date = date_match.group(0)
                                desc = r.get("description","") or r.get("Dénomination","") or r.get("Titre","") or str(list(r.values())[:2])
                                events.append({"date": date, "title": f"[{h['module']}] {desc[:80]}", "source": h["module"]})
            except: pass
        events.sort(key=lambda x: x["date"])
        self.count_lbl.setText(f"{len(events)} événements datés trouvés dans l'historique")
        if not events:
            lbl = QLabel("Aucun événement daté trouvé. Lancez d'abord des recherches sur cette cible.")
            lbl.setStyleSheet("color:#4A5C70;background:transparent;padding:20px;")
            self._timeline_layout.addWidget(lbl)
        else:
            colors = {"breach":"#DC2626","domain":"#0891B2","email":"#7C3AED","username":"#2563EB",
                      "ip":"#059669","france":"#D97706","bodacc":"#D97706","infogreffe":"#D97706"}
            for ev in events:
                color = colors.get(ev["source"], "#7C3AED")
                widget = TimelineEvent(ev["date"], ev["title"], ev["source"], color)
                self._timeline_layout.addWidget(widget)
        self._timeline_layout.addStretch()
