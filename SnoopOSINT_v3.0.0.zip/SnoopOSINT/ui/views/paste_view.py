from ui.views.base_view import BaseView, WorkerThread
from modules.paste import paste_search

class PasteView(BaseView):
    MODULE_NAME="paste"; TITLE="Paste Sites"; ICON="📋"
    COLUMNS=["Source","ID","Date","Taille","URL","Extrait"]
    PLACEHOLDER="email, username, mot de passe..."
    def _run(self, q):
        self._worker = WorkerThread(paste_search.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()
