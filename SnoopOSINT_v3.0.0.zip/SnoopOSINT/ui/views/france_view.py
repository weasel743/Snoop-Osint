from PyQt6.QtWidgets import QTabWidget, QWidget, QVBoxLayout
from ui.views.base_view import BaseView, WorkerThread
from modules.france import bodacc, infogreffe, pagesjaunes, datafr

class FranceBodaccView(BaseView):
    MODULE_NAME="bodacc"; TITLE="BODACC"; ICON="🏛️"
    COLUMNS=["Source","Type","Dénomination","SIREN","Date","Tribunal","Ville","Description"]
    PLACEHOLDER="Nom entreprise, SIREN, ou dirigeant..."
    def _run(self, q):
        self._worker = WorkerThread(bodacc.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()

class FranceInfogreffeView(BaseView):
    MODULE_NAME="infogreffe"; TITLE="Infogreffe"; ICON="📋"
    COLUMNS=["Source","Raison sociale","SIREN","Dirigeant","Qualité","Ville","Date MAJ","Forme juridique"]
    PLACEHOLDER="Raison sociale ou SIREN..."
    def _run(self, q):
        self._worker = WorkerThread(infogreffe.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()

class FrancePagesJaunesView(BaseView):
    MODULE_NAME="pagesjaunes"; TITLE="Pages Jaunes / Blanches"; ICON="📒"
    COLUMNS=["Source","Nom","Adresse","Téléphone","Catégorie","URL"]
    PLACEHOLDER="Nom personne ou entreprise..."
    def _run(self, q):
        self._worker = WorkerThread(pagesjaunes.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()

class FranceDataGouv(BaseView):
    MODULE_NAME="datafr"; TITLE="Data.gouv.fr"; ICON="🇫🇷"
    COLUMNS=["Source","Type","Titre","Organisation","Date","URL","Description"]
    PLACEHOLDER="Rechercher dans les données ouvertes françaises..."
    def _run(self, q):
        self._worker = WorkerThread(datafr.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()
