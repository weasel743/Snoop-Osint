from ui.views.base_view import BaseView, WorkerThread
from modules.domain import dns_enum

class DnsView(BaseView):
    MODULE_NAME = "dns"
    TITLE = "DNS"
    ICON = "🌀"
    COLUMNS = ["Type", "Valeur", "TTL", "Source"]
    PLACEHOLDER = "ex: example.com"

    def _run(self, query):
        self._worker = WorkerThread(dns_enum.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
