import os
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QLineEdit, QPushButton, QFrame, QFileDialog,
                              QProgressBar, QSizePolicy)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont
from core.language_manager import LanguageManager
from core.config_manager import ConfigManager
from core.database import Database
from core.report_generator import ReportGenerator
from ui.widgets.clickable_table import ClickableTable
from ui.widgets.toast import show_toast


class WorkerThread(QThread):
    result = pyqtSignal(list)
    progress = pyqtSignal(int, int, dict)
    error = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, fn, *args, **kwargs):
        super().__init__()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs

    def run(self):
        try:
            result = self.fn(*self.args, **self.kwargs)
            self.result.emit(result or [])
        except Exception as e:
            self.error.emit(str(e))
        finally:
            self.finished.emit()


class BaseView(QWidget):
    MODULE_NAME = "base"
    TITLE = "Module"
    ICON = "🔍"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "Entrez une valeur..."

    def __init__(self, parent=None):
        super().__init__(parent)
        self.lang = LanguageManager()
        self.cfg = ConfigManager()
        self.db = Database()
        self._results = []
        self._worker = None
        self._setup_ui()
        self.lang.register(self._retranslate)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        # Header
        header = QHBoxLayout()
        self.title_lbl = QLabel(f"{self.ICON} {self.TITLE}")
        self.title_lbl.setStyleSheet(
            "font-size: 15pt; font-weight: bold; color: #EEF3FC; background: transparent;")
        header.addWidget(self.title_lbl)
        header.addStretch()
        self.count_lbl = QLabel("")
        self.count_lbl.setStyleSheet(
            "background: rgba(124,58,237,0.2); color: #A78BFA; padding: 3px 12px; "
            "border-radius: 10px; border: 1px solid rgba(124,58,237,0.3); font-size: 9pt;")
        header.addWidget(self.count_lbl)
        layout.addLayout(header)

        # Search bar
        search_row = QHBoxLayout()
        search_row.setSpacing(8)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText(self.PLACEHOLDER)
        self.search_input.setMinimumHeight(36)
        self.search_input.returnPressed.connect(self._start_search)
        search_row.addWidget(self.search_input, 1)

        self.btn_search = QPushButton(self.lang.t("buttons", "search"))
        self.btn_search.setMinimumHeight(36)
        self.btn_search.setMinimumWidth(110)
        self.btn_search.clicked.connect(self._start_search)
        search_row.addWidget(self.btn_search)

        self.btn_clear = QPushButton(self.lang.t("buttons", "clear"))
        self.btn_clear.setObjectName("secondary")
        self.btn_clear.setMinimumHeight(36)
        self.btn_clear.clicked.connect(self._clear)
        search_row.addWidget(self.btn_clear)
        self._extra_controls(search_row)
        layout.addLayout(search_row)

        # Progress bar
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setFixedHeight(4)
        self.progress.setTextVisible(False)
        self.progress.setStyleSheet("""
            QProgressBar { background: #1A2A44; border-radius: 2px; border: none; }
            QProgressBar::chunk { background: #7C3AED; border-radius: 2px; }
        """)
        layout.addWidget(self.progress)

        # Filter row
        filter_row = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("🔍 Filtrer les résultats...")
        self.filter_input.setMaximumHeight(30)
        self.filter_input.textChanged.connect(self._filter)
        self.filter_input.setStyleSheet("""
            QLineEdit { background: #0A0E17; border: 1px solid #1A2A44; border-radius: 4px;
                        padding: 3px 10px; color: #EEF3FC; font-size: 9pt; }
        """)
        filter_row.addWidget(self.filter_input, 1)
        filter_row.addStretch()
        layout.addLayout(filter_row)

        # Table
        self.table = ClickableTable(self.COLUMNS)
        layout.addWidget(self.table, 1)

        # Export row
        export_row = QHBoxLayout()
        self.status_lbl = QLabel("Prêt")
        self.status_lbl.setStyleSheet("color: #8AA0B8; font-size: 9pt; background: transparent;")
        export_row.addWidget(self.status_lbl)
        export_row.addStretch()

        for label, fmt in [("CSV", "csv"), ("JSON", "json"), ("PDF", "pdf"), ("HTML", "html")]:
            btn = QPushButton(label)
            btn.setObjectName("secondary")
            btn.setFixedHeight(28)
            btn.setFixedWidth(60)
            btn.clicked.connect(lambda checked, f=fmt: self._export(f))
            export_row.addWidget(btn)
        layout.addLayout(export_row)

    def _extra_controls(self, row):
        pass

    def _start_search(self):
        query = self.search_input.text().strip()
        if not query:
            show_toast(self.window(), "Veuillez entrer une valeur", "warning")
            return
        self._set_loading(True)
        self._results = []
        self.table.clear_data()
        self.status_lbl.setText(self.lang.t("messages", "loading"))
        self.count_lbl.setText("")
        self._run(query)

    def _run(self, query):
        raise NotImplementedError

    def _on_results(self, results):
        self._results = results
        self.table.load_data(results)
        self.count_lbl.setText(f"{len(results)} résultats")
        self.status_lbl.setText(f"✅ {len(results)} résultats trouvés")
        self._set_loading(False)
        if self.cfg.get("search", "auto_save_history", default=True):
            try:
                self.db.save_result(self.MODULE_NAME, self.search_input.text().strip(), results)
            except Exception:
                pass
        if not results:
            show_toast(self.window(), self.lang.t("messages", "no_results"), "warning")

    def _on_error(self, msg):
        self.status_lbl.setText(f"❌ Erreur: {msg}")
        self._set_loading(False)
        show_toast(self.window(), f"Erreur: {msg}", "error")

    def _set_loading(self, loading):
        self.progress.setVisible(loading)
        self.btn_search.setEnabled(not loading)
        if loading:
            self.progress.setRange(0, 0)
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(100)

    def _clear(self):
        self.search_input.clear()
        self.filter_input.clear()
        self.table.clear_data()
        self._results = []
        self.count_lbl.setText("")
        self.status_lbl.setText("Prêt")

    def _filter(self, text):
        self.table.filter_rows(text)

    def _export(self, fmt):
        if not self._results:
            show_toast(self.window(), "Aucun résultat à exporter", "warning")
            return
        query = self.search_input.text().strip()
        gen = ReportGenerator(self.MODULE_NAME, query, self._results)
        filters = {"csv": "CSV (*.csv)", "json": "JSON (*.json)",
                   "pdf": "PDF (*.pdf)", "html": "HTML (*.html)"}
        path, _ = QFileDialog.getSaveFileName(self, "Exporter", f"{self.MODULE_NAME}_export",
                                              filters.get(fmt, "*.*"))
        if not path:
            return
        try:
            fn = getattr(gen, f"export_{fmt}")
            fn(path)
            show_toast(self.window(), f"Exporté: {os.path.basename(path)}", "success")
        except Exception as e:
            show_toast(self.window(), f"Erreur export: {e}", "error")

    def _retranslate(self):
        self.btn_search.setText(self.lang.t("buttons", "search"))
        self.btn_clear.setText(self.lang.t("buttons", "clear"))
