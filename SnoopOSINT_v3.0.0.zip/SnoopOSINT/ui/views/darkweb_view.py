from PyQt6.QtWidgets import QLabel, QVBoxLayout
from ui.views.base_view import BaseView, WorkerThread
import requests

HEADERS = {"User-Agent": "Mozilla/5.0"}

def search_darkweb(query, timeout=10):
    results = []
    try:
        resp = requests.get("https://ahmia.fi/search/", params={"q":query},
            headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(resp.text, "html.parser")
            for li in soup.select("li.result")[:20]:
                title_el = li.select_one("h4")
                link_el = li.select_one("a")
                desc_el = li.select_one("p")
                results.append({
                    "Source": "Ahmia.fi",
                    "Titre": title_el.text.strip()[:80] if title_el else "",
                    "URL": link_el.get("href","") if link_el else "",
                    "Description": desc_el.text.strip()[:120] if desc_el else ""
                })
    except Exception:
        pass
    if not results:
        results.append({"Source":"Info","Titre":"Ahmia.fi (moteur Dark Web indexé)",
            "URL":"https://ahmia.fi","Description":"Résultats non disponibles ou tor requis"})
    return results

class DarkwebView(BaseView):
    MODULE_NAME = "darkweb"
    TITLE = "Dark Web"
    ICON = "🕸️"
    COLUMNS = ["Source", "Titre", "URL", "Description"]
    PLACEHOLDER = "ex: forum, marketplace, service..."

    def _run(self, query):
        self._worker = WorkerThread(search_darkweb, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
