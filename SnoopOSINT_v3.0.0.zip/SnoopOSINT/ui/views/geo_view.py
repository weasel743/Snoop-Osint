from ui.views.base_view import BaseView, WorkerThread
from modules.geo import ip_geo

class GeoView(BaseView):
    MODULE_NAME = "geo"
    TITLE = "Géolocalisation"
    ICON = "🗺️"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: 8.8.8.8 ou domaine.com"

    def _run(self, query):
        self._worker = WorkerThread(ip_geo.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
