from ui.views.base_view import BaseView, WorkerThread
from modules.username import sherlock

class UsernameView(BaseView):
    MODULE_NAME="username"; TITLE="Nom d'utilisateur"; ICON="👤"
    COLUMNS=["Plateforme","URL","Statut","Code HTTP"]
    PLACEHOLDER="ex: john_doe"
    def _run(self, q):
        self._worker = WorkerThread(sherlock.run, q,
            timeout=self.cfg.get_timeout(),
            max_workers=self.cfg.get("search","max_threads",default=30))
        self._worker.result.connect(self._on_sherlock); self._worker.error.connect(self._on_error); self._worker.start()
    def _on_sherlock(self, results):
        rows = [{"Plateforme":r["platform"],"URL":r["url"],"Statut":r["status"],"Code HTTP":str(r["code"])} for r in results]
        super()._on_results(rows)
