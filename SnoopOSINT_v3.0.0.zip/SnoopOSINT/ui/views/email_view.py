from ui.views.base_view import BaseView, WorkerThread
from modules.email import holehe, hibp

class EmailView(BaseView):
    MODULE_NAME="email"; TITLE="Email"; ICON="📧"
    COLUMNS=["Plateforme","Trouvé","Détails","Méthode"]
    PLACEHOLDER="ex: john@example.com"
    def _run(self, q):
        self._worker = WorkerThread(holehe.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_holehe); self._worker.error.connect(self._on_error); self._worker.start()
    def _on_holehe(self, results):
        rows = [{"Plateforme":r["platform"],"Trouvé":"✅ Oui" if r["found"] else "❌ Non",
                 "Détails":r.get("details",""),"Méthode":r.get("method","")} for r in results]
        super()._on_results(rows)
        api_key = self.cfg.get("api_keys","hibp",default="")
        self._worker2 = WorkerThread(hibp.run, self.search_input.text().strip(), api_key=api_key, timeout=self.cfg.get_timeout())
        self._worker2.result.connect(self._on_breach); self._worker2.start()
    def _on_breach(self, results):
        if results:
            existing = self._results[:]
            for r in results:
                existing.append({"Plateforme":f"🔴 {r.get('source','')}","Trouvé":"✅ Fuite",
                    "Détails":r.get("description","")[:80],"Méthode":r.get("severity","")})
            self._results = existing; self.table.load_data(existing)
            self.count_lbl.setText(f"{len(existing)} résultats")
