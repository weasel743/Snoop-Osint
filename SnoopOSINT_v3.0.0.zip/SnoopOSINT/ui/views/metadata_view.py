from ui.views.image_view import ImageView

class MetadataView(ImageView):
    MODULE_NAME = "metadata"
    TITLE = "Métadonnées"
    ICON = "📄"
