"""
Vue Corrélation — interface principale du moteur de corrélation automatique
"""
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QLineEdit, QPushButton, QSplitter, QTextEdit,
                              QProgressBar, QComboBox)
from PyQt6.QtCore import Qt, pyqtSignal
from modules.correlation.engine import CorrelationEngine, detect_type
from ui.views.graph_view import GraphView
from ui.widgets.toast import show_toast
from core.config_manager import ConfigManager
from core.database import Database


class CorrelationView(QWidget):
    navigate_to = pyqtSignal(str, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cfg = ConfigManager()
        self.db = Database()
        self._engine = None
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Header
        header = QWidget()
        header.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        header_l = QHBoxLayout(header)
        header_l.setContentsMargins(16, 10, 16, 10)

        title = QLabel("🔗 Corrélation automatique")
        title.setStyleSheet("font-size:14pt;font-weight:bold;color:#EEF3FC;background:transparent;")
        header_l.addWidget(title)

        self.seed_input = QLineEdit()
        self.seed_input.setPlaceholderText("email, username, IP, domaine, téléphone...")
        self.seed_input.setMinimumWidth(300)
        self.seed_input.setMinimumHeight(36)
        self.seed_input.returnPressed.connect(self._start)
        header_l.addWidget(self.seed_input, 1)

        self.depth_combo = QComboBox()
        for d in [1, 2, 3]:
            self.depth_combo.addItem(f"Profondeur {d}", d)
        self.depth_combo.setCurrentIndex(1)
        self.depth_combo.setFixedWidth(130)
        header_l.addWidget(self.depth_combo)

        self.btn_run = QPushButton("▶ Lancer")
        self.btn_run.setMinimumHeight(36)
        self.btn_run.setMinimumWidth(100)
        self.btn_run.clicked.connect(self._start)
        header_l.addWidget(self.btn_run)

        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setObjectName("secondary")
        self.btn_stop.setMinimumHeight(36)
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self._stop)
        header_l.addWidget(self.btn_stop)

        layout.addWidget(header)

        # Progress
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setFixedHeight(3)
        self.progress.setTextVisible(False)
        self.progress.setStyleSheet("QProgressBar{background:#0A0E17;border:none}QProgressBar::chunk{background:#7C3AED}")
        layout.addWidget(self.progress)

        # Splitter : graphe | log
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # Graphe
        self.graph_view = GraphView()
        self.graph_view.navigate_to.connect(self._on_navigate)
        splitter.addWidget(self.graph_view)

        # Panneau droit : status + résumé
        right = QWidget()
        right.setStyleSheet("background:#0D1726;")
        right.setFixedWidth(280)
        right_l = QVBoxLayout(right)
        right_l.setContentsMargins(12, 12, 12, 12)
        right_l.setSpacing(8)

        log_title = QLabel("📋 Activité en temps réel")
        log_title.setStyleSheet("color:#8AA0B8;font-size:9pt;background:transparent;")
        right_l.addWidget(log_title)

        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("""
            QTextEdit{background:#0A0E17;color:#EEF3FC;border:1px solid #1A2A44;
                      border-radius:6px;padding:8px;font-family:'Courier New';font-size:9pt;}
        """)
        right_l.addWidget(self.log_area, 1)

        summary_title = QLabel("📊 Résumé")
        summary_title.setStyleSheet("color:#8AA0B8;font-size:9pt;background:transparent;")
        right_l.addWidget(summary_title)

        self.summary_lbl = QLabel("Lancez une corrélation pour commencer")
        self.summary_lbl.setWordWrap(True)
        self.summary_lbl.setStyleSheet("""
            background:#0A0E17;border:1px solid #1A2A44;border-radius:6px;
            padding:10px;color:#EEF3FC;font-size:9pt;
        """)
        right_l.addWidget(self.summary_lbl)

        # Légende
        legend = QLabel("""
<b style='color:#EEF3FC'>Légende</b><br>
<span style='color:#7C3AED'>●</span> Email &nbsp;
<span style='color:#2563EB'>●</span> Username<br>
<span style='color:#0891B2'>●</span> Domaine &nbsp;
<span style='color:#059669'>●</span> IP<br>
<span style='color:#D97706'>●</span> Téléphone &nbsp;
<span style='color:#DB2777'>●</span> Nom<br>
<span style='color:#34D399'>●</span> Plateforme &nbsp;
<span style='color:#DC2626'>●</span> Fuite<br>
<span style='color:#F59E0B'>●</span> Crypto &nbsp;
<span style='color:#8B5CF6'>●</span> Organisation
        """)
        legend.setTextFormat(Qt.TextFormat.RichText)
        legend.setStyleSheet("background:#0A0E17;border:1px solid #1A2A44;border-radius:6px;padding:10px;font-size:9pt;")
        right_l.addWidget(legend)

        splitter.addWidget(right)
        splitter.setSizes([800, 280])
        layout.addWidget(splitter, 1)

        # Status bar
        self.status_lbl = QLabel("Prêt — entrez une donnée et lancez la corrélation")
        self.status_lbl.setStyleSheet("""
            background:#0D1726;border-top:1px solid #1A2A44;
            color:#8AA0B8;padding:6px 14px;font-size:9pt;
        """)
        layout.addWidget(self.status_lbl)

    def start_with_query(self, query):
        self.seed_input.setText(query)
        self._start()

    def _start(self):
        seed = self.seed_input.text().strip()
        if not seed:
            show_toast(self.window(), "Entrez une valeur à analyser", "warning")
            return
        self.graph_view.clear()
        self.log_area.clear()
        self.summary_lbl.setText("Analyse en cours...")
        depth = self.depth_combo.currentData() or 2
        max_nodes = self.cfg.get("correlation","max_nodes",default=50)
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._log(f"🚀 Démarrage — seed: <b>{seed}</b>", "#A78BFA")
        self._log(f"⚙️ Profondeur: {depth} | Nœuds max: {max_nodes}")
        detected = detect_type(seed)
        self._log(f"🔍 Type détecté: <b>{detected}</b>", "#34D399")
        self._engine = CorrelationEngine(seed, max_depth=depth, max_nodes=max_nodes,
                                          timeout=self.cfg.get_timeout())
        self._engine.node_found.connect(self._on_node)
        self._engine.edge_found.connect(self._on_edge)
        self._engine.status_update.connect(self._on_status)
        self._engine.progress.connect(self._on_progress)
        self._engine.finished_signal.connect(self._on_finished)
        self._engine.start()

    def _stop(self):
        if self._engine:
            self._engine.stop()
        self._set_done()

    def _on_node(self, node_data):
        self.graph_view.add_node(node_data)
        val = node_data.get("value","")[:40]
        ntype = node_data.get("type","")
        self._log(f"✅ [{ntype}] {val}", "#34D399")

    def _on_edge(self, edge_data):
        self.graph_view.add_edge(edge_data)
        self._log(f"🔗 {edge_data.get('src','')[:20]} → {edge_data.get('label','')} → {edge_data.get('dst','')[:20]}", "#8AA0B8")

    def _on_status(self, msg):
        self.status_lbl.setText(f"🔄 {msg}")

    def _on_progress(self, done, total):
        self.progress.setRange(0, max(total, 1))
        self.progress.setValue(done)

    def _on_finished(self, result):
        summary = result.get("summary","")
        nodes = result.get("nodes",[])
        edges = result.get("edges",[])
        self.summary_lbl.setText(f"✅ {summary}")
        self._log(f"🎯 Terminé: {summary}", "#A78BFA")
        self._set_done()
        try:
            seed = self.seed_input.text().strip()
            self.db.save_graph(seed, nodes, edges, summary)
        except: pass
        show_toast(self.window(), f"Corrélation terminée — {summary}", "success")

    def _set_done(self):
        self.progress.setVisible(False)
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)

    def _on_navigate(self, view_id, query):
        self.navigate_to.emit(view_id, query)

    def _log(self, msg, color="#EEF3FC"):
        self.log_area.append(f'<span style="color:{color}">{msg}</span>')
        sb = self.log_area.verticalScrollBar()
        sb.setValue(sb.maximum())
