from ui.views.base_view import BaseView, WorkerThread
from modules.social import github_scan


class GithubView(BaseView):
    MODULE_NAME = "github"
    TITLE = "GitHub"
    ICON = "🐙"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: torvalds"

    def _run(self, query):
        self._worker = WorkerThread(github_scan.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
