from ui.views.base_view import BaseView, WorkerThread
import requests

HEADERS = {"User-Agent":"Mozilla/5.0"}

def search_wifi(bssid_or_ssid, timeout=10):
    results = []
    try:
        resp = requests.get("https://api.wigle.net/api/v2/network/search",
            params={"netid":bssid_or_ssid,"freenet":"false","paynet":"false"},
            headers=HEADERS, auth=("AIDaaaaaaaaaaaa","test"), timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for r in data.get("results",[])[:20]:
                results.append({"SSID":r.get("ssid",""),"BSSID":r.get("netid",""),
                    "Sécurité":r.get("encryption",""),"Canal":str(r.get("channel","")),"Pays":r.get("country",""),
                    "Coord":f"{r.get('trilat','')},{r.get('trilong','')}"})
    except Exception:
        pass
    if not results:
        results.append({"SSID":"WiGLE API requiert inscription","BSSID":bssid_or_ssid,
            "Sécurité":"","Canal":"","Pays":"","Coord":"Inscription gratuite sur wigle.net"})
    return results

class WifiView(BaseView):
    MODULE_NAME = "wifi"
    TITLE = "WiFi"
    ICON = "📡"
    COLUMNS = ["SSID", "BSSID", "Sécurité", "Canal", "Pays", "Coord"]
    PLACEHOLDER = "ex: AA:BB:CC:DD:EE:FF ou SSID réseau"

    def _run(self, query):
        self._worker = WorkerThread(search_wifi, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
