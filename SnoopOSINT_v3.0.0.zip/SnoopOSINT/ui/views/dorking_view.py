import webbrowser
from PyQt6.QtWidgets import QLabel, QPushButton, QGridLayout, QWidget, QVBoxLayout, QHBoxLayout
from PyQt6.QtCore import Qt
from ui.views.base_view import BaseView

DORKS = [
    ("Site spécifique", 'site:{query}'),
    ("Fichiers sensibles", 'site:{query} ext:pdf OR ext:xls OR ext:doc'),
    ("Répertoires ouverts", 'intitle:"index of" site:{query}'),
    ("Login pages", 'site:{query} inurl:login OR inurl:admin'),
    ("Configs exposées", 'site:{query} ext:env OR ext:cfg OR ext:conf'),
    ("Bases de données", 'site:{query} ext:sql OR ext:db OR ext:bak'),
    ("Emails exposés", 'site:{query} "@{query}"'),
    ("Sous-domaines", 'site:*.{query} -www'),
    ("Cameras/IoT", 'intitle:"webcam" OR intitle:"camera" site:{query}'),
    ("Erreurs PHP", 'site:{query} "Warning: mysql_"'),
    ("WordPress", 'site:{query} inurl:wp-admin OR inurl:wp-login'),
    ("PHPMyAdmin", 'site:{query} inurl:phpmyadmin'),
]

class DorkingView(BaseView):
    MODULE_NAME = "dorking"
    TITLE = "Google Dorking"
    ICON = "🔍"
    COLUMNS = ["Dork", "Requête", "Ouvrir"]
    PLACEHOLDER = "ex: example.com"

    def _run(self, query):
        results = []
        for name, template in DORKS:
            dork = template.replace("{query}", query)
            results.append({"Dork": name, "Requête": dork,
                "Ouvrir": f"https://www.google.com/search?q={dork}"})
        self._on_results(results)
