from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QTextEdit, QPushButton, QComboBox, QFileDialog,
                              QProgressBar)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from ui.widgets.clickable_table import ClickableTable
from ui.widgets.toast import show_toast
from core.language_manager import LanguageManager
from core.config_manager import ConfigManager
from core.database import Database


class BatchWorker(QThread):
    progress = pyqtSignal(int, int, str, list)
    finished = pyqtSignal()

    def __init__(self, module_fn, queries, timeout):
        super().__init__()
        self.module_fn = module_fn
        self.queries = queries
        self.timeout = timeout
        self._stop = False

    def run(self):
        total = len(self.queries)
        for i, q in enumerate(self.queries):
            if self._stop:
                break
            try:
                results = self.module_fn(q, timeout=self.timeout)
            except Exception as e:
                results = [{"Requête": q, "Résultat": f"Erreur: {e}", "Source": ""}]
            self.progress.emit(i + 1, total, q, results)
        self.finished.emit()

    def stop(self):
        self._stop = True


class BatchView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lang = LanguageManager()
        self.cfg = ConfigManager()
        self.db = Database()
        self._worker = None
        self._all_results = []
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        title = QLabel("📦 Recherche en lot")
        title.setStyleSheet("font-size: 15pt; font-weight: bold; color: #EEF3FC; background: transparent;")
        layout.addWidget(title)

        sub = QLabel("Saisissez une valeur par ligne. Le module sélectionné sera appliqué à chaque entrée.")
        sub.setStyleSheet("color: #8AA0B8; background: transparent; font-size: 10pt;")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        ctrl_row = QHBoxLayout()
        self.module_combo = QComboBox()
        modules = [
            ("ip", "🌐 Adresse IP"),
            ("username", "👤 Nom d'utilisateur"),
            ("domain", "🏠 Domaine"),
            ("email", "📧 Email"),
            ("mac", "💻 MAC Address"),
            ("vin", "🚗 VIN"),
        ]
        for mid, mname in modules:
            self.module_combo.addItem(mname, mid)
        ctrl_row.addWidget(QLabel("Module:"))
        ctrl_row.addWidget(self.module_combo)
        ctrl_row.addStretch()

        self.btn_file = QPushButton("📁 Charger fichier .txt")
        self.btn_file.setObjectName("secondary")
        self.btn_file.clicked.connect(self._load_file)
        ctrl_row.addWidget(self.btn_file)

        self.btn_run = QPushButton("▶ Lancer la recherche en lot")
        self.btn_run.clicked.connect(self._start)
        ctrl_row.addWidget(self.btn_run)

        self.btn_stop = QPushButton("⏹ Stop")
        self.btn_stop.setObjectName("secondary")
        self.btn_stop.setEnabled(False)
        self.btn_stop.clicked.connect(self._stop)
        ctrl_row.addWidget(self.btn_stop)
        layout.addLayout(ctrl_row)

        self.input_area = QTextEdit()
        self.input_area.setPlaceholderText("8.8.8.8\n1.1.1.1\n192.168.1.1\n...")
        self.input_area.setMaximumHeight(120)
        self.input_area.setStyleSheet("""
            QTextEdit { background: #0D1726; border: 1px solid #1A2A44; border-radius: 6px;
                        color: #EEF3FC; padding: 8px; font-family: 'Courier New'; font-size: 9pt; }
        """)
        layout.addWidget(self.input_area)

        self.progress = QProgressBar()
        self.progress.setFixedHeight(6)
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        self.progress.setStyleSheet("""
            QProgressBar { background: #1A2A44; border-radius: 3px; border: none; }
            QProgressBar::chunk { background: #7C3AED; border-radius: 3px; }
        """)
        layout.addWidget(self.progress)

        self.status_lbl = QLabel("Prêt — entrez vos cibles ci-dessus")
        self.status_lbl.setStyleSheet("color: #8AA0B8; font-size: 9pt; background: transparent;")
        layout.addWidget(self.status_lbl)

        self.table = ClickableTable(["Requête", "Champ", "Valeur", "Source"])
        layout.addWidget(self.table, 1)

        export_row = QHBoxLayout()
        export_row.addStretch()
        for label, fmt in [("CSV", "csv"), ("JSON", "json")]:
            btn = QPushButton(label)
            btn.setObjectName("secondary")
            btn.setFixedHeight(28)
            btn.setFixedWidth(60)
            btn.clicked.connect(lambda checked, f=fmt: self._export(f))
            export_row.addWidget(btn)
        layout.addLayout(export_row)

    def _load_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Charger liste", "", "Texte (*.txt *.csv)")
        if path:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                self.input_area.setPlainText(f.read())

    def _get_module_fn(self, mid):
        if mid == "ip":
            from modules.ip.ipapi import run
            return run
        elif mid == "username":
            from modules.username.sherlock import run
            return run
        elif mid == "domain":
            from modules.domain.whois_lookup import run
            return run
        elif mid == "email":
            from modules.email.holehe import run
            return run
        elif mid == "mac":
            from ui.views.mac_view import lookup_mac
            return lookup_mac
        elif mid == "vin":
            from ui.views.vin_view import decode_vin
            return decode_vin
        return None

    def _start(self):
        text = self.input_area.toPlainText().strip()
        queries = [q.strip() for q in text.splitlines() if q.strip()]
        if not queries:
            show_toast(self.window(), "Aucune cible saisie", "warning")
            return
        mid = self.module_combo.currentData()
        fn = self._get_module_fn(mid)
        if not fn:
            show_toast(self.window(), "Module non disponible", "error")
            return
        self.table.clear_data()
        self._all_results = []
        self.progress.setVisible(True)
        self.progress.setMaximum(len(queries))
        self.progress.setValue(0)
        self.btn_run.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self._worker = BatchWorker(fn, queries, self.cfg.get_timeout())
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_done)
        self._worker.start()

    def _on_progress(self, done, total, query, results):
        self.progress.setValue(done)
        self.status_lbl.setText(f"[{done}/{total}] {query}")
        for r in results:
            if isinstance(r, dict):
                row = {"Requête": query, "Champ": r.get("champ", r.get("Champ", "")),
                       "Valeur": r.get("valeur", r.get("Valeur", "")),
                       "Source": r.get("source", r.get("Source", ""))}
            else:
                row = {"Requête": query, "Champ": "", "Valeur": str(r), "Source": ""}
            self._all_results.append(row)
        self.table.load_data(self._all_results)

    def _on_done(self):
        self.btn_run.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.status_lbl.setText(f"✅ Terminé — {len(self._all_results)} entrées")
        show_toast(self.window(), f"Batch terminé — {len(self._all_results)} résultats", "success")

    def _stop(self):
        if self._worker:
            self._worker.stop()

    def _export(self, fmt):
        if not self._all_results:
            show_toast(self.window(), "Aucun résultat", "warning")
            return
        from core.report_generator import ReportGenerator
        gen = ReportGenerator("batch", "multiple", self._all_results)
        filters = {"csv": "CSV (*.csv)", "json": "JSON (*.json)"}
        path, _ = QFileDialog.getSaveFileName(self, "Exporter", "batch_export", filters.get(fmt, "*.*"))
        if path:
            getattr(gen, f"export_{fmt}")(path)
            show_toast(self.window(), "Exporté avec succès", "success")
