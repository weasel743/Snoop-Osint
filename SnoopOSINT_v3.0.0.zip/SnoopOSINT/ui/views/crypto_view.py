from ui.views.base_view import BaseView, WorkerThread
from modules.crypto import btc_balance

class CryptoView(BaseView):
    MODULE_NAME = "crypto"
    TITLE = "Crypto"
    ICON = "₿"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "Adresse BTC ou ETH..."

    def _run(self, query):
        self._worker = WorkerThread(btc_balance.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
