from ui.views.base_view import BaseView, WorkerThread
from modules.phone import phonenumbers_lib


class PhoneView(BaseView):
    MODULE_NAME = "phone"
    TITLE = "Téléphone"
    ICON = "📱"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: +33612345678"

    def _run(self, query):
        self._worker = WorkerThread(phonenumbers_lib.run, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
