import json
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QLineEdit, QPushButton, QComboBox)
from PyQt6.QtCore import Qt
from ui.widgets.clickable_table import ClickableTable
from ui.widgets.toast import show_toast
from core.database import Database
from core.language_manager import LanguageManager


class HistoryView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.db = Database()
        self.lang = LanguageManager()
        self._setup_ui()
        self._load()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        title = QLabel("📋 Historique")
        title.setStyleSheet("font-size: 15pt; font-weight: bold; color: #EEF3FC; background: transparent;")
        layout.addWidget(title)

        ctrl = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Rechercher dans l'historique...")
        self.search_input.textChanged.connect(self._search)
        ctrl.addWidget(self.search_input, 1)

        self.module_filter = QComboBox()
        self.module_filter.addItem("Tous les modules", "")
        for m in ["username", "email", "phone", "ip", "domain", "image", "social",
                  "crypto", "geo", "breach", "portscan", "github", "batch"]:
            self.module_filter.addItem(m.capitalize(), m)
        self.module_filter.currentIndexChanged.connect(self._load)
        ctrl.addWidget(self.module_filter)

        btn_refresh = QPushButton("🔄 Actualiser")
        btn_refresh.setObjectName("secondary")
        btn_refresh.clicked.connect(self._load)
        ctrl.addWidget(btn_refresh)

        btn_clear = QPushButton("🗑️ Effacer tout")
        btn_clear.setObjectName("secondary")
        btn_clear.clicked.connect(self._clear_all)
        ctrl.addWidget(btn_clear)
        layout.addLayout(ctrl)

        self.count_lbl = QLabel("")
        self.count_lbl.setStyleSheet("color: #8AA0B8; font-size: 9pt; background: transparent;")
        layout.addWidget(self.count_lbl)

        self.table = ClickableTable(["ID", "Module", "Requête", "Nb résultats", "Date"])
        layout.addWidget(self.table, 1)

        stats_lbl = QLabel("")
        stats_lbl.setObjectName("stats_lbl")
        layout.addWidget(stats_lbl)
        self._stats_lbl = stats_lbl

    def _load(self):
        module = self.module_filter.currentData() or None
        rows = self.db.get_history(limit=500, module=module)
        self._render(rows)
        stats = self.db.get_stats()
        self._stats_lbl.setStyleSheet("color: #4A5C70; font-size: 9pt; background: transparent;")
        self._stats_lbl.setText(
            f"Total: {stats['total']} recherches | "
            + " | ".join(f"{r['module']}:{r['c']}" for r in stats['by_module'][:6])
        )

    def _render(self, rows):
        data = [{"ID": str(r["id"]), "Module": r["module"], "Requête": r["query"],
                 "Nb résultats": str(r["result_count"]), "Date": r["timestamp"]}
                for r in rows]
        self.table.load_data(data)
        self.count_lbl.setText(f"{len(data)} entrées")

    def _search(self, text):
        if text:
            rows = self.db.search_history(text)
            self._render(rows)
        else:
            self._load()

    def _clear_all(self):
        module = self.module_filter.currentData() or None
        self.db.clear_history(module)
        self._load()
        show_toast(self.window(), "Historique effacé", "success")
