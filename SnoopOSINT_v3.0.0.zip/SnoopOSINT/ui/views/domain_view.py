from PyQt6.QtWidgets import QPushButton
from ui.views.base_view import BaseView, WorkerThread
from modules.domain import whois_lookup, dns_enum, ssl_info

class DomainView(BaseView):
    MODULE_NAME="domain"; TITLE="Domaine"; ICON="🌐"
    COLUMNS=["Champ","Valeur","Source"]; PLACEHOLDER="ex: example.com"
    def _extra_controls(self, row):
        for label, fn in [("DNS", self._run_dns), ("SSL", self._run_ssl)]:
            b = QPushButton(label); b.setObjectName("secondary"); b.setMinimumHeight(36)
            b.clicked.connect(fn); row.addWidget(b)
    def _run(self, q):
        self._set_loading(True)
        self._worker = WorkerThread(whois_lookup.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results); self._worker.error.connect(self._on_error); self._worker.start()
    def _run_dns(self):
        q = self.search_input.text().strip()
        if not q: return
        self._set_loading(True)
        self._worker = WorkerThread(dns_enum.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(lambda r: self._append(r)); self._worker.error.connect(self._on_error); self._worker.start()
    def _run_ssl(self):
        q = self.search_input.text().strip()
        if not q: return
        self._set_loading(True)
        self._worker = WorkerThread(ssl_info.run, q, timeout=self.cfg.get_timeout())
        self._worker.result.connect(lambda r: self._append(r)); self._worker.error.connect(self._on_error); self._worker.start()
    def _append(self, results):
        combined = self._results + results; self._results = combined
        self.table.load_data(combined); self.count_lbl.setText(f"{len(combined)} résultats")
        self._set_loading(False)
