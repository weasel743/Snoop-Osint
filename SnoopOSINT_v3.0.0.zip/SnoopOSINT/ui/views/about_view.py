from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout
from PyQt6.QtCore import Qt
import webbrowser

class AboutView(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40,30,40,30)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        logo = QLabel("⚡")
        logo.setStyleSheet("font-size:60px;background:transparent;")
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(logo)

        name = QLabel("Snoop OSINT")
        name.setStyleSheet("font-size:28pt;font-weight:900;color:#7C3AED;background:transparent;letter-spacing:3px;")
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(name)

        version = QLabel("v2.0.0 — The Reference OSINT Tool")
        version.setStyleSheet("color:#8AA0B8;font-size:12pt;background:transparent;")
        version.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(version)

        layout.addSpacing(20)

        features = QLabel(
            "✅ 26+ modules OSINT intégrés\n"
            "✅ 0 clef API requise pour démarrer\n"
            "✅ Thèmes personnalisables (10+)\n"
            "✅ Interface multilingue (6 langues)\n"
            "✅ Export CSV / JSON / PDF / HTML\n"
            "✅ Historique SQLite local\n"
            "✅ Système de plugins extensible\n"
            "✅ Animations temps réel (7 types)\n"
            "✅ Recherche en lot\n"
            "✅ Open Source — MIT License"
        )
        features.setStyleSheet("color:#EEF3FC;font-size:11pt;background:rgba(124,58,237,0.1);"
                               "border:1px solid rgba(124,58,237,0.3);border-radius:8px;padding:20px;")
        features.setAlignment(Qt.AlignmentFlag.AlignLeft)
        layout.addWidget(features)

        layout.addSpacing(20)

        disclaimer = QLabel(
            "⚠️ Avertissement légal\n"
            "Cet outil est destiné à des fins éducatives et de recherche légitime.\n"
            "N'utilisez Snoop OSINT que sur des cibles que vous êtes autorisé à analyser.\n"
            "L'auteur décline toute responsabilité pour un usage non autorisé."
        )
        disclaimer.setStyleSheet("color:#FBBF24;font-size:9pt;background:rgba(251,191,36,0.08);"
                                 "border:1px solid rgba(251,191,36,0.3);border-radius:6px;padding:12px;")
        disclaimer.setWordWrap(True)
        layout.addWidget(disclaimer)

        layout.addSpacing(16)

        btn_row = QHBoxLayout()
        btn_row.setAlignment(Qt.AlignmentFlag.AlignCenter)
        for label, url in [("🐙 GitHub", "https://github.com/snoop-osint"),
                            ("📖 Documentation", "https://github.com/snoop-osint/wiki"),
                            ("🐛 Signaler un bug", "https://github.com/snoop-osint/issues")]:
            btn = QPushButton(label)
            btn.setObjectName("secondary")
            btn.clicked.connect(lambda _, u=url: webbrowser.open(u))
            btn_row.addWidget(btn)
        layout.addLayout(btn_row)
        layout.addStretch()
