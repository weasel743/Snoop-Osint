from ui.views.base_view import BaseView, WorkerThread
import requests, re

HEADERS = {"User-Agent":"Mozilla/5.0"}

def search_company(name, timeout=10):
    results = []
    try:
        resp = requests.get("https://autocomplete.clearbit.com/v1/companies/suggest",
            params={"query":name}, headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            for c in resp.json()[:10]:
                results.append({"Champ":"Entreprise","Valeur":c.get("name",""),"Source":"Clearbit"})
                if c.get("domain"):
                    results.append({"Champ":"Domaine","Valeur":c["domain"],"Source":"Clearbit"})
                if c.get("logo"):
                    results.append({"Champ":"Logo URL","Valeur":c["logo"],"Source":"Clearbit"})
    except Exception:
        pass
    try:
        resp2 = requests.get("https://api.openapi.io/api/company/v1/search",
            params={"q":name,"limit":5}, headers=HEADERS, timeout=timeout)
    except Exception:
        pass
    try:
        resp3 = requests.get("https://companies.eu/api/v1/search",
            params={"name":name,"country":"FR"}, headers=HEADERS, timeout=timeout)
        if resp3.status_code == 200:
            data = resp3.json()
            for c in data.get("companies",[])[:5]:
                results.append({"Champ":c.get("type",""),"Valeur":c.get("name",""),"Source":"Companies.eu"})
    except Exception:
        pass
    if not results:
        results.append({"Champ":"Info","Valeur":"Aucun résultat — essayez le nom exact","Source":"N/A"})
    return results

class CompanyView(BaseView):
    MODULE_NAME = "company"
    TITLE = "Entreprise"
    ICON = "🏢"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "ex: Google, Apple, SNCF..."

    def _run(self, query):
        self._worker = WorkerThread(search_company, query, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
