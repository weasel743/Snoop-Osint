from ui.views.base_view import BaseView, WorkerThread
from modules.social import github_scan

class SocialView(BaseView):
    MODULE_NAME = "social"
    TITLE = "Réseaux sociaux"
    ICON = "💬"
    COLUMNS = ["Réseau", "Info", "Valeur", "Source"]
    PLACEHOLDER = "Pseudo, email ou URL..."

    def _run(self, query):
        self._worker = WorkerThread(self._aggregate, query)
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _aggregate(self, query):
        results = []
        gh = github_scan.run(query, timeout=self.cfg.get_timeout())
        for r in gh:
            results.append({"Réseau": "GitHub", "Info": r["champ"], "Valeur": r["valeur"], "Source": r["source"]})
        return results
