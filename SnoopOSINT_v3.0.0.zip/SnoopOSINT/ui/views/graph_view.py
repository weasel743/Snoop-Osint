"""
Vue Graphe — visualisation interactive des nœuds de corrélation
"""
import math
import random
from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                              QPushButton, QSlider, QFileDialog, QToolTip)
from PyQt6.QtCore import Qt, QPointF, QRectF, QTimer, pyqtSignal
from PyQt6.QtGui import (QPainter, QPen, QBrush, QColor, QFont,
                          QPainterPath, QRadialGradient, QImage)

from modules.correlation.engine import NODE_COLORS


class GraphCanvas(QWidget):
    node_clicked = pyqtSignal(dict)
    node_double_clicked = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.nodes = {}    # id -> {x, y, data}
        self.edges = []    # list of {src, dst, label}
        self._dragging = None
        self._drag_offset = QPointF(0, 0)
        self._pan_start = None
        self._pan_offset = QPointF(0, 0)
        self._zoom = 1.0
        self._hovered = None
        self.setMouseTracking(True)
        self.setMinimumSize(400, 300)
        self._anim_timer = QTimer(self)
        self._anim_timer.timeout.connect(self._relax_step)
        self._anim_timer.start(50)
        self._pulse = 0

    def set_graph(self, nodes_list, edges_list):
        self.nodes = {}
        self.edges = edges_list[:]
        cx, cy = self.width() / 2 or 400, self.height() / 2 or 300
        for i, n in enumerate(nodes_list):
            angle = 2 * math.pi * i / max(len(nodes_list), 1)
            r = min(cx, cy) * 0.6
            self.nodes[n["id"]] = {
                "x": cx + r * math.cos(angle),
                "y": cy + r * math.sin(angle),
                "vx": 0.0, "vy": 0.0,
                "data": n
            }
        self.update()

    def add_node(self, node_data):
        nid = node_data["id"]
        if nid not in self.nodes:
            cx = self.width() / 2 or 400
            cy = self.height() / 2 or 300
            self.nodes[nid] = {
                "x": cx + random.uniform(-150, 150),
                "y": cy + random.uniform(-150, 150),
                "vx": 0.0, "vy": 0.0,
                "data": node_data
            }
        self.update()

    def add_edge(self, edge_data):
        for e in self.edges:
            if e["src"] == edge_data["src"] and e["dst"] == edge_data["dst"]:
                return
        self.edges.append(edge_data)
        self.update()

    def _relax_step(self):
        self._pulse = (self._pulse + 0.05) % (2 * math.pi)
        nodes = list(self.nodes.values())
        n = len(nodes)
        if n < 2:
            self.update()
            return
        K = 80.0
        for i in range(n):
            for j in range(i + 1, n):
                dx = nodes[i]["x"] - nodes[j]["x"]
                dy = nodes[i]["y"] - nodes[j]["y"]
                dist = max(math.sqrt(dx*dx + dy*dy), 1)
                force = (K * K) / dist
                nodes[i]["vx"] += force * dx / dist
                nodes[i]["vy"] += force * dy / dist
                nodes[j]["vx"] -= force * dx / dist
                nodes[j]["vy"] -= force * dy / dist
        edge_map = {(e["src"], e["dst"]) for e in self.edges}
        for eid, n1 in self.nodes.items():
            for eid2, n2 in self.nodes.items():
                if eid == eid2: continue
                if (eid, eid2) in edge_map or (eid2, eid) in edge_map:
                    dx = n2["x"] - n1["x"]
                    dy = n2["y"] - n1["y"]
                    dist = max(math.sqrt(dx*dx + dy*dy), 1)
                    force = (dist - K) / dist * 0.05
                    n1["vx"] += force * dx
                    n1["vy"] += force * dy
        damp = 0.85
        margin = 40
        W = self.width() or 800
        H = self.height() or 600
        for node in self.nodes.values():
            node["vx"] *= damp
            node["vy"] *= damp
            node["x"] = max(margin, min(W - margin, node["x"] + node["vx"]))
            node["y"] = max(margin, min(H - margin, node["y"] + node["vy"]))
        self.update()

    def _world_to_screen(self, x, y):
        cx, cy = self.width() / 2, self.height() / 2
        sx = (x - cx) * self._zoom + cx + self._pan_offset.x()
        sy = (y - cy) * self._zoom + cy + self._pan_offset.y()
        return sx, sy

    def _screen_to_world(self, sx, sy):
        cx, cy = self.width() / 2, self.height() / 2
        wx = (sx - cx - self._pan_offset.x()) / self._zoom + cx
        wy = (sy - cy - self._pan_offset.y()) / self._zoom + cy
        return wx, wy

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(self.rect(), QColor("#0A0E17"))

        # Grille de fond
        grid_col = QColor("#0D1726")
        painter.setPen(QPen(grid_col, 1))
        step = 40
        for x in range(0, self.width(), step):
            painter.drawLine(x, 0, x, self.height())
        for y in range(0, self.height(), step):
            painter.drawLine(0, y, self.width(), y)

        # Arêtes
        for edge in self.edges:
            n1 = self.nodes.get(edge["src"])
            n2 = self.nodes.get(edge["dst"])
            if not n1 or not n2: continue
            x1, y1 = self._world_to_screen(n1["x"], n1["y"])
            x2, y2 = self._world_to_screen(n2["x"], n2["y"])
            edge_color = QColor("#1A2A44")
            painter.setPen(QPen(edge_color, 1.5))
            painter.drawLine(int(x1), int(y1), int(x2), int(y2))
            # Label arête
            if edge.get("label"):
                mx, my = (x1+x2)/2, (y1+y2)/2
                painter.setPen(QColor("#4A5C70"))
                painter.setFont(QFont("Segoe UI", 7))
                painter.drawText(int(mx)+2, int(my)-2, edge["label"])

        # Nœuds
        for nid, node in self.nodes.items():
            d = node["data"]
            ntype = d.get("type", "")
            color = QColor(NODE_COLORS.get(ntype, "#7C3AED"))
            sx, sy = self._world_to_screen(node["x"], node["y"])
            is_hovered = nid == self._hovered
            pulse = abs(math.sin(self._pulse)) * 0.3
            radius = int(18 * self._zoom * (1.1 if is_hovered else 1.0))
            # Glow
            glow = QColor(color); glow.setAlpha(int((40 + pulse*30)))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(glow))
            painter.drawEllipse(int(sx - radius*1.8), int(sy - radius*1.8),
                                int(radius*3.6), int(radius*3.6))
            # Corps
            painter.setBrush(QBrush(color))
            border_col = QColor("#FFFFFF") if is_hovered else color.lighter(150)
            painter.setPen(QPen(border_col, 2 if is_hovered else 1))
            painter.drawEllipse(int(sx - radius), int(sy - radius), radius*2, radius*2)
            # Icône type
            icon_map = {"email":"@","username":"👤","domain":"🌐","ip":"🔌",
                        "phone":"📱","name":"👤","platform":"💬","breach":"🔓",
                        "crypto":"₿","org":"🏢","url":"🔗"}
            icon = icon_map.get(ntype, "?")
            painter.setPen(QColor("white"))
            painter.setFont(QFont("Segoe UI", max(8, int(10 * self._zoom))))
            painter.drawText(QRectF(sx-radius, sy-radius, radius*2, radius*2),
                             Qt.AlignmentFlag.AlignCenter, icon)
            # Label
            label = d.get("value","")[:20]
            painter.setPen(QColor("#EEF3FC"))
            painter.setFont(QFont("Segoe UI", max(7, int(8 * self._zoom))))
            painter.drawText(int(sx - 50), int(sy + radius + 12), 100, 16,
                             Qt.AlignmentFlag.AlignCenter, label)
            # Score confiance
            conf = d.get("confidence", 100)
            conf_col = QColor("#34D399") if conf >= 80 else QColor("#FBBF24") if conf >= 60 else QColor("#F87171")
            painter.setPen(conf_col)
            painter.setFont(QFont("Segoe UI", 6))
            painter.drawText(int(sx - 15), int(sy + radius + 24), 30, 12,
                             Qt.AlignmentFlag.AlignCenter, f"{conf}%")
        painter.end()

    def _node_at(self, x, y):
        for nid, node in self.nodes.items():
            sx, sy = self._world_to_screen(node["x"], node["y"])
            if (sx - x)**2 + (sy - y)**2 <= (20 * self._zoom)**2:
                return nid
        return None

    def mousePressEvent(self, event):
        nid = self._node_at(event.pos().x(), event.pos().y())
        if nid:
            self._dragging = nid
            node = self.nodes[nid]
            sx, sy = self._world_to_screen(node["x"], node["y"])
            self._drag_offset = QPointF(sx - event.pos().x(), sy - event.pos().y())
        else:
            self._pan_start = event.pos()

    def mouseMoveEvent(self, event):
        if self._dragging:
            node = self.nodes[self._dragging]
            sx = event.pos().x() + self._drag_offset.x()
            sy = event.pos().y() + self._drag_offset.y()
            node["x"], node["y"] = self._screen_to_world(sx, sy)
            node["vx"] = node["vy"] = 0
            self.update()
        elif self._pan_start:
            delta = event.pos() - self._pan_start
            self._pan_offset += QPointF(delta.x(), delta.y())
            self._pan_start = event.pos()
            self.update()
        else:
            nid = self._node_at(event.pos().x(), event.pos().y())
            if nid != self._hovered:
                self._hovered = nid
                if nid:
                    d = self.nodes[nid]["data"]
                    QToolTip.showText(event.globalPosition().toPoint(),
                        f"<b>{d.get('value','')}</b><br>Type: {d.get('type','')}<br>"
                        f"Source: {d.get('source','')}<br>Confiance: {d.get('confidence','')}%")
                self.update()

    def mouseReleaseEvent(self, event):
        if self._dragging:
            nid = self._node_at(event.pos().x(), event.pos().y())
            if nid == self._dragging:
                self.node_clicked.emit(self.nodes[nid]["data"])
        self._dragging = None
        self._pan_start = None

    def mouseDoubleClickEvent(self, event):
        nid = self._node_at(event.pos().x(), event.pos().y())
        if nid:
            self.node_double_clicked.emit(self.nodes[nid]["data"])

    def wheelEvent(self, event):
        delta = event.angleDelta().y()
        factor = 1.1 if delta > 0 else 0.9
        self._zoom = max(0.3, min(3.0, self._zoom * factor))
        self.update()

    def reset_view(self):
        self._zoom = 1.0
        self._pan_offset = QPointF(0, 0)
        self.update()

    def export_image(self, path):
        img = QImage(self.size(), QImage.Format.Format_RGB32)
        img.fill(QColor("#0A0E17"))
        painter = QPainter(img)
        self.render(painter)
        painter.end()
        img.save(path)
        return path


class GraphView(QWidget):
    navigate_to = pyqtSignal(str, str)  # view_id, query

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Toolbar
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(12, 8, 12, 8)
        title = QLabel("🕸️ Graphe de corrélation")
        title.setStyleSheet("font-size:12pt;font-weight:bold;color:#EEF3FC;background:transparent;")
        toolbar.addWidget(title)
        toolbar.addStretch()

        self.node_count_lbl = QLabel("0 nœuds")
        self.node_count_lbl.setStyleSheet("color:#8AA0B8;background:transparent;font-size:9pt;")
        toolbar.addWidget(self.node_count_lbl)

        btn_reset = QPushButton("⌖ Recentrer")
        btn_reset.setObjectName("secondary"); btn_reset.setFixedHeight(28)
        btn_reset.clicked.connect(lambda: self.canvas.reset_view())
        toolbar.addWidget(btn_reset)

        btn_export = QPushButton("📷 Exporter PNG")
        btn_export.setObjectName("secondary"); btn_export.setFixedHeight(28)
        btn_export.clicked.connect(self._export_png)
        toolbar.addWidget(btn_export)

        btn_clear = QPushButton("🗑 Effacer")
        btn_clear.setObjectName("secondary"); btn_clear.setFixedHeight(28)
        btn_clear.clicked.connect(self.clear)
        toolbar.addWidget(btn_clear)

        toolbar_w = QWidget()
        toolbar_w.setStyleSheet("background:#0D1726;border-bottom:1px solid #1A2A44;")
        toolbar_w.setLayout(toolbar)
        layout.addWidget(toolbar_w)

        # Canvas
        self.canvas = GraphCanvas()
        self.canvas.node_clicked.connect(self._on_node_click)
        self.canvas.node_double_clicked.connect(self._on_node_double_click)
        layout.addWidget(self.canvas, 1)

        # Detail panel
        self.detail = QLabel("Cliquez sur un nœud pour voir ses détails")
        self.detail.setStyleSheet("""
            background:#0D1726;border-top:1px solid #1A2A44;
            color:#8AA0B8;padding:8px 14px;font-size:9pt;
        """)
        self.detail.setMinimumHeight(36)
        layout.addWidget(self.detail)

    def load_graph(self, nodes, edges):
        self.canvas.set_graph(nodes, edges)
        self.node_count_lbl.setText(f"{len(nodes)} nœuds · {len(edges)} liens")

    def add_node(self, node_data):
        self.canvas.add_node(node_data)
        self.node_count_lbl.setText(
            f"{len(self.canvas.nodes)} nœuds · {len(self.canvas.edges)} liens")

    def add_edge(self, edge_data):
        self.canvas.add_edge(edge_data)

    def clear(self):
        self.canvas.nodes = {}
        self.canvas.edges = []
        self.node_count_lbl.setText("0 nœuds")
        self.canvas.update()

    def _on_node_click(self, data):
        self.detail.setText(
            f"<b style='color:#A78BFA'>{data.get('value','')}</b> "
            f"| Type: <b>{data.get('type','')}</b> "
            f"| Source: {data.get('source','')} "
            f"| Confiance: <b style='color:#34D399'>{data.get('confidence','')}%</b> "
            f"— Double-cliquez pour relancer une recherche")
        self.detail.setTextFormat(Qt.TextFormat.RichText)

    def _on_node_double_click(self, data):
        ntype = data.get("type","")
        value = data.get("value","")
        view_map = {
            "email":"email","username":"username","domain":"domain",
            "ip":"ip","phone":"phone","crypto":"crypto","org":"company",
        }
        view_id = view_map.get(ntype, "username")
        self.navigate_to.emit(view_id, value)

    def _export_png(self):
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(self, "Exporter graphe", "graphe_correlation", "PNG (*.png)")
        if path:
            self.canvas.export_image(path)
            from ui.widgets.toast import show_toast
            show_toast(self.window(), f"Graphe exporté", "success")
