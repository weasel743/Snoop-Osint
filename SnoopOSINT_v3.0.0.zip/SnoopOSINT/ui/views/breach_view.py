from ui.views.base_view import BaseView, WorkerThread
from modules.breach import hibp_breach

class BreachView(BaseView):
    MODULE_NAME = "breach"
    TITLE = "Fuites de données"
    ICON = "🔓"
    COLUMNS = ["Source", "Date", "Nb victimes", "Description", "Types de données", "Sévérité"]
    PLACEHOLDER = "ex: john@example.com"

    def _run(self, query):
        api_key = self.cfg.get("api_keys", "hibp", default="")
        self._worker = WorkerThread(hibp_breach.run, query, api_key=api_key, timeout=self.cfg.get_timeout())
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
