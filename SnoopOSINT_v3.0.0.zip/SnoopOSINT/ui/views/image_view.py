from PyQt6.QtWidgets import QPushButton, QFileDialog
from ui.views.base_view import BaseView, WorkerThread
from modules.image import exif_extract


class ImageView(BaseView):
    MODULE_NAME = "image"
    TITLE = "Image / EXIF"
    ICON = "🖼️"
    COLUMNS = ["Champ", "Valeur", "Source"]
    PLACEHOLDER = "Chemin de l'image ou URL..."

    def _extra_controls(self, row):
        self.btn_browse = QPushButton("📁 Parcourir")
        self.btn_browse.setObjectName("secondary")
        self.btn_browse.setMinimumHeight(36)
        self.btn_browse.clicked.connect(self._browse)
        row.addWidget(self.btn_browse)

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Sélectionner une image", "",
            "Images (*.jpg *.jpeg *.png *.tiff *.webp *.bmp *.gif *.heic *.raw)"
        )
        if path:
            self.search_input.setText(path)
            self._start_search()

    def _run(self, query):
        self._worker = WorkerThread(exif_extract.run, query)
        self._worker.result.connect(self._on_results)
        self._worker.error.connect(self._on_error)
        self._worker.start()
