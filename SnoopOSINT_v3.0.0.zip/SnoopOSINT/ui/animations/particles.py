import random
import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QColor, QPen


class ParticlesWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.particles = []
        self.connection_dist = 120
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)
        self._init_particles()

    def _init_particles(self):
        w, h = max(self.width(), 800), max(self.height(), 600)
        self.particles = [
            {"x": random.uniform(0, w), "y": random.uniform(0, h),
             "vx": random.uniform(-0.5, 0.5), "vy": random.uniform(-0.5, 0.5),
             "size": random.uniform(2, 4)}
            for _ in range(50)
        ]

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._init_particles()

    def _tick(self):
        w, h = max(self.width(), 800), max(self.height(), 600)
        for p in self.particles:
            p["x"] += p["vx"]
            p["y"] += p["vy"]
            if p["x"] < 0 or p["x"] > w:
                p["vx"] *= -1
            if p["y"] < 0 or p["y"] > h:
                p["vy"] *= -1
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        parts = self.particles
        n = len(parts)
        for i in range(n):
            for j in range(i + 1, n):
                dx = parts[i]["x"] - parts[j]["x"]
                dy = parts[i]["y"] - parts[j]["y"]
                dist = math.sqrt(dx * dx + dy * dy)
                if dist < self.connection_dist:
                    alpha = int((1 - dist / self.connection_dist) * 80)
                    c = QColor(self.accent)
                    c.setAlpha(alpha)
                    painter.setPen(QPen(c, 1))
                    painter.drawLine(int(parts[i]["x"]), int(parts[i]["y"]),
                                     int(parts[j]["x"]), int(parts[j]["y"]))
        for p in parts:
            c = QColor(self.accent)
            c.setAlpha(180)
            painter.setPen(Qt.PenStyle.NoPen)
            from PyQt6.QtGui import QBrush
            painter.setBrush(QBrush(c))
            painter.drawEllipse(int(p["x"] - p["size"]), int(p["y"] - p["size"]),
                                int(p["size"] * 2), int(p["size"] * 2))
        painter.end()

    def set_enabled(self, enabled):
        if enabled:
            self._timer.start(50)
        else:
            self._timer.stop()
