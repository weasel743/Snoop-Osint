import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt, QPointF
from PyQt6.QtGui import QPainter, QColor, QConicalGradient

class GradientWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.t = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(60)

    def _tick(self):
        self.t += 0.01
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        cx, cy = self.width() / 2, self.height() / 2
        angle = self.t * 30
        grad = QConicalGradient(QPointF(cx, cy), angle)
        c1 = QColor(self.accent); c1.setAlpha(40)
        c2 = QColor(self.accent); c2.setAlpha(5)
        grad.setColorAt(0, c1)
        grad.setColorAt(0.5, c2)
        grad.setColorAt(1, c1)
        from PyQt6.QtGui import QBrush
        painter.setBrush(QBrush(grad))
        painter.setPen(Qt.PenStyle.NoPen)
        size = max(self.width(), self.height()) * 1.5
        painter.drawEllipse(int(cx - size/2), int(cy - size/2), int(size), int(size))
        painter.end()

    def set_enabled(self, en):
        self._timer.start(60) if en else self._timer.stop()
