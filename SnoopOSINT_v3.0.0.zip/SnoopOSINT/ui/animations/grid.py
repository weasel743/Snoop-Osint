import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QColor, QBrush

class GridWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.t = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)

    def _tick(self):
        self.t += 0.05
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        spacing = 40
        for x in range(0, self.width() + spacing, spacing):
            for y in range(0, self.height() + spacing, spacing):
                d = math.sqrt((x - self.width()/2)**2 + (y - self.height()/2)**2)
                pulse = (math.sin(self.t - d * 0.02) + 1) / 2
                size = 2 + int(pulse * 3)
                alpha = int(30 + pulse * 80)
                c = QColor(self.accent); c.setAlpha(alpha)
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QBrush(c))
                painter.drawEllipse(x - size, y - size, size * 2, size * 2)
        painter.end()

    def set_enabled(self, en):
        self._timer.start(50) if en else self._timer.stop()
