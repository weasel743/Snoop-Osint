import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QColor, QPen, QPainterPath

class WavesWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.t = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(40)

    def _tick(self):
        self.t += 0.04
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        h = self.height()
        w = self.width()
        for wave_idx in range(3):
            path = QPainterPath()
            phase = self.t + wave_idx * 1.2
            amp = 20 + wave_idx * 10
            freq = 0.015 - wave_idx * 0.003
            y_base = h * (0.3 + wave_idx * 0.2)
            path.moveTo(0, y_base)
            for x in range(0, w + 5, 5):
                y = y_base + amp * math.sin(x * freq + phase)
                path.lineTo(x, y)
            alpha = 60 - wave_idx * 15
            c = QColor(self.accent); c.setAlpha(alpha)
            painter.setPen(QPen(c, 2))
            painter.drawPath(path)
        painter.end()

    def set_enabled(self, en):
        self._timer.start(40) if en else self._timer.stop()
