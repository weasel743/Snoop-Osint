import random, math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush

class NeuralWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.nodes = []
        self.edges = []
        self.tick_count = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(50)
        self._init_network()

    def _init_network(self):
        w, h = max(self.width(), 800), max(self.height(), 600)
        layers = [4, 6, 8, 6, 4]
        self.nodes = []
        self.edges = []
        layer_x = [int(w * (i + 1) / (len(layers) + 1)) for i in range(len(layers))]
        node_idx = 0
        layer_nodes = []
        for li, (lx, count) in enumerate(zip(layer_x, layers)):
            nodes_in_layer = []
            for ni in range(count):
                y = int(h * (ni + 1) / (count + 1))
                self.nodes.append({"x": lx, "y": y, "pulse": random.uniform(0, math.pi * 2), "id": node_idx})
                nodes_in_layer.append(node_idx)
                node_idx += 1
            layer_nodes.append(nodes_in_layer)
        for li in range(len(layer_nodes) - 1):
            for n1 in layer_nodes[li]:
                for n2 in layer_nodes[li + 1]:
                    if random.random() < 0.6:
                        self.edges.append((n1, n2, random.uniform(0, math.pi * 2)))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._init_network()

    def _tick(self):
        self.tick_count += 1
        for n in self.nodes:
            n["pulse"] += 0.08
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        for (i, j, phase) in self.edges:
            n1, n2 = self.nodes[i], self.nodes[j]
            pulse = abs(math.sin(self.tick_count * 0.05 + phase))
            alpha = int(20 + pulse * 60)
            c = QColor(self.accent); c.setAlpha(alpha)
            painter.setPen(QPen(c, 1))
            painter.drawLine(n1["x"], n1["y"], n2["x"], n2["y"])
        for n in self.nodes:
            pulse = (math.sin(n["pulse"]) + 1) / 2
            size = 4 + int(pulse * 4)
            c = QColor(self.accent); c.setAlpha(int(100 + pulse * 120))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(c))
            painter.drawEllipse(n["x"] - size, n["y"] - size, size * 2, size * 2)
        painter.end()

    def set_enabled(self, en):
        self._timer.start(50) if en else self._timer.stop()
