import random
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QColor, QFont


class MatrixWidget(QWidget):
    CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%^&*()アイウエオカキクケコ"

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.columns = []
        self.font_size = 14
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(60)
        self._init_columns()

    def _init_columns(self):
        w = max(self.width(), 400)
        col_count = w // self.font_size
        self.columns = [
            {"y": random.randint(-500, 0), "speed": random.randint(2, 6),
             "chars": [random.choice(self.CHARS) for _ in range(30)]}
            for _ in range(col_count)
        ]

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._init_columns()

    def _tick(self):
        h = max(self.height(), 400)
        for col in self.columns:
            col["y"] += col["speed"]
            if col["y"] > h + 200:
                col["y"] = random.randint(-300, -50)
                col["speed"] = random.randint(2, 6)
                col["chars"] = [random.choice(self.CHARS) for _ in range(30)]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        font = QFont("Courier New", self.font_size)
        painter.setFont(font)
        w = self.width()
        fs = self.font_size
        for i, col in enumerate(self.columns):
            x = i * fs
            for j, ch in enumerate(col["chars"]):
                y = col["y"] - j * fs
                if y < 0 or y > self.height():
                    continue
                if j == 0:
                    color = QColor(180, 255, 180, 220)
                elif j < 4:
                    alpha = max(0, 200 - j * 30)
                    color = QColor(0, 200, 50, alpha)
                else:
                    alpha = max(0, 130 - j * 5)
                    color = QColor(0, 150, 30, alpha)
                painter.setPen(color)
                painter.drawText(x, y, ch)
        painter.end()

    def set_enabled(self, enabled):
        if enabled:
            self._timer.start(60)
        else:
            self._timer.stop()
            self.update()
