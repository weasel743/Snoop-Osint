import random
import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QPainter, QPen, QColor, QPainterPath


class LightningWidget(QWidget):
    def __init__(self, parent=None, accent="#7C3AED"):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self.accent = QColor(accent)
        self.bolts = []
        self._render_timer = QTimer(self)
        self._render_timer.timeout.connect(self._tick)
        self._render_timer.start(40)
        self._spawn_timer = QTimer(self)
        self._spawn_timer.timeout.connect(self._spawn)
        self._spawn_timer.start(2800)
        self._spawn()

    def set_accent(self, hex_color):
        self.accent = QColor(hex_color)

    def set_enabled(self, enabled):
        if enabled:
            self._render_timer.start(40)
            self._spawn_timer.start(2800)
        else:
            self._render_timer.stop()
            self._spawn_timer.stop()
            self.bolts.clear()
            self.update()

    def _spawn(self):
        if not self.isVisible() or self.width() < 10:
            return
        count = random.randint(1, 2)
        for _ in range(count):
            x = random.randint(50, max(51, self.width() - 50))
            y = random.randint(10, max(11, int(self.height() * 0.5)))
            segments = self._make_bolt(x, y)
            life = random.randint(15, 30)
            self.bolts.append({"segments": segments, "life": life, "max_life": life})

    def _make_bolt(self, start_x, start_y):
        segments = []
        cx, cy = start_x, start_y
        steps = random.randint(5, 9)
        for i in range(steps):
            direction = 1 if i % 2 == 0 else -1
            nx = cx + direction * random.randint(20, 60)
            ny = cy + random.randint(15, 35)
            segments.append((cx, cy, nx, ny))
            cx, cy = nx, ny
        return segments

    def _tick(self):
        for bolt in self.bolts[:]:
            bolt["life"] -= 1
            if bolt["life"] <= 0:
                self.bolts.remove(bolt)
        self.update()

    def paintEvent(self, event):
        if not self.bolts:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        for bolt in self.bolts:
            ratio = bolt["life"] / bolt["max_life"]
            alpha = int(ratio * 200)
            segs = bolt["segments"]
            path = QPainterPath()
            if segs:
                path.moveTo(segs[0][0], segs[0][1])
                for (x1, y1, x2, y2) in segs:
                    path.lineTo(x2, y2)
            glow = QColor(self.accent)
            glow.setAlpha(int(alpha * 0.4))
            glow_pen = QPen(glow, 8)
            glow_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(glow_pen)
            painter.drawPath(path)
            mid_glow = QColor(self.accent)
            mid_glow.setAlpha(int(alpha * 0.6))
            mid_pen = QPen(mid_glow, 4)
            mid_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(mid_pen)
            painter.drawPath(path)
            core = QColor(220, 220, 255, alpha)
            core_pen = QPen(core, 1.5)
            core_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            painter.setPen(core_pen)
            painter.drawPath(path)
        painter.end()
