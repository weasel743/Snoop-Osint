import sys
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QStackedWidget, QApplication, QFrame, QLabel
from PyQt6.QtCore import Qt
from core.config_manager import ConfigManager
from core.theme_manager import ThemeManager
from core.language_manager import LanguageManager
from ui.sidebar import Sidebar
from ui.header import Header

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.cfg = ConfigManager(); self.theme_mgr = ThemeManager(); self.lang = LanguageManager()
        self._views = {}; self._anim_widget = None
        self._setup_window(); self._apply_theme(); self._setup_ui(); self._navigate("dashboard")
    def _setup_window(self):
        w = self.cfg.get("ui","window","width",default=1400)
        h = self.cfg.get("ui","window","height",default=850)
        self.resize(w,h); self.setMinimumSize(1000,650)
        self.setWindowTitle("⚡ Snoop OSINT v3")
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Window)
        if self.cfg.get("ui","window","maximized",default=False): self.showMaximized()
    def _apply_theme(self):
        self.theme_mgr.apply_theme(QApplication.instance(), self.cfg.get("app","theme",default="violet"))
    def _setup_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        outer = QVBoxLayout(central); outer.setContentsMargins(0,0,0,0); outer.setSpacing(0)
        self.header = Header(self)
        self.header.theme_changed.connect(self._on_theme)
        self.header.language_changed.connect(lambda c: None)
        self.header.global_search.connect(self._global_search)
        outer.addWidget(self.header)
        body = QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)
        self.sidebar = Sidebar(self); self.sidebar.navigate.connect(self._navigate); body.addWidget(self.sidebar)
        self.content_frame = QFrame()
        self.content_frame.setObjectName("content_frame")
        self.content_frame.setStyleSheet("QFrame#content_frame{background:#0A0E17;}")
        cl = QVBoxLayout(self.content_frame); cl.setContentsMargins(0,0,0,0)
        self.stack = QStackedWidget(); self.stack.setStyleSheet("background:transparent;"); cl.addWidget(self.stack)
        body.addWidget(self.content_frame, 1)
        outer.addLayout(body, 1)
        self._start_animation()
    def _get_view(self, vid):
        if vid in self._views: return self._views[vid]
        v = self._create_view(vid)
        if v: self.stack.addWidget(v); self._views[vid] = v
        return v
    def _create_view(self, vid):
        try:
            if vid=="dashboard":
                from ui.views.dashboard_view import DashboardView; v=DashboardView(); v.navigate.connect(self._navigate); return v
            elif vid=="correlation":
                from ui.views.correlation_view import CorrelationView; v=CorrelationView(); v.navigate_to.connect(self._navigate_with_query); return v
            elif vid=="username":
                from ui.views.username_view import UsernameView; return UsernameView()
            elif vid=="email":
                from ui.views.email_view import EmailView; return EmailView()
            elif vid=="phone":
                from ui.views.phone_view import PhoneView; return PhoneView()
            elif vid=="ip":
                from ui.views.ip_view import IpView; return IpView()
            elif vid=="domain":
                from ui.views.domain_view import DomainView; return DomainView()
            elif vid=="image":
                from ui.views.image_view import ImageView; return ImageView()
            elif vid=="metadata":
                from ui.views.metadata_view import MetadataView; return MetadataView()
            elif vid=="social":
                from ui.views.github_view import GithubView; return GithubView()
            elif vid=="crypto":
                from ui.views.crypto_view import CryptoView; return CryptoView()
            elif vid=="geo":
                from ui.views.geo_view import GeoView; return GeoView()
            elif vid=="breach":
                from ui.views.breach_view import BreachView; return BreachView()
            elif vid=="paste":
                from ui.views.paste_view import PasteView; return PasteView()
            elif vid=="portscan":
                from ui.views.portscan_view import PortscanView; return PortscanView()
            elif vid=="dns":
                from ui.views.dns_view import DnsView; return DnsView()
            elif vid=="ssl":
                from ui.views.ssl_view import SslView; return SslView()
            elif vid=="dorking":
                from ui.views.dorking_view import DorkingView; return DorkingView()
            elif vid=="shodan":
                from ui.views.shodan_view import ShodanView; return ShodanView()
            elif vid=="bodacc":
                from ui.views.france_view import FranceBodaccView; return FranceBodaccView()
            elif vid=="infogreffe":
                from ui.views.france_view import FranceInfogreffeView; return FranceInfogreffeView()
            elif vid=="pagesjaunes":
                from ui.views.france_view import FrancePagesJaunesView; return FrancePagesJaunesView()
            elif vid=="datafr":
                from ui.views.france_view import FranceDataGouv; return FranceDataGouv()
            elif vid=="graph":
                from ui.views.graph_view import GraphView; v=GraphView(); v.navigate_to.connect(self._navigate_with_query); return v
            elif vid=="timeline":
                from ui.views.timeline_view import TimelineView; return TimelineView()
            elif vid=="batch":
                from ui.views.batch_view import BatchView; return BatchView()
            elif vid=="history":
                from ui.views.history_view import HistoryView; return HistoryView()
            elif vid=="plugins":
                from ui.views.plugins_view import PluginsView; return PluginsView()
            elif vid=="settings":
                from ui.views.settings_view import SettingsView; v=SettingsView(); v.theme_changed.connect(self._on_theme); return v
            elif vid=="about":
                from ui.views.about_view import AboutView; return AboutView()
            elif vid in ("company","vin","wifi","mac","company","person","darkweb"):
                from ui.views import company_view, vin_view, wifi_view, mac_view, person_view, darkweb_view
                m = {"company":company_view.CompanyView,"vin":vin_view.VinView,"wifi":wifi_view.WifiView,
                     "mac":mac_view.MacView,"person":person_view.PersonView,"darkweb":darkweb_view.DarkwebView}
                return m[vid]() if vid in m else None
        except Exception as e:
            lbl = QLabel(f"❌ Erreur vue '{vid}': {e}")
            lbl.setStyleSheet("color:#F87171;padding:40px;font-size:11pt;background:transparent;")
            return lbl
        return None
    def _navigate(self, vid):
        v = self._get_view(vid)
        if v: self.stack.setCurrentWidget(v); self.sidebar.set_active(vid)
    def _navigate_with_query(self, vid, query):
        self._navigate(vid)
        v = self._views.get(vid)
        if v and hasattr(v,"search_input"):
            v.search_input.setText(query)
            if hasattr(v,"_start_search"): v._start_search()
        elif v and hasattr(v,"start_with_query"):
            v.start_with_query(query)
    def _global_search(self, query):
        if not query: return
        import re
        if re.match(r'^\d{1,3}(\.\d{1,3}){3}$', query): vid="ip"
        elif "@" in query and "." in query: vid="email"
        elif re.match(r'^\+?\d[\d\s\-]{7,}$', query): vid="phone"
        elif re.match(r'^\d{17}$', query): vid="vin"
        elif re.match(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$', query): vid="mac"
        elif "." in query and " " not in query and not query.startswith("@"): vid="domain"
        else: vid="username"
        self._navigate_with_query(vid, query)
    def _on_theme(self, name):
        self.theme_mgr.apply_theme(QApplication.instance(), name)
        accent = self.cfg.get_theme(name).get("accent","#7C3AED")
        if self._anim_widget and hasattr(self._anim_widget,"set_accent"):
            self._anim_widget.set_accent(accent)
    def _start_animation(self):
        if not self.cfg.get("ui","animation","enabled",default=True): return
        atype = self.cfg.get("ui","animation","type",default="lightning")
        accent = self.cfg.get_theme().get("accent","#7C3AED")
        try:
            m = {"lightning":"ui.animations.lightning","matrix":"ui.animations.matrix",
                 "particles":"ui.animations.particles","neural":"ui.animations.neural",
                 "grid":"ui.animations.grid","waves":"ui.animations.waves","gradient":"ui.animations.gradient"}
            cls_map = {"lightning":"LightningWidget","matrix":"MatrixWidget","particles":"ParticlesWidget",
                       "neural":"NeuralWidget","grid":"GridWidget","waves":"WavesWidget","gradient":"GradientWidget"}
            import importlib
            mod = importlib.import_module(m.get(atype,"ui.animations.lightning"))
            cls = getattr(mod, cls_map.get(atype,"LightningWidget"))
            self._anim_widget = cls(self.content_frame, accent) if atype != "matrix" else cls(self.content_frame)
            self._anim_widget.resize(self.content_frame.size())
            self._anim_widget.lower(); self._anim_widget.show()
        except: pass
    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self._anim_widget: self._anim_widget.resize(self.content_frame.size())
    def closeEvent(self, e):
        self.cfg.set(self.width(),"ui","window","width"); self.cfg.set(self.height(),"ui","window","height")
        self.cfg.set(self.isMaximized(),"ui","window","maximized"); self.cfg.save(); e.accept()
    def mouseDoubleClickEvent(self, e):
        if e.y() < 50:
            self.showNormal() if self.isMaximized() else self.showMaximized()
