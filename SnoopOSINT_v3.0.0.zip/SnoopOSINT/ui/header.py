from PyQt6.QtWidgets import (QWidget, QHBoxLayout, QLabel, QLineEdit,
                              QPushButton, QComboBox)
from PyQt6.QtCore import Qt, pyqtSignal, QPoint
from PyQt6.QtGui import QFont, QColor
from core.language_manager import LanguageManager, AVAILABLE_LANGUAGES
from core.config_manager import ConfigManager


class Header(QWidget):
    global_search = pyqtSignal(str)
    language_changed = pyqtSignal(str)
    theme_changed = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.lang = LanguageManager()
        self.cfg = ConfigManager()
        self._drag_pos = None
        self.setFixedHeight(50)
        self.setObjectName("header")
        self.setStyleSheet("""
            QWidget#header {
                background-color: #0D1726;
                border-bottom: 1px solid #1A2A44;
            }
        """)
        self._build()
        self.lang.register(self._retranslate)

    def _build(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 0, 12, 0)
        layout.setSpacing(12)

        logo = QLabel("⚡ <span style='color:#7C3AED;font-weight:900;'>SNOOP</span> "
                      "<span style='color:#EEF3FC;font-weight:300;'>OSINT</span>")
        logo.setTextFormat(Qt.TextFormat.RichText)
        logo.setStyleSheet("font-size: 14pt; background: transparent; letter-spacing: 1px;")
        layout.addWidget(logo)

        layout.addSpacing(20)

        self.search_input = QLineEdit()
        self.search_input.setObjectName("global_search")
        self.search_input.setPlaceholderText(self.lang.t("placeholders", "global_search"))
        self.search_input.setFixedWidth(260)
        self.search_input.setStyleSheet("""
            QLineEdit { background: #0A0E17; border: 1px solid #1A2A44;
                        border-radius: 18px; padding: 5px 14px; color: #EEF3FC; font-size: 10pt; }
            QLineEdit:focus { border: 1px solid #7C3AED; }
        """)
        self.search_input.returnPressed.connect(
            lambda: self.global_search.emit(self.search_input.text()))
        layout.addWidget(self.search_input)

        layout.addStretch()

        self.lang_combo = QComboBox()
        for code, name in AVAILABLE_LANGUAGES.items():
            self.lang_combo.addItem(name, code)
        current_lang = self.cfg.get_language()
        for i in range(self.lang_combo.count()):
            if self.lang_combo.itemData(i) == current_lang:
                self.lang_combo.setCurrentIndex(i)
                break
        self.lang_combo.setFixedWidth(110)
        self.lang_combo.currentIndexChanged.connect(self._on_lang_change)
        self.lang_combo.setStyleSheet("""
            QComboBox { background: #0A0E17; border: 1px solid #1A2A44;
                        border-radius: 4px; padding: 4px 8px; color: #8AA0B8; font-size: 9pt; }
        """)
        layout.addWidget(self.lang_combo)

        themes = ["violet", "blue", "green", "red", "orange", "cyan", "pink", "gold", "matrix", "light"]
        self.theme_combo = QComboBox()
        for t in themes:
            self.theme_combo.addItem(t.capitalize(), t)
        current_theme = self.cfg.get("app", "theme", default="violet")
        for i in range(self.theme_combo.count()):
            if self.theme_combo.itemData(i) == current_theme:
                self.theme_combo.setCurrentIndex(i)
                break
        self.theme_combo.setFixedWidth(110)
        self.theme_combo.currentIndexChanged.connect(self._on_theme_change)
        self.theme_combo.setStyleSheet("""
            QComboBox { background: #0A0E17; border: 1px solid #7C3AED33;
                        border-radius: 4px; padding: 4px 8px; color: #A78BFA; font-size: 9pt; }
        """)
        layout.addWidget(self.theme_combo)

        layout.addSpacing(8)

        for symbol, slot in [("─", self._minimize), ("□", self._maximize), ("✕", self._close)]:
            btn = QPushButton(symbol)
            btn.setFixedSize(28, 28)
            if symbol == "✕":
                btn.setStyleSheet("""
                    QPushButton { background: transparent; color: #8AA0B8; border: none; font-size: 12pt; border-radius: 4px; }
                    QPushButton:hover { background: #EF4444; color: white; }
                """)
            else:
                btn.setStyleSheet("""
                    QPushButton { background: transparent; color: #8AA0B8; border: none; font-size: 12pt; border-radius: 4px; }
                    QPushButton:hover { background: #1A2A44; color: #EEF3FC; }
                """)
            btn.clicked.connect(slot)
            layout.addWidget(btn)

    def _minimize(self):
        w = self.window()
        if w:
            w.showMinimized()

    def _maximize(self):
        w = self.window()
        if w:
            if w.isMaximized():
                w.showNormal()
            else:
                w.showMaximized()

    def _close(self):
        w = self.window()
        if w:
            w.close()

    def _on_lang_change(self, idx):
        code = self.lang_combo.itemData(idx)
        self.lang.switch(code)
        self.language_changed.emit(code)

    def _on_theme_change(self, idx):
        t = self.theme_combo.itemData(idx)
        self.theme_changed.emit(t)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self._drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            w = self.window()
            if w:
                delta = event.globalPosition().toPoint() - self._drag_pos
                w.move(w.pos() + delta)
                self._drag_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self._drag_pos = None

    def _retranslate(self):
        self.search_input.setPlaceholderText(self.lang.t("placeholders", "global_search"))
