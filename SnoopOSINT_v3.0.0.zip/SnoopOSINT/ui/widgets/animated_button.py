from PyQt6.QtWidgets import QPushButton
from PyQt6.QtCore import QPropertyAnimation, QEasingCurve, pyqtProperty, QSize
from PyQt6.QtGui import QColor


class AnimatedButton(QPushButton):
    def __init__(self, text="", parent=None, accent="#7C3AED"):
        super().__init__(text, parent)
        self.accent = accent
        self.setCursor(__import__("PyQt6.QtCore", fromlist=["Qt"]).Qt.CursorShape.PointingHandCursor)

    def enterEvent(self, event):
        self.setStyleSheet(f"background-color: #6D28D9; color: white; border-radius: 6px; padding: 6px 16px; font-weight: bold;")
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.setStyleSheet("")
        super().leaveEvent(event)
