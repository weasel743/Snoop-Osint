import math
from PyQt6.QtWidgets import QWidget
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QPainter, QPen, QColor, QFont


class ProgressRing(QWidget):
    def __init__(self, parent=None, size=60, accent="#7C3AED"):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.accent = QColor(accent)
        self._value = 0
        self._spinning = False
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._spin)

    def set_value(self, v):
        self._spinning = False
        self._timer.stop()
        self._value = max(0, min(100, v))
        self.update()

    def start_spin(self):
        self._spinning = True
        self._timer.start(30)

    def stop_spin(self):
        self._spinning = False
        self._timer.stop()
        self.update()

    def _spin(self):
        self._angle = (self._angle + 8) % 360
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        margin = 5
        rect = self.rect().adjusted(margin, margin, -margin, -margin)
        bg_pen = QPen(QColor("#1A2A44"), 6)
        painter.setPen(bg_pen)
        painter.drawEllipse(rect)
        fg_pen = QPen(self.accent, 6)
        fg_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(fg_pen)
        if self._spinning:
            painter.drawArc(rect, (90 - self._angle) * 16, -120 * 16)
        else:
            span = int(self._value / 100 * 360)
            painter.drawArc(rect, 90 * 16, -span * 16)
            painter.setPen(QPen(QColor("#EEF3FC")))
            font = QFont("Segoe UI", 9, QFont.Weight.Bold)
            painter.setFont(font)
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, f"{int(self._value)}%")
        painter.end()
