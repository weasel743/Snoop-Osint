from PyQt6.QtWidgets import QLabel, QWidget, QHBoxLayout
from PyQt6.QtCore import QTimer, Qt, QPropertyAnimation, QEasingCurve, pyqtProperty
from PyQt6.QtGui import QColor


class Toast(QWidget):
    def __init__(self, parent, message, kind="info", duration=3000):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        colors = {
            "info": ("#7C3AED", "#A78BFA"),
            "success": ("#065F46", "#34D399"),
            "warning": ("#92400E", "#FBBF24"),
            "error": ("#7F1D1D", "#F87171"),
        }
        bg, text_color = colors.get(kind, colors["info"])
        icons = {"info": "ℹ️", "success": "✅", "warning": "⚠️", "error": "❌"}
        icon = icons.get(kind, "ℹ️")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 10, 16, 10)
        label = QLabel(f"{icon} {message}")
        label.setStyleSheet(f"color: {text_color}; font-size: 11pt; background: transparent;")
        layout.addWidget(label)
        self.setStyleSheet(f"""
            QWidget {{
                background-color: {bg};
                border-radius: 8px;
                border: 1px solid {text_color}44;
            }}
        """)
        self.adjustSize()
        if parent:
            pw, ph = parent.width(), parent.height()
            self.move(pw - self.width() - 20, ph - self.height() - 20)
        self.show()
        self.raise_()
        QTimer.singleShot(duration, self.close)


def show_toast(parent, message, kind="info", duration=3000):
    t = Toast(parent, message, kind, duration)
    return t
