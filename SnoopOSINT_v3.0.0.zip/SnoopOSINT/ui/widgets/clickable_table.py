import csv
import json
import webbrowser
from PyQt6.QtWidgets import (QTableWidget, QTableWidgetItem, QHeaderView,
                              QMenu, QApplication, QAbstractItemView)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QAction


class ClickableTable(QTableWidget):
    row_double_clicked = pyqtSignal(int, dict)

    def __init__(self, columns, parent=None):
        super().__init__(parent)
        self.columns = columns
        self._data = []
        self._sort_col = -1
        self._sort_asc = True
        self._setup(columns)

    def _setup(self, columns):
        self.setColumnCount(len(columns))
        self.setHorizontalHeaderLabels(columns)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.setAlternatingRowColors(True)
        self.setShowGrid(True)
        self.verticalHeader().setVisible(False)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        if columns:
            self.horizontalHeader().setStretchLastSection(True)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._context_menu)
        self.horizontalHeader().sectionClicked.connect(self._sort_by_col)
        self.cellDoubleClicked.connect(self._on_double_click)
        self.cellClicked.connect(self._on_click)

    def load_data(self, rows):
        self._data = rows
        self._render(rows)

    def _render(self, rows):
        self.setRowCount(len(rows))
        for ri, row in enumerate(rows):
            if isinstance(row, dict):
                values = [str(row.get(col, row.get(col.lower(), ""))) for col in self.columns]
            elif isinstance(row, (list, tuple)):
                values = [str(v) for v in row]
                while len(values) < len(self.columns):
                    values.append("")
            else:
                values = [str(row)] + [""] * (len(self.columns) - 1)

            for ci, val in enumerate(values[:len(self.columns)]):
                item = QTableWidgetItem(val)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if "✅" in val or "Trouvé" in val or "Ouvert" in val:
                    item.setForeground(QColor("#34D399"))
                elif "❌" in val or "Fermé" in val or "Erreur" in val:
                    item.setForeground(QColor("#F87171"))
                elif "🟡" in val or "Moyen" in val:
                    item.setForeground(QColor("#FBBF24"))
                elif val.startswith("http"):
                    item.setForeground(QColor("#7C3AED"))
                self.setItem(ri, ci, item)
        self.resizeRowsToContents()

    def _sort_by_col(self, col):
        if self._sort_col == col:
            self._sort_asc = not self._sort_asc
        else:
            self._sort_col = col
            self._sort_asc = True
        key = self.columns[col] if col < len(self.columns) else None
        if key and self._data:
            try:
                if isinstance(self._data[0], dict):
                    self._data.sort(key=lambda r: str(r.get(key, r.get(key.lower(), ""))).lower(),
                                    reverse=not self._sort_asc)
                elif isinstance(self._data[0], (list, tuple)):
                    self._data.sort(key=lambda r: str(r[col]) if col < len(r) else "",
                                    reverse=not self._sort_asc)
            except Exception:
                pass
            self._render(self._data)
            symbol = "▲" if self._sort_asc else "▼"
            for i, c in enumerate(self.columns):
                label = f"{c} {symbol}" if i == col else c
                self.horizontalHeaderItem(i).setText(label)

    def _on_click(self, row, col):
        item = self.item(row, col)
        if not item:
            return
        val = item.text()
        if val.startswith("http://") or val.startswith("https://"):
            QApplication.clipboard().setText(val)

    def _on_double_click(self, row, col):
        item = self.item(row, col)
        if not item:
            return
        val = item.text()
        if val.startswith("http://") or val.startswith("https://"):
            webbrowser.open(val)
        else:
            QApplication.clipboard().setText(val)
        if self._data and row < len(self._data):
            self.row_double_clicked.emit(row, self._data[row] if isinstance(self._data[row], dict) else {})

    def _context_menu(self, pos):
        item = self.itemAt(pos)
        if not item:
            return
        val = item.text()
        menu = QMenu(self)
        act_copy = QAction("📋 Copier", self)
        act_copy.triggered.connect(lambda: QApplication.clipboard().setText(val))
        menu.addAction(act_copy)
        if val.startswith("http"):
            act_open = QAction("🌐 Ouvrir dans le navigateur", self)
            act_open.triggered.connect(lambda: webbrowser.open(val))
            menu.addAction(act_open)
        act_google = QAction("🔍 Chercher sur Google", self)
        act_google.triggered.connect(lambda: webbrowser.open(f"https://www.google.com/search?q={val}"))
        menu.addAction(act_google)
        menu.addSeparator()
        act_copy_row = QAction("📝 Copier la ligne", self)
        act_copy_row.triggered.connect(self._copy_selected_rows)
        menu.addAction(act_copy_row)
        menu.exec(self.viewport().mapToGlobal(pos))

    def _copy_selected_rows(self):
        rows = set(i.row() for i in self.selectedItems())
        lines = []
        for r in sorted(rows):
            cells = [self.item(r, c).text() if self.item(r, c) else "" for c in range(self.columnCount())]
            lines.append("\t".join(cells))
        QApplication.clipboard().setText("\n".join(lines))

    def export_csv(self, path):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f)
            writer.writerow(self.columns)
            for row in range(self.rowCount()):
                writer.writerow([self.item(row, col).text() if self.item(row, col) else ""
                                 for col in range(self.columnCount())])

    def export_json(self, path):
        data = []
        for row in range(self.rowCount()):
            d = {}
            for col, header in enumerate(self.columns):
                d[header] = self.item(row, col).text() if self.item(row, col) else ""
            data.append(d)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def get_data_as_dicts(self):
        data = []
        for row in range(self.rowCount()):
            d = {}
            for col, header in enumerate(self.columns):
                d[header] = self.item(row, col).text() if self.item(row, col) else ""
            data.append(d)
        return data

    def filter_rows(self, text):
        text = text.lower()
        for row in range(self.rowCount()):
            visible = False
            for col in range(self.columnCount()):
                item = self.item(row, col)
                if item and text in item.text().lower():
                    visible = True
                    break
            self.setRowHidden(row, not visible)

    def clear_data(self):
        self._data = []
        self.setRowCount(0)
