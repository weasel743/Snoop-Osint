from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QScrollArea
from PyQt6.QtCore import Qt, pyqtSignal
from core.language_manager import LanguageManager

SIDEBAR_ITEMS = [
    ("SECTION","section_search"),
    ("dashboard","🏠","dashboard"),
    ("correlation","🔗","correlation"),
    ("username","👤","username"),
    ("email","📧","email"),
    ("phone","📱","phone"),
    ("ip","🌐","ip"),
    ("domain","🌐","domain"),
    ("SECTION","section_analysis"),
    ("image","🖼️","image"),
    ("metadata","📄","metadata"),
    ("social","💬","social"),
    ("crypto","₿","crypto"),
    ("geo","🗺️","geo"),
    ("breach","🔓","breach"),
    ("paste","📋","paste"),
    ("portscan","🔌","portscan"),
    ("dns","🌀","dns"),
    ("ssl","🔐","ssl"),
    ("dorking","🔍","dorking"),
    ("shodan","🛡️","shodan"),
    ("SECTION","section_france"),
    ("bodacc","🏛️","bodacc"),
    ("infogreffe","📋","infogreffe"),
    ("pagesjaunes","📒","pagesjaunes"),
    ("datafr","🇫🇷","datafr"),
    ("SECTION","section_tools"),
    ("graph","🕸️","graph"),
    ("timeline","📅","timeline"),
    ("batch","📦","batch"),
    ("history","📋","history"),
    ("plugins","🧩","plugins"),
    ("settings","⚙️","settings"),
    ("about","❓","about"),
]

class SidebarItem(QWidget):
    clicked = pyqtSignal(str)
    def __init__(self, view_id, icon, label, parent=None):
        super().__init__(parent)
        self.view_id = view_id; self.active = False; self.collapsed = False
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12,0,12,0); layout.setSpacing(10)
        self.icon_lbl = QLabel(icon)
        self.icon_lbl.setFixedWidth(22)
        self.icon_lbl.setStyleSheet("font-size:14px;background:transparent;")
        layout.addWidget(self.icon_lbl)
        self.text_lbl = QLabel(label)
        self.text_lbl.setStyleSheet("font-size:10pt;background:transparent;color:#8AA0B8;")
        layout.addWidget(self.text_lbl); layout.addStretch()
        self.setFixedHeight(32)
        self.setStyleSheet("border-left:3px solid transparent;")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
    def set_active(self, a):
        self.active = a
        if a:
            self.setStyleSheet("border-left:3px solid #7C3AED;background:rgba(124,58,237,0.15);")
            self.text_lbl.setStyleSheet("font-size:10pt;background:transparent;color:#EEF3FC;font-weight:bold;")
        else:
            self.setStyleSheet("border-left:3px solid transparent;")
            self.text_lbl.setStyleSheet("font-size:10pt;background:transparent;color:#8AA0B8;")
    def set_collapsed(self, c):
        self.collapsed = c; self.text_lbl.setVisible(not c)
    def set_label(self, t): self.text_lbl.setText(t)
    def mousePressEvent(self, e): self.clicked.emit(self.view_id)
    def enterEvent(self, e):
        if not self.active:
            self.setStyleSheet("border-left:3px solid rgba(124,58,237,0.5);background:rgba(124,58,237,0.08);")
            self.text_lbl.setStyleSheet("font-size:10pt;background:transparent;color:#EEF3FC;")
    def leaveEvent(self, e):
        if not self.active:
            self.setStyleSheet("border-left:3px solid transparent;")
            self.text_lbl.setStyleSheet("font-size:10pt;background:transparent;color:#8AA0B8;")

class Sidebar(QWidget):
    navigate = pyqtSignal(str)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.lang = LanguageManager()
        self.items = {}; self.active_id = "dashboard"; self.collapsed = False
        self.setFixedWidth(220)
        self.setObjectName("sidebar")
        self.setStyleSheet("QWidget#sidebar{background:#0D1726;border-right:1px solid #1A2A44;}")
        self._build(); self.lang.register(self._retranslate)
    def _build(self):
        ml = QVBoxLayout(self); ml.setContentsMargins(0,8,0,0); ml.setSpacing(0)
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea{border:none;background:transparent;}")
        container = QWidget(); container.setStyleSheet("background:transparent;")
        self.items_layout = QVBoxLayout(container)
        self.items_layout.setContentsMargins(0,0,0,0); self.items_layout.setSpacing(1)
        for item_def in SIDEBAR_ITEMS:
            if item_def[0] == "SECTION":
                lbl = QLabel(self.lang.t("sidebar", item_def[1]))
                lbl.setObjectName(f"sec_{item_def[1]}")
                lbl.setStyleSheet("color:#4A5C70;font-size:8pt;font-weight:bold;letter-spacing:1.5px;padding:10px 15px 3px;background:transparent;")
                self.items_layout.addWidget(lbl); self.items[f"_sec_{item_def[1]}"] = lbl
            else:
                vid, icon, lk = item_def
                label = self.lang.t("sidebar", lk)
                item = SidebarItem(vid, icon, label)
                item.clicked.connect(self._on_click)
                self.items_layout.addWidget(item); self.items[vid] = item
        self.items_layout.addStretch(); scroll.setWidget(container); ml.addWidget(scroll, 1)
        toggle = QPushButton("◀")
        toggle.clicked.connect(self.toggle_collapse)
        toggle.setFixedHeight(28)
        toggle.setStyleSheet("QPushButton{background:#0A0E17;color:#8AA0B8;border:none;border-top:1px solid #1A2A44;}QPushButton:hover{background:#1A2A44;color:#EEF3FC;}")
        ml.addWidget(toggle); self._toggle_btn = toggle
        self.set_active("dashboard")
    def _on_click(self, vid):
        self.set_active(vid); self.navigate.emit(vid)
    def set_active(self, vid):
        if self.active_id in self.items and isinstance(self.items[self.active_id], SidebarItem):
            self.items[self.active_id].set_active(False)
        self.active_id = vid
        if vid in self.items and isinstance(self.items[vid], SidebarItem):
            self.items[vid].set_active(True)
    def toggle_collapse(self):
        self.collapsed = not self.collapsed
        self.setFixedWidth(60 if self.collapsed else 220)
        self._toggle_btn.setText("▶" if self.collapsed else "◀")
        for k, v in self.items.items():
            if isinstance(v, SidebarItem): v.set_collapsed(self.collapsed)
            elif isinstance(v, QLabel): v.setVisible(not self.collapsed)
    def _retranslate(self):
        for item_def in SIDEBAR_ITEMS:
            if item_def[0] == "SECTION":
                k = f"_sec_{item_def[1]}"
                if k in self.items: self.items[k].setText(self.lang.t("sidebar",item_def[1]))
            else:
                vid,_,lk = item_def
                if vid in self.items: self.items[vid].set_label(self.lang.t("sidebar",lk))
