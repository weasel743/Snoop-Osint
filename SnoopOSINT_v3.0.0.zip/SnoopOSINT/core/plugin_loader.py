import os
import importlib.util
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLUGINS_DIR = os.path.join(BASE_DIR, "plugins")


class PluginLoader:
    def __init__(self):
        self.plugins = {}
        self.load_all()

    def load_all(self):
        os.makedirs(PLUGINS_DIR, exist_ok=True)
        for fname in os.listdir(PLUGINS_DIR):
            if fname.endswith(".py") and not fname.startswith("_"):
                self.load_plugin(fname)

    def load_plugin(self, filename):
        name = filename[:-3]
        path = os.path.join(PLUGINS_DIR, filename)
        try:
            spec = importlib.util.spec_from_file_location(name, path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules[f"plugin_{name}"] = mod
            spec.loader.exec_module(mod)
            meta = {
                "name": getattr(mod, "PLUGIN_NAME", name),
                "version": getattr(mod, "PLUGIN_VERSION", "1.0"),
                "description": getattr(mod, "PLUGIN_DESCRIPTION", ""),
                "author": getattr(mod, "PLUGIN_AUTHOR", "Unknown"),
                "module": mod,
                "filename": filename,
                "enabled": True
            }
            self.plugins[name] = meta
        except Exception as e:
            self.plugins[name] = {"name": name, "enabled": False, "error": str(e), "filename": filename}

    def get_plugins(self):
        return list(self.plugins.values())

    def reload_plugin(self, name):
        if name in self.plugins:
            filename = self.plugins[name].get("filename", f"{name}.py")
            self.load_plugin(filename)

    def run_plugin(self, name, query, **kwargs):
        p = self.plugins.get(name)
        if not p or not p.get("enabled"):
            return []
        mod = p.get("module")
        if not mod:
            return []
        run_fn = getattr(mod, "run", None)
        if not run_fn:
            return []
        return run_fn(query, **kwargs)
