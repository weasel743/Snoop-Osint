import csv, json, os
from datetime import datetime
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class ReportGenerator:
    def __init__(self, module, query, results):
        self.module = module; self.query = query; self.results = results
        self.ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.dir = os.path.join(BASE_DIR,"reports")
        os.makedirs(self.dir, exist_ok=True)
    def _path(self, ext): return os.path.join(self.dir, f"{self.module}_{self.ts}.{ext}")
    def export_csv(self, path=None):
        path = path or self._path("csv")
        if not self.results: return path
        keys = list(self.results[0].keys()) if isinstance(self.results[0],dict) else ["value"]
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
            for r in self.results:
                w.writerow(r if isinstance(r,dict) else {"value":str(r)})
        return path
    def export_json(self, path=None):
        path = path or self._path("json")
        with open(path,"w",encoding="utf-8") as f:
            json.dump({"module":self.module,"query":self.query,
                "timestamp":datetime.now().isoformat(),"count":len(self.results),
                "results":self.results},f,indent=2,ensure_ascii=False)
        return path
    def export_html(self, path=None):
        path = path or self._path("html")
        keys = list(self.results[0].keys()) if self.results and isinstance(self.results[0],dict) else ["value"]
        header = "".join(f"<th>{k}</th>" for k in keys)
        rows = ""
        for r in self.results:
            if isinstance(r,dict): cells = "".join(f"<td>{r.get(k,'')}</td>" for k in keys)
            else: cells = f"<td>{r}</td>"
            rows += f"<tr>{cells}</tr>"
        html = f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Snoop OSINT</title>
<style>body{{background:#0A0E17;color:#EEF3FC;font-family:'Segoe UI',sans-serif;padding:20px}}
h1{{color:#7C3AED}}table{{width:100%;border-collapse:collapse;background:#0D1726;border-radius:8px;overflow:hidden}}
th{{background:#0A0E17;color:#8AA0B8;padding:10px;text-align:left;border-bottom:1px solid #1A2A44;font-size:11px;text-transform:uppercase}}
td{{padding:8px 10px;border-bottom:1px solid #111C2E;font-size:12px}}tr:hover td{{background:#1A2A44}}</style></head>
<body><h1>⚡ Snoop OSINT — {self.module}</h1>
<p style="color:#8AA0B8">Cible: <b style="color:#A78BFA">{self.query}</b> | {len(self.results)} résultats | {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
<table><thead><tr>{header}</tr></thead><tbody>{rows}</tbody></table></body></html>"""
        with open(path,"w",encoding="utf-8") as f: f.write(html)
        return path
    def export_pdf(self, path=None):
        path = path or self._path("pdf")
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
            from reportlab.lib.units import cm
            doc = SimpleDocTemplate(path,pagesize=A4,leftMargin=2*cm,rightMargin=2*cm,topMargin=2*cm,bottomMargin=2*cm)
            styles = getSampleStyleSheet()
            ts = ParagraphStyle("t",fontSize=16,textColor=colors.HexColor("#7C3AED"),spaceAfter=6,fontName="Helvetica-Bold")
            ss = ParagraphStyle("s",fontSize=10,textColor=colors.HexColor("#8AA0B8"),spaceAfter=12)
            els = [Paragraph(f"⚡ Snoop OSINT — {self.module}",ts),
                   Paragraph(f"Cible: {self.query} | {len(self.results)} résultats | {datetime.now().strftime('%d/%m/%Y %H:%M')}",ss),
                   Spacer(1,0.3*cm)]
            if self.results and isinstance(self.results[0],dict):
                keys = list(self.results[0].keys())
                data = [keys] + [[str(r.get(k,""))[:60] for k in keys] for r in self.results[:500]]
            else:
                data = [["Résultat"]] + [[str(r)[:80]] for r in self.results[:500]]
            t = Table(data,repeatRows=1)
            t.setStyle(TableStyle([
                ("BACKGROUND",(0,0),(-1,0),colors.HexColor("#7C3AED")),("TEXTCOLOR",(0,0),(-1,0),colors.white),
                ("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),
                ("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.HexColor("#F8F9FA"),colors.white]),
                ("GRID",(0,0),(-1,-1),0.5,colors.HexColor("#E2E8F0")),("PADDING",(0,0),(-1,-1),4)]))
            els.append(t); doc.build(els)
        except Exception as e:
            with open(path,"w") as f: f.write(f"Snoop OSINT\n{self.module}\n{self.query}\n{json.dumps(self.results[:100],indent=2)}")
        return path
