import json, os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

AVAILABLE_LANGUAGES = {
    "fr": "Français",
    "en": "English",
    "es": "Español",
    "de": "Deutsch"
}

class LanguageManager:
    _instance = None
    def __new__(cls):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
        return cls._instance

    def __init__(self):
        if not self._loaded:
            from core.config_manager import ConfigManager
            self.cfg = ConfigManager()
            self.strings = {}
            self._observers = []
            self.current = "fr"
            self.load(self.cfg.get_language())
            self._loaded = True

    def load(self, code):
        p = os.path.join(BASE_DIR, "config", "languages", f"{code}.json")
        if not os.path.exists(p):
            p = os.path.join(BASE_DIR, "config", "languages", "fr.json")
            code = "fr"
        with open(p, encoding="utf-8") as f:
            self.strings = json.load(f)
        self.current = code

    def switch(self, code):
        self.load(code)
        self.cfg.set(code, "app", "language")
        self.cfg.save()
        for cb in self._observers:
            try: cb()
            except: pass

    def register(self, cb):
        self._observers.append(cb)

    def t(self, *keys, default=""):
        d = self.strings
        for k in keys:
            if isinstance(d, dict) and k in d:
                d = d[k]
            else:
                return default or ".".join(keys)
        return str(d)

    def get_languages(self):
        return AVAILABLE_LANGUAGES
