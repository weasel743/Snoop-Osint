import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def run(ip_address, timeout=10):
    results = []
    primary = _check_ipapi(ip_address, timeout)
    results.extend(primary)
    if not primary:
        alt = _check_ipinfo(ip_address, timeout)
        results.extend(alt)
    extra = _check_ipwhois(ip_address, timeout)
    results.extend(extra)
    return results


def _check_ipapi(ip, timeout):
    try:
        resp = requests.get(
            f"http://ip-api.com/json/{ip}",
            params={"fields": "status,message,continent,country,countryCode,region,"
                              "regionName,city,district,zip,lat,lon,timezone,offset,"
                              "currency,isp,org,as,asname,mobile,proxy,hosting,query"},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code != 200:
            return []
        d = resp.json()
        if d.get("status") != "success":
            return [{"champ": "Erreur", "valeur": d.get("message", "Échec"), "source": "ip-api.com"}]
        return [
            {"champ": "Adresse IP", "valeur": d.get("query", ip), "source": "ip-api.com"},
            {"champ": "Pays", "valeur": f"{d.get('country', '')} ({d.get('countryCode', '')})", "source": "ip-api.com"},
            {"champ": "Région", "valeur": d.get("regionName", ""), "source": "ip-api.com"},
            {"champ": "Ville", "valeur": d.get("city", ""), "source": "ip-api.com"},
            {"champ": "Code postal", "valeur": d.get("zip", ""), "source": "ip-api.com"},
            {"champ": "Latitude", "valeur": str(d.get("lat", "")), "source": "ip-api.com"},
            {"champ": "Longitude", "valeur": str(d.get("lon", "")), "source": "ip-api.com"},
            {"champ": "Fuseau horaire", "valeur": d.get("timezone", ""), "source": "ip-api.com"},
            {"champ": "ISP", "valeur": d.get("isp", ""), "source": "ip-api.com"},
            {"champ": "Organisation", "valeur": d.get("org", ""), "source": "ip-api.com"},
            {"champ": "AS", "valeur": d.get("as", ""), "source": "ip-api.com"},
            {"champ": "ASN Name", "valeur": d.get("asname", ""), "source": "ip-api.com"},
            {"champ": "Mobile", "valeur": "✅ Oui" if d.get("mobile") else "❌ Non", "source": "ip-api.com"},
            {"champ": "Proxy / VPN", "valeur": "✅ Détecté" if d.get("proxy") else "❌ Non détecté", "source": "ip-api.com"},
            {"champ": "Hébergement", "valeur": "✅ Oui" if d.get("hosting") else "❌ Non", "source": "ip-api.com"},
            {"champ": "Maps", "valeur": f"https://maps.google.com/?q={d.get('lat')},{d.get('lon')}", "source": "ip-api.com"},
        ]
    except Exception as e:
        return [{"champ": "Erreur", "valeur": str(e), "source": "ip-api.com"}]


def _check_ipinfo(ip, timeout):
    try:
        resp = requests.get(f"https://ipinfo.io/{ip}/json", headers=HEADERS, timeout=timeout)
        if resp.status_code == 200:
            d = resp.json()
            results = []
            for k, v in d.items():
                if k not in ("readme",):
                    results.append({"champ": k.capitalize(), "valeur": str(v), "source": "ipinfo.io"})
            return results
    except Exception:
        pass
    return []


def _check_ipwhois(ip, timeout):
    try:
        resp = requests.get(
            f"https://rdap.arin.net/registry/ip/{ip}",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            d = resp.json()
            name = d.get("name", "")
            handle = d.get("handle", "")
            if name or handle:
                return [{"champ": "RDAP Name", "valeur": name, "source": "ARIN RDAP"},
                        {"champ": "RDAP Handle", "valeur": handle, "source": "ARIN RDAP"}]
    except Exception:
        pass
    return []
