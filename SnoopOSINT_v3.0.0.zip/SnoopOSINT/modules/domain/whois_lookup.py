import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def run(domain, timeout=15):
    results = []
    try:
        import whois
        w = whois.whois(domain)
        fields = {
            "Domaine": w.domain_name,
            "Registrar": w.registrar,
            "Date création": str(w.creation_date)[:25] if w.creation_date else None,
            "Date expiration": str(w.expiration_date)[:25] if w.expiration_date else None,
            "Dernière MAJ": str(w.updated_date)[:25] if w.updated_date else None,
            "Statut": w.status,
            "Serveurs DNS": w.name_servers,
            "Email registrant": w.emails,
            "Pays": w.country,
            "Organisation": w.org,
            "Ville": w.city,
            "DNSSEC": w.dnssec,
        }
        for k, v in fields.items():
            if v:
                val = v if isinstance(v, str) else (", ".join(str(x) for x in v) if isinstance(v, (list, set)) else str(v))
                results.append({"champ": k, "valeur": val[:200], "source": "python-whois"})
    except ImportError:
        results.extend(_fallback_whois(domain, timeout))
    except Exception as e:
        results.extend(_fallback_whois(domain, timeout))
        if not results:
            results.append({"champ": "Erreur", "valeur": str(e), "source": "whois"})
    return results


def _fallback_whois(domain, timeout):
    results = []
    try:
        resp = requests.get(
            f"https://who-dat.as93.net/{domain}",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            d = resp.json()
            reg = d.get("Registrant", {})
            reg_info = d.get("Registrar", {})
            for k, v in {
                "Registrar": reg_info.get("Name", ""),
                "URL Registrar": reg_info.get("URL", ""),
                "WHOIS Server": reg_info.get("WhoIs Server", ""),
                "Organisation": reg.get("Organization", ""),
                "Pays": reg.get("Country", ""),
                "État": reg.get("State", ""),
            }.items():
                if v:
                    results.append({"champ": k, "valeur": v, "source": "who-dat.as93.net"})
            dates = d.get("Domain", {})
            for k, v in {
                "Créé le": dates.get("Created Date", ""),
                "Expire le": dates.get("Expiration Date", ""),
                "Mis à jour": dates.get("Updated Date", ""),
                "Statut": ", ".join(dates.get("Status", [])),
                "DNSSEC": dates.get("DNSSEC", ""),
            }.items():
                if v:
                    results.append({"champ": k, "valeur": str(v)[:200], "source": "who-dat.as93.net"})
    except Exception:
        pass
    try:
        resp = requests.get(
            f"https://rdap.org/domain/{domain}",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            d = resp.json()
            results.append({"champ": "RDAP Status", "valeur": ", ".join(d.get("status", [])), "source": "rdap.org"})
            for ev in d.get("events", []):
                results.append({
                    "champ": f"Événement: {ev.get('eventAction','?')}",
                    "valeur": ev.get("eventDate", "")[:25],
                    "source": "rdap.org"
                })
    except Exception:
        pass
    return results
