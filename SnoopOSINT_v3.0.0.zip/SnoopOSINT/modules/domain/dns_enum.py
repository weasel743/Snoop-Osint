import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA", "PTR", "SRV", "CAA"]


def run(domain, timeout=10):
    results = []
    try:
        import dns.resolver
        for rtype in RECORD_TYPES:
            try:
                answers = dns.resolver.resolve(domain, rtype, lifetime=timeout)
                for rdata in answers:
                    results.append({
                        "type": rtype,
                        "valeur": str(rdata),
                        "ttl": str(answers.rrset.ttl),
                        "source": "dnspython"
                    })
            except Exception:
                pass
    except ImportError:
        results.extend(_doh_lookup(domain, timeout))
    if not results:
        results.extend(_doh_lookup(domain, timeout))
    return results


def _doh_lookup(domain, timeout):
    """DNS over HTTPS — Google & Cloudflare, sans bibliothèque."""
    results = []
    for rtype in RECORD_TYPES:
        for doh_url in [
            f"https://dns.google/resolve?name={domain}&type={rtype}",
            f"https://cloudflare-dns.com/dns-query?name={domain}&type={rtype}",
        ]:
            try:
                resp = requests.get(
                    doh_url,
                    headers={**HEADERS, "Accept": "application/dns-json"},
                    timeout=timeout
                )
                if resp.status_code == 200:
                    data = resp.json()
                    answers = data.get("Answer", [])
                    for ans in answers:
                        results.append({
                            "type": rtype,
                            "valeur": ans.get("data", ""),
                            "ttl": str(ans.get("TTL", "")),
                            "source": "DNS over HTTPS"
                        })
                    if answers:
                        break
            except Exception:
                continue
    return results
