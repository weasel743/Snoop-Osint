import ssl
import socket
import requests
from datetime import datetime

HEADERS = {"User-Agent": "Mozilla/5.0"}


def run(domain, timeout=10):
    results = []
    results.extend(_check_ssl_native(domain, timeout))
    results.extend(_check_crt_sh(domain, timeout))
    return results


def _check_ssl_native(domain, timeout):
    results = []
    try:
        ctx = ssl.create_default_context()
        clean = domain.replace("https://", "").replace("http://", "").split("/")[0]
        with socket.create_connection((clean, 443), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=clean) as ssock:
                cert = ssock.getpeercert()
                subject = dict(x[0] for x in cert.get("subject", []))
                issuer = dict(x[0] for x in cert.get("issuer", []))
                not_before = cert.get("notBefore", "")
                not_after = cert.get("notAfter", "")
                san = cert.get("subjectAltName", [])
                san_list = ", ".join(v for t, v in san if t == "DNS")

                try:
                    exp_dt = datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
                    days_left = (exp_dt - datetime.utcnow()).days
                    validity = f"✅ Valide ({days_left} jours)" if days_left > 0 else "❌ Expiré"
                except Exception:
                    validity = "Inconnu"

                results = [
                    {"champ": "CN (Subject)", "valeur": subject.get("commonName", ""), "source": "SSL natif"},
                    {"champ": "Organisation", "valeur": subject.get("organizationName", ""), "source": "SSL natif"},
                    {"champ": "Émetteur", "valeur": issuer.get("commonName", ""), "source": "SSL natif"},
                    {"champ": "Émetteur Org", "valeur": issuer.get("organizationName", ""), "source": "SSL natif"},
                    {"champ": "Valide depuis", "valeur": not_before, "source": "SSL natif"},
                    {"champ": "Valide jusqu'au", "valeur": not_after, "source": "SSL natif"},
                    {"champ": "Validité", "valeur": validity, "source": "SSL natif"},
                    {"champ": "SAN (Domaines)", "valeur": san_list[:300], "source": "SSL natif"},
                    {"champ": "Version", "valeur": ssock.version(), "source": "SSL natif"},
                ]
    except ssl.SSLCertVerificationError as e:
        results.append({"champ": "Avertissement", "valeur": f"Cert non vérifié: {e}", "source": "SSL natif"})
    except Exception as e:
        results.append({"champ": "Info", "valeur": f"SSL non disponible: {e}", "source": "SSL natif"})
    return results


def _check_crt_sh(domain, timeout):
    results = []
    try:
        resp = requests.get(
            "https://crt.sh/",
            params={"q": domain, "output": "json"},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            certs = resp.json()
            unique = {}
            for c in certs:
                cn = c.get("common_name", "")
                issuer = c.get("issuer_name", "")
                key = f"{cn}|{issuer}"
                if key not in unique:
                    unique[key] = c
            results.append({"champ": "Certs trouvés (crt.sh)", "valeur": str(len(certs)), "source": "crt.sh"})
            for k, c in list(unique.items())[:10]:
                results.append({
                    "champ": "Certificat",
                    "valeur": f"{c.get('common_name','')} — {c.get('not_after','')[:10]}",
                    "source": "crt.sh"
                })
    except Exception:
        pass
    return results
