import requests, hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed

H = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

def _gravatar(email, timeout):
    h = hashlib.md5(email.lower().strip().encode()).hexdigest()
    try:
        r = requests.get(f"https://www.gravatar.com/{h}.json", headers=H, timeout=timeout)
        if r.status_code == 200:
            entry = r.json().get("entry",[{}])[0]
            return {"platform":"Gravatar","found":True,"details":entry.get("displayName","Profil trouvé"),"method":"Hash MD5"}
    except: pass
    return {"platform":"Gravatar","found":False,"details":"","method":"Hash MD5"}

def _github(email, timeout):
    try:
        r = requests.get("https://api.github.com/search/users",
            params={"q":f"{email} in:email"},
            headers={**H,"Accept":"application/vnd.github.v3+json"}, timeout=timeout)
        if r.status_code == 200:
            d = r.json()
            if d.get("total_count",0) > 0:
                items = d.get("items",[])
                login = items[0]["login"] if items else ""
                return {"platform":"GitHub","found":True,"details":f"@{login}" if login else "Trouvé","method":"API publique"}
    except: pass
    return {"platform":"GitHub","found":False,"details":"","method":"API publique"}

def _firefox(email, timeout):
    try:
        r = requests.post("https://api.accounts.firefox.com/v1/account/check",
            json={"email":email}, headers={**H,"Content-Type":"application/json"}, timeout=timeout)
        if r.status_code == 200: return {"platform":"Firefox Accounts","found":True,"details":"Compte Mozilla","method":"API officielle"}
        if r.status_code == 400: return {"platform":"Firefox Accounts","found":False,"details":"","method":"API officielle"}
    except: pass
    return {"platform":"Firefox Accounts","found":False,"details":"","method":"API officielle"}

def _twitter(email, timeout):
    try:
        r = requests.get(f"https://api.twitter.com/i/users/email_available.json",
            params={"email":email}, headers=H, timeout=timeout)
        if r.status_code == 200:
            d = r.json()
            taken = not d.get("valid",True)
            return {"platform":"Twitter/X","found":taken,"details":"Email enregistré" if taken else "","method":"Fingerprint"}
    except: pass
    return {"platform":"Twitter/X","found":False,"details":"","method":"Fingerprint"}

def _adobe(email, timeout):
    try:
        r = requests.post("https://auth.services.adobe.com/en_US/index.html",
            data={"email":email}, headers=H, timeout=timeout)
        if "taken" in r.text.lower() or "already" in r.text.lower():
            return {"platform":"Adobe","found":True,"details":"Email enregistré","method":"Fingerprint"}
    except: pass
    return {"platform":"Adobe","found":False,"details":"","method":"Fingerprint"}

def _protonmail(email, timeout):
    try:
        local = email.split("@")[0]
        r = requests.get(f"https://api.protonmail.ch/pks/lookup?op=index&search={email}",
            headers=H, timeout=timeout)
        if r.status_code == 200 and local in r.text:
            return {"platform":"ProtonMail","found":True,"details":"Clef PGP publique trouvée","method":"PGP keyserver"}
    except: pass
    return {"platform":"ProtonMail","found":False,"details":"","method":"PGP keyserver"}

def _jetbrains(email, timeout):
    try:
        r = requests.post("https://account.jetbrains.com/v1/auth/check",
            json={"email":email}, headers={**H,"Content-Type":"application/json"}, timeout=timeout)
        if r.status_code == 200 and "exists" in r.text.lower():
            return {"platform":"JetBrains","found":True,"details":"Compte JetBrains","method":"Fingerprint"}
    except: pass
    return {"platform":"JetBrains","found":False,"details":"","method":"Fingerprint"}

def _lastpass(email, timeout):
    try:
        r = requests.get("https://lastpass.com/create_account.php",
            params={"check":"avail","skipcontent":1,"mistype":1,"username":email},
            headers=H, timeout=timeout)
        if r.status_code == 200 and r.text.strip() == "0":
            return {"platform":"LastPass","found":True,"details":"Email enregistré","method":"Register check"}
    except: pass
    return {"platform":"LastPass","found":False,"details":"","method":"Register check"}

def _hubspot(email, timeout):
    try:
        r = requests.post("https://api.hubspot.com/contacts/v1/contact/email/create-or-update",
            json={"email":email}, headers={**H,"Content-Type":"application/json"}, timeout=timeout)
        if r.status_code in (409,200):
            return {"platform":"HubSpot","found":r.status_code==409,"details":"Contact existant" if r.status_code==409 else "","method":"API"}
    except: pass
    return {"platform":"HubSpot","found":False,"details":"","method":"API"}

CHECKERS = [_gravatar, _github, _firefox, _twitter, _adobe, _protonmail, _jetbrains, _lastpass, _hubspot]

def run(email, timeout=10, progress_callback=None):
    results = []
    done = 0
    with ThreadPoolExecutor(max_workers=len(CHECKERS)) as ex:
        futures = {ex.submit(fn, email, timeout): fn.__name__ for fn in CHECKERS}
        for fut in as_completed(futures):
            done += 1
            res = fut.result()
            results.append(res)
            if progress_callback: progress_callback(done, len(CHECKERS), res)
    results.sort(key=lambda x: (0 if x["found"] else 1, x["platform"]))
    return results
