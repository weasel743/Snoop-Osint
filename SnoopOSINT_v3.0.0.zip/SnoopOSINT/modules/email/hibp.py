import requests
import time

HEADERS = {
    "User-Agent": "SnoopOSINT/2.0 (Educational OSINT Tool)",
    "Accept": "application/json",
}

KNOWN_BREACHES_DB = [
    {"Name": "Adobe", "BreachDate": "2013-10-04", "PwnCount": 152445165,
     "Description": "Données Adobe compromises", "DataClasses": ["Email", "Password hints", "Usernames"]},
    {"Name": "LinkedIn", "BreachDate": "2012-05-05", "PwnCount": 164611595,
     "Description": "Fuite LinkedIn 2012", "DataClasses": ["Email addresses", "Passwords"]},
    {"Name": "MySpace", "BreachDate": "2008-07-01", "PwnCount": 359420698,
     "Description": "Ancienne fuite MySpace", "DataClasses": ["Email addresses", "Passwords", "Usernames"]},
    {"Name": "Canva", "BreachDate": "2019-05-24", "PwnCount": 137272116,
     "Description": "Fuite Canva 2019", "DataClasses": ["Email addresses", "Names", "Usernames"]},
    {"Name": "Dropbox", "BreachDate": "2012-07-09", "PwnCount": 68648009,
     "Description": "Fuite Dropbox 2012", "DataClasses": ["Email addresses", "Passwords"]},
    {"Name": "Tumblr", "BreachDate": "2013-10-18", "PwnCount": 65469298,
     "Description": "Fuite Tumblr 2013", "DataClasses": ["Email addresses", "Passwords"]},
    {"Name": "Zynga", "BreachDate": "2019-09-01", "PwnCount": 172869660,
     "Description": "Fuite Zynga 2019", "DataClasses": ["Email addresses", "Passwords", "Usernames"]},
    {"Name": "Collection #1", "BreachDate": "2019-01-07", "PwnCount": 772904991,
     "Description": "Compilation massive de fuites", "DataClasses": ["Email addresses", "Passwords"]},
]


def check_hibp_api(email, api_key="", timeout=10):
    """Tente l'API HIBP v3 si clef fournie."""
    if not api_key:
        return None
    try:
        resp = requests.get(
            f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}",
            headers={**HEADERS, "hibp-api-key": api_key},
            timeout=timeout
        )
        if resp.status_code == 200:
            return resp.json()
        elif resp.status_code == 404:
            return []
    except Exception:
        pass
    return None


def check_dehashed(email, timeout=10):
    """Vérifie via DeHashed API publique."""
    try:
        resp = requests.get(
            "https://dehashed.com/search",
            params={"query": email},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200 and "entries" in resp.text.lower():
            return [{"Name": "DeHashed", "BreachDate": "Multiple",
                     "Description": "Données trouvées dans DeHashed",
                     "DataClasses": ["Email", "Passwords", "Usernames"]}]
    except Exception:
        pass
    return []


def check_breach_directory(email, timeout=10):
    """Vérifie BreachDirectory API (gratuite)."""
    try:
        resp = requests.get(
            "https://breachdirectory.org/api",
            params={"func": "auto", "term": email},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("success") and data.get("result"):
                return [{"Name": "BreachDirectory", "BreachDate": "Various",
                         "Description": f"{len(data['result'])} entrées trouvées",
                         "DataClasses": ["Email", "Password hashes"]}]
    except Exception:
        pass
    return []


def check_intelligence_x(email, timeout=10):
    """Vérifie Intelligence X (gratuit limité)."""
    try:
        resp = requests.post(
            "https://3.intelx.io/intelligent/search",
            json={"term": email, "timeout": 5, "target": 2, "maxresults": 10, "sort": 4},
            headers={**HEADERS, "Content-Type": "application/json", "x-key": "test"},
            timeout=timeout
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("id"):
                return [{"Name": "Intelligence X", "BreachDate": "Multiple",
                         "Description": "Données trouvées sur IntelX",
                         "DataClasses": ["Leaked data"]}]
    except Exception:
        pass
    return []


def run(email, api_key="", timeout=10):
    results = []
    api_results = check_hibp_api(email, api_key, timeout)
    if api_results is not None:
        results.extend(api_results)
    else:
        directory_results = check_breach_directory(email, timeout)
        results.extend(directory_results)
    formatted = []
    for b in results:
        formatted.append({
            "source": b.get("Name", "Inconnu"),
            "date": b.get("BreachDate", "?"),
            "count": f"{b.get('PwnCount', 0):,}" if b.get("PwnCount") else "N/A",
            "description": b.get("Description", "")[:100],
            "data_types": ", ".join(b.get("DataClasses", [])),
            "severity": _severity(b.get("PwnCount", 0))
        })
    return formatted


def _severity(count):
    if count > 100_000_000:
        return "🔴 Critique"
    elif count > 10_000_000:
        return "🟠 Élevé"
    elif count > 1_000_000:
        return "🟡 Moyen"
    else:
        return "🟢 Faible"
