import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def run(phone_number, timeout=10):
    results = []
    try:
        import phonenumbers
        from phonenumbers import geocoder, carrier, timezone

        try:
            parsed = phonenumbers.parse(phone_number, None)
        except Exception:
            try:
                parsed = phonenumbers.parse(f"+{phone_number}", None)
            except Exception:
                return [{"champ": "Erreur", "valeur": "Numéro invalide", "source": "phonenumbers"}]

        is_valid = phonenumbers.is_valid_number(parsed)
        is_possible = phonenumbers.is_possible_number(parsed)
        country = geocoder.description_for_number(parsed, "fr")
        carrier_name = carrier.name_for_number(parsed, "fr")
        timezones = list(timezone.time_zones_for_number(parsed))
        number_type = phonenumbers.number_type(parsed)

        type_map = {
            phonenumbers.PhoneNumberType.MOBILE: "Mobile",
            phonenumbers.PhoneNumberType.FIXED_LINE: "Fixe",
            phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "Fixe ou Mobile",
            phonenumbers.PhoneNumberType.TOLL_FREE: "Numéro vert",
            phonenumbers.PhoneNumberType.PREMIUM_RATE: "Surtaxé",
            phonenumbers.PhoneNumberType.VOIP: "VoIP",
            phonenumbers.PhoneNumberType.PAGER: "Pager",
            phonenumbers.PhoneNumberType.UAN: "UAN",
            phonenumbers.PhoneNumberType.VOICEMAIL: "Messagerie",
            phonenumbers.PhoneNumberType.UNKNOWN: "Inconnu",
        }

        results = [
            {"champ": "Numéro (international)", "valeur": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.INTERNATIONAL), "source": "phonenumbers"},
            {"champ": "Numéro (national)", "valeur": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.NATIONAL), "source": "phonenumbers"},
            {"champ": "Numéro (E.164)", "valeur": phonenumbers.format_number(parsed, phonenumbers.PhoneNumberFormat.E164), "source": "phonenumbers"},
            {"champ": "Pays", "valeur": country or "Inconnu", "source": "phonenumbers"},
            {"champ": "Indicatif pays", "valeur": f"+{parsed.country_code}", "source": "phonenumbers"},
            {"champ": "Opérateur", "valeur": carrier_name or "Inconnu", "source": "phonenumbers"},
            {"champ": "Type", "valeur": type_map.get(number_type, "Inconnu"), "source": "phonenumbers"},
            {"champ": "Valide", "valeur": "✅ Oui" if is_valid else "❌ Non", "source": "phonenumbers"},
            {"champ": "Possible", "valeur": "✅ Oui" if is_possible else "❌ Non", "source": "phonenumbers"},
            {"champ": "Fuseaux horaires", "valeur": ", ".join(timezones) or "Inconnu", "source": "phonenumbers"},
        ]
    except ImportError:
        results = [{"champ": "Erreur", "valeur": "Installez: pip install phonenumbers", "source": "system"}]

    extra = _check_online(phone_number, timeout)
    results.extend(extra)
    return results


def _check_online(phone, timeout=10):
    results = []
    try:
        resp = requests.get(
            f"https://phonevalidation.abstractapi.com/v1/?api_key=&phone={phone}",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("phone"):
                results.append({"champ": "Format validé", "valeur": data.get("phone", ""), "source": "AbstractAPI"})
    except Exception:
        pass

    try:
        clean = ''.join(c for c in phone if c.isdigit() or c == '+')
        resp = requests.get(
            f"https://api.hlr-lookups.com/api/v1/noauth/hlr/",
            params={"number": clean},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("results"):
                r = data["results"][0]
                results.append({"champ": "HLR Status", "valeur": r.get("status", ""), "source": "HLR Lookup"})
    except Exception:
        pass

    return results
