def run(file_path):
    results = []
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS

        img = Image.open(file_path)
        results.append({"champ": "Format", "valeur": img.format or "Inconnu", "source": "Pillow"})
        results.append({"champ": "Dimensions", "valeur": f"{img.width}x{img.height} px", "source": "Pillow"})
        results.append({"champ": "Mode", "valeur": img.mode, "source": "Pillow"})

        exif_data = img._getexif()
        if exif_data:
            gps_info = {}
            for tag_id, value in exif_data.items():
                tag = TAGS.get(tag_id, str(tag_id))
                if tag == "GPSInfo":
                    for gps_tag_id, gps_val in value.items():
                        gps_tag = GPSTAGS.get(gps_tag_id, str(gps_tag_id))
                        gps_info[gps_tag] = gps_val
                    continue
                if isinstance(value, bytes):
                    try:
                        value = value.decode("utf-8", errors="replace")
                    except Exception:
                        value = repr(value)
                if isinstance(value, str) and len(value) > 200:
                    value = value[:200] + "..."
                results.append({"champ": tag, "valeur": str(value), "source": "EXIF"})

            if gps_info:
                lat = _convert_gps(gps_info.get("GPSLatitude"), gps_info.get("GPSLatitudeRef", "N"))
                lon = _convert_gps(gps_info.get("GPSLongitude"), gps_info.get("GPSLongitudeRef", "E"))
                if lat and lon:
                    results.append({"champ": "GPS Latitude", "valeur": f"{lat:.6f}", "source": "EXIF GPS"})
                    results.append({"champ": "GPS Longitude", "valeur": f"{lon:.6f}", "source": "EXIF GPS"})
                    results.append({"champ": "Google Maps", "valeur": f"https://maps.google.com/?q={lat},{lon}", "source": "EXIF GPS"})
                    alt = gps_info.get("GPSAltitude")
                    if alt:
                        try:
                            results.append({"champ": "Altitude", "valeur": f"{float(alt):.1f} m", "source": "EXIF GPS"})
                        except Exception:
                            pass
        else:
            results.append({"champ": "EXIF", "valeur": "Aucune donnée EXIF trouvée", "source": "Pillow"})

    except ImportError:
        results.append({"champ": "Erreur", "valeur": "Installez: pip install Pillow", "source": "system"})
    except Exception as e:
        results.append({"champ": "Erreur", "valeur": str(e), "source": "Pillow"})

    try:
        import exifread
        with open(file_path, "rb") as f:
            tags = exifread.process_file(f, details=False)
        for k, v in tags.items():
            val = str(v)[:200]
            already = any(r["champ"] == k for r in results)
            if not already:
                results.append({"champ": k, "valeur": val, "source": "exifread"})
    except Exception:
        pass

    return results


def _convert_gps(coord, ref):
    if not coord:
        return None
    try:
        d, m, s = [float(x) for x in coord]
        val = d + m / 60 + s / 3600
        if ref in ("S", "W"):
            val = -val
        return val
    except Exception:
        return None
