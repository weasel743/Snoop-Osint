import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def run(address, timeout=10):
    results = []
    addr = address.strip()
    if addr.startswith("0x") or len(addr) == 42:
        results.extend(_check_eth(addr, timeout))
    else:
        results.extend(_check_btc(addr, timeout))
    return results


def _check_btc(address, timeout):
    results = []
    try:
        resp = requests.get(
            f"https://blockchain.info/rawaddr/{address}",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            d = resp.json()
            balance_btc = d.get("final_balance", 0) / 1e8
            received_btc = d.get("total_received", 0) / 1e8
            sent_btc = d.get("total_sent", 0) / 1e8
            n_tx = d.get("n_tx", 0)
            results = [
                {"champ": "Adresse", "valeur": address, "source": "Blockchain.info"},
                {"champ": "Balance actuelle", "valeur": f"{balance_btc:.8f} BTC", "source": "Blockchain.info"},
                {"champ": "Total reçu", "valeur": f"{received_btc:.8f} BTC", "source": "Blockchain.info"},
                {"champ": "Total envoyé", "valeur": f"{sent_btc:.8f} BTC", "source": "Blockchain.info"},
                {"champ": "Nombre de transactions", "valeur": str(n_tx), "source": "Blockchain.info"},
            ]
            txs = d.get("txs", [])[:5]
            for tx in txs:
                tx_hash = tx.get("hash", "")[:20] + "..."
                time_str = str(tx.get("time", ""))
                val_out = sum(o.get("value", 0) for o in tx.get("out", [])) / 1e8
                results.append({
                    "champ": f"TX: {tx_hash}",
                    "valeur": f"{val_out:.6f} BTC — {time_str}",
                    "source": "Blockchain.info"
                })
        elif resp.status_code == 500:
            results.append({"champ": "Erreur", "valeur": "Adresse invalide ou non trouvée", "source": "Blockchain.info"})
    except Exception as e:
        results.append({"champ": "Erreur", "valeur": str(e), "source": "Blockchain.info"})

    try:
        resp2 = requests.get(
            f"https://api.blockcypher.com/v1/btc/main/addrs/{address}/balance",
            headers=HEADERS, timeout=timeout
        )
        if resp2.status_code == 200:
            d2 = resp2.json()
            results.append({"champ": "Confirmé (BlockCypher)", "valeur": f"{d2.get('balance',0)/1e8:.8f} BTC", "source": "BlockCypher"})
    except Exception:
        pass

    return results


def _check_eth(address, timeout):
    results = []
    try:
        resp = requests.get(
            "https://api.etherscan.io/api",
            params={"module": "account", "action": "balance", "address": address, "tag": "latest"},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            d = resp.json()
            if d.get("status") == "1":
                balance_eth = int(d.get("result", 0)) / 1e18
                results.append({"champ": "Adresse ETH", "valeur": address, "source": "Etherscan"})
                results.append({"champ": "Balance ETH", "valeur": f"{balance_eth:.6f} ETH", "source": "Etherscan"})
    except Exception:
        pass

    try:
        resp2 = requests.get(
            "https://api.etherscan.io/api",
            params={"module": "account", "action": "txlist", "address": address,
                    "sort": "desc", "page": 1, "offset": 5},
            headers=HEADERS, timeout=timeout
        )
        if resp2.status_code == 200:
            d2 = resp2.json()
            if d2.get("status") == "1":
                txs = d2.get("result", [])
                results.append({"champ": "Transactions ETH", "valeur": str(len(txs)), "source": "Etherscan"})
                for tx in txs[:3]:
                    val = int(tx.get("value", 0)) / 1e18
                    results.append({
                        "champ": f"TX: {tx.get('hash','')[:20]}...",
                        "valeur": f"{val:.6f} ETH",
                        "source": "Etherscan"
                    })
    except Exception:
        pass

    if not results:
        results.append({"champ": "Info", "valeur": "Impossible de vérifier (API non configurée)", "source": "Etherscan"})
    return results
