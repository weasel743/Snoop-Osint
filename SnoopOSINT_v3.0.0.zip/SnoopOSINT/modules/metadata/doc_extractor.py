"""
Extraction de métadonnées depuis PDF, DOCX, XLSX, images
"""
import os

def run(file_path, timeout=10):
    results = []
    ext = os.path.splitext(file_path)[1].lower()
    if ext in (".jpg",".jpeg",".png",".tiff",".webp",".bmp",".raw",".heic"):
        results.extend(_image_meta(file_path))
    elif ext == ".pdf":
        results.extend(_pdf_meta(file_path))
    elif ext in (".docx",".doc"):
        results.extend(_docx_meta(file_path))
    elif ext in (".xlsx",".xls"):
        results.extend(_xlsx_meta(file_path))
    else:
        results.extend(_image_meta(file_path))
    return results

def _image_meta(path):
    results = []
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS
        img = Image.open(path)
        results.append({"Champ":"Format","Valeur":img.format or "?","Source":"Pillow"})
        results.append({"Champ":"Dimensions","Valeur":f"{img.width}x{img.height}","Source":"Pillow"})
        results.append({"Champ":"Mode couleur","Valeur":img.mode,"Source":"Pillow"})
        exif = img._getexif()
        if exif:
            gps = {}
            for tid, val in exif.items():
                tag = TAGS.get(tid, str(tid))
                if tag == "GPSInfo":
                    for gtid, gval in val.items(): gps[GPSTAGS.get(gtid,str(gtid))] = gval
                    continue
                if isinstance(val, bytes):
                    try: val = val.decode("utf-8","replace")
                    except: val = repr(val)
                if str(val).strip(): results.append({"Champ":tag,"Valeur":str(val)[:200],"Source":"EXIF"})
            if gps:
                lat = _gps(gps.get("GPSLatitude"), gps.get("GPSLatitudeRef","N"))
                lon = _gps(gps.get("GPSLongitude"), gps.get("GPSLongitudeRef","E"))
                if lat and lon:
                    results.append({"Champ":"GPS Latitude","Valeur":f"{lat:.6f}","Source":"EXIF GPS"})
                    results.append({"Champ":"GPS Longitude","Valeur":f"{lon:.6f}","Source":"EXIF GPS"})
                    results.append({"Champ":"Google Maps","Valeur":f"https://maps.google.com/?q={lat},{lon}","Source":"EXIF GPS"})
    except ImportError: results.append({"Champ":"Erreur","Valeur":"pip install Pillow","Source":"system"})
    except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"Pillow"})
    return results

def _gps(coord, ref):
    if not coord: return None
    try:
        d,m,s = [float(x) for x in coord]
        v = d + m/60 + s/3600
        return -v if ref in ("S","W") else v
    except: return None

def _pdf_meta(path):
    results = []
    try:
        import PyPDF2
        with open(path,"rb") as f:
            reader = PyPDF2.PdfReader(f)
            results.append({"Champ":"Pages","Valeur":str(len(reader.pages)),"Source":"PyPDF2"})
            meta = reader.metadata
            if meta:
                for k,v in meta.items():
                    if v: results.append({"Champ":k.lstrip("/"),"Valeur":str(v)[:200],"Source":"PDF Metadata"})
    except ImportError:
        try:
            with open(path,"rb") as f: content = f.read(4096).decode("latin-1","replace")
            import re
            for m in re.finditer(r'/(\w+)\s*\(([^)]+)\)', content):
                results.append({"Champ":m.group(1),"Valeur":m.group(2)[:200],"Source":"PDF Raw"})
        except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"PDF"})
    except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"PDF"})
    return results

def _docx_meta(path):
    results = []
    try:
        from docx import Document
        doc = Document(path)
        props = doc.core_properties
        for attr in ("author","created","description","keywords","last_modified_by",
                     "modified","revision","subject","title"):
            val = getattr(props, attr, None)
            if val: results.append({"Champ":attr.replace("_"," ").capitalize(),"Valeur":str(val)[:200],"Source":"DOCX"})
        results.append({"Champ":"Paragraphes","Valeur":str(len(doc.paragraphs)),"Source":"DOCX"})
    except ImportError: results.append({"Champ":"Info","Valeur":"pip install python-docx pour lire les .docx","Source":"system"})
    except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"DOCX"})
    return results

def _xlsx_meta(path):
    results = []
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True)
        props = wb.properties
        for attr in ("creator","created","description","keywords","lastModifiedBy",
                     "modified","revision","subject","title"):
            val = getattr(props, attr, None)
            if val: results.append({"Champ":attr,"Valeur":str(val)[:200],"Source":"XLSX"})
        results.append({"Champ":"Feuilles","Valeur":", ".join(wb.sheetnames),"Source":"XLSX"})
    except ImportError: results.append({"Champ":"Info","Valeur":"pip install openpyxl pour lire les .xlsx","Source":"system"})
    except Exception as e: results.append({"Champ":"Erreur","Valeur":str(e),"Source":"XLSX"})
    return results
