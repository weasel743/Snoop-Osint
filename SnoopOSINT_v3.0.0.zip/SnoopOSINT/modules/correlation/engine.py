"""
Moteur de corrélation automatique — le coeur unique de Snoop OSINT v3
Explore automatiquement les connexions entre les données trouvées.
"""
import re, threading
from PyQt6.QtCore import QThread, pyqtSignal

# Types de nœuds
NODE_EMAIL = "email"
NODE_USERNAME = "username"
NODE_DOMAIN = "domain"
NODE_IP = "ip"
NODE_PHONE = "phone"
NODE_NAME = "name"
NODE_PLATFORM = "platform"
NODE_BREACH = "breach"
NODE_CRYPTO = "crypto"
NODE_ORG = "org"
NODE_URL = "url"

# Couleurs par type
NODE_COLORS = {
    NODE_EMAIL:    "#7C3AED",
    NODE_USERNAME: "#2563EB",
    NODE_DOMAIN:   "#0891B2",
    NODE_IP:       "#059669",
    NODE_PHONE:    "#D97706",
    NODE_NAME:     "#DB2777",
    NODE_PLATFORM: "#34D399",
    NODE_BREACH:   "#DC2626",
    NODE_CRYPTO:   "#F59E0B",
    NODE_ORG:      "#8B5CF6",
    NODE_URL:      "#6B7280",
}

def detect_type(value):
    v = str(value).strip()
    if re.match(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$', v): return NODE_EMAIL
    if re.match(r'^\d{1,3}(\.\d{1,3}){3}$', v): return NODE_IP
    if re.match(r'^(\+?\d[\d\s\-().]{7,20})$', v): return NODE_PHONE
    if re.match(r'^(https?://)?[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}(/.*)?$', v) and '.' in v and ' ' not in v:
        if '/' in v or v.count('.') >= 1: return NODE_DOMAIN
    if re.match(r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$', v): return NODE_CRYPTO
    if re.match(r'^0x[a-fA-F0-9]{40}$', v): return NODE_CRYPTO
    return NODE_USERNAME


class CorrelationNode:
    def __init__(self, value, ntype=None, source="", confidence=100, data=None):
        self.value = str(value).strip()
        self.type = ntype or detect_type(self.value)
        self.source = source
        self.confidence = confidence
        self.data = data or {}
        self.id = f"{self.type}:{self.value}"

    def to_dict(self):
        return {"id":self.id,"value":self.value,"type":self.type,
                "source":self.source,"confidence":self.confidence,"data":self.data}


class CorrelationEdge:
    def __init__(self, src_id, dst_id, label="", weight=1.0):
        self.src = src_id; self.dst = dst_id
        self.label = label; self.weight = weight
    def to_dict(self):
        return {"src":self.src,"dst":self.dst,"label":self.label,"weight":self.weight}


class CorrelationGraph:
    def __init__(self):
        self.nodes = {}  # id -> CorrelationNode
        self.edges = []  # list of CorrelationEdge

    def add_node(self, node):
        if node.id not in self.nodes:
            self.nodes[node.id] = node
            return True
        else:
            existing = self.nodes[node.id]
            existing.confidence = max(existing.confidence, node.confidence)
            existing.data.update(node.data)
            return False

    def add_edge(self, src_id, dst_id, label="", weight=1.0):
        for e in self.edges:
            if e.src == src_id and e.dst == dst_id: return
        self.edges.append(CorrelationEdge(src_id, dst_id, label, weight))

    def get_nodes_list(self):
        return [n.to_dict() for n in self.nodes.values()]

    def get_edges_list(self):
        return [e.to_dict() for e in self.edges]

    def node_count(self): return len(self.nodes)
    def edge_count(self): return len(self.edges)


class CorrelationEngine(QThread):
    """
    Moteur principal — explore en profondeur à partir d'une seed.
    Émet des signaux PyQt6 pour mise à jour en temps réel de l'UI.
    """
    node_found = pyqtSignal(dict)        # nouveau nœud
    edge_found = pyqtSignal(dict)        # nouvelle connexion
    status_update = pyqtSignal(str)      # message de statut
    progress = pyqtSignal(int, int)      # done, total
    finished_signal = pyqtSignal(dict)   # graphe complet

    def __init__(self, seed, max_depth=3, max_nodes=50, timeout=10):
        super().__init__()
        self.seed = seed
        self.max_depth = max_depth
        self.max_nodes = max_nodes
        self.timeout = timeout
        self.graph = CorrelationGraph()
        self._stop = False
        self._visited = set()
        self._queue = []  # (node_id, depth)

    def stop(self): self._stop = True

    def run(self):
        seed_node = CorrelationNode(self.seed)
        self._emit_node(seed_node)
        self._queue.append((seed_node.id, 0))
        total_estimated = self.max_nodes
        done = 0

        while self._queue and not self._stop:
            node_id, depth = self._queue.pop(0)
            if node_id in self._visited: continue
            if depth >= self.max_depth: continue
            if self.graph.node_count() >= self.max_nodes: break

            self._visited.add(node_id)
            node = self.graph.nodes.get(node_id)
            if not node: continue

            done += 1
            self.progress.emit(done, max(total_estimated, done+1))
            self.status_update.emit(f"Analyse: {node.value[:50]}...")
            self._explore(node, depth)

        summary = self._build_summary()
        self.finished_signal.emit({
            "nodes": self.graph.get_nodes_list(),
            "edges": self.graph.get_edges_list(),
            "summary": summary
        })

    def _emit_node(self, node):
        is_new = self.graph.add_node(node)
        if is_new:
            self.node_found.emit(node.to_dict())
        return is_new

    def _emit_edge(self, src_id, dst_id, label=""):
        self.graph.add_edge(src_id, dst_id, label)
        self.edge_found.emit({"src":src_id,"dst":dst_id,"label":label})

    def _explore(self, node, depth):
        if node.type == NODE_EMAIL: self._explore_email(node, depth)
        elif node.type == NODE_USERNAME: self._explore_username(node, depth)
        elif node.type == NODE_DOMAIN: self._explore_domain(node, depth)
        elif node.type == NODE_IP: self._explore_ip(node, depth)

    def _explore_email(self, node, depth):
        email = node.value
        self.status_update.emit(f"Email: {email}")

        # Gravatar
        try:
            import hashlib, requests
            h = hashlib.md5(email.lower().strip().encode()).hexdigest()
            resp = requests.get(f"https://www.gravatar.com/{h}.json",
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                entry = resp.json().get("entry",[{}])[0]
                display = entry.get("displayName","")
                if display:
                    n = CorrelationNode(display, NODE_NAME, "Gravatar", 85,
                        {"avatar":f"https://www.gravatar.com/avatar/{h}"})
                    self._emit_node(n); self._emit_edge(node.id, n.id, "Gravatar")
                for acc in entry.get("accounts",[]):
                    url = acc.get("url","")
                    username = acc.get("username","")
                    if username:
                        un = CorrelationNode(username, NODE_USERNAME, "Gravatar", 80)
                        self._emit_node(un); self._emit_edge(node.id, un.id, "Gravatar account")
                        self._queue.append((un.id, depth+1))
        except: pass

        # GitHub search
        try:
            import requests
            resp = requests.get("https://api.github.com/search/users",
                params={"q":f"{email} in:email"},
                headers={"User-Agent":"SnoopOSINT","Accept":"application/vnd.github.v3+json"},
                timeout=self.timeout)
            if resp.status_code == 200:
                items = resp.json().get("items",[])
                for item in items[:3]:
                    un = CorrelationNode(item["login"], NODE_USERNAME, "GitHub", 90,
                        {"github_url":item.get("html_url",""),"avatar":item.get("avatar_url","")})
                    self._emit_node(un); self._emit_edge(node.id, un.id, "GitHub email")
                    self._queue.append((un.id, depth+1))
        except: pass

        # Domaine de l'email
        try:
            domain = email.split("@")[1]
            skip = {"gmail.com","yahoo.com","hotmail.com","outlook.com","protonmail.com",
                    "icloud.com","live.com","msn.com","ymail.com","free.fr","orange.fr","sfr.fr"}
            if domain not in skip:
                dn = CorrelationNode(domain, NODE_DOMAIN, "Email domain", 95)
                self._emit_node(dn); self._emit_edge(node.id, dn.id, "Domaine email")
                self._queue.append((dn.id, depth+1))
        except: pass

        # Fuites via BreachDirectory
        try:
            import requests
            resp = requests.get("https://breachdirectory.org/api",
                params={"func":"auto","term":email},
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success") and data.get("result"):
                    bn = CorrelationNode(f"Fuite: {email}", NODE_BREACH, "BreachDirectory", 80,
                        {"count":len(data["result"]),"email":email})
                    self._emit_node(bn); self._emit_edge(node.id, bn.id, "Fuite détectée")
        except: pass

    def _explore_username(self, node, depth):
        username = node.value
        self.status_update.emit(f"Username: {username}")

        # GitHub profil complet
        try:
            import requests
            resp = requests.get(f"https://api.github.com/users/{username}",
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                d = resp.json()
                if d.get("email"):
                    en = CorrelationNode(d["email"], NODE_EMAIL, "GitHub profil", 95)
                    self._emit_node(en); self._emit_edge(node.id, en.id, "Email GitHub")
                    self._queue.append((en.id, depth+1))
                if d.get("name"):
                    nn = CorrelationNode(d["name"], NODE_NAME, "GitHub profil", 90, d)
                    self._emit_node(nn); self._emit_edge(node.id, nn.id, "Nom réel")
                if d.get("company"):
                    org = d["company"].strip().lstrip("@")
                    on = CorrelationNode(org, NODE_ORG, "GitHub profil", 75)
                    self._emit_node(on); self._emit_edge(node.id, on.id, "Organisation")
                if d.get("blog"):
                    blog = d["blog"]
                    if "." in blog:
                        blog = blog.replace("https://","").replace("http://","").split("/")[0]
                        dn = CorrelationNode(blog, NODE_DOMAIN, "GitHub blog", 80)
                        self._emit_node(dn); self._emit_edge(node.id, dn.id, "Site web")
                        self._queue.append((dn.id, depth+1))
                if d.get("twitter_username"):
                    tw = CorrelationNode(d["twitter_username"], NODE_USERNAME, "GitHub Twitter", 85,
                        {"platform":"Twitter"})
                    self._emit_node(tw); self._emit_edge(node.id, tw.id, "Twitter lié")
                    self._queue.append((tw.id, depth+1))
        except: pass

        # Extraire emails depuis les commits GitHub
        try:
            import requests, re
            resp = requests.get(f"https://api.github.com/users/{username}/events/public",
                params={"per_page":30}, headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                emails = set(re.findall(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', resp.text))
                for e in emails:
                    if "github" not in e and "noreply" not in e and "example" not in e:
                        en = CorrelationNode(e, NODE_EMAIL, "GitHub events", 70)
                        self._emit_node(en); self._emit_edge(node.id, en.id, "Email commit")
                        self._queue.append((en.id, depth+1))
        except: pass

        # Vérification rapide sur quelques plateformes clés
        try:
            import requests
            QUICK_SITES = [
                ("Reddit",    f"https://www.reddit.com/user/{username}/about.json", "name"),
                ("Dev.to",    f"https://dev.to/api/users/by_username?url={username}", "username"),
            ]
            for platform, url, key in QUICK_SITES:
                try:
                    r = requests.get(url, headers={"User-Agent":"SnoopOSINT"}, timeout=5)
                    if r.status_code == 200 and key in r.text:
                        pn = CorrelationNode(f"{platform}:{username}", NODE_PLATFORM, platform, 85,
                            {"platform":platform,"username":username,"url":url.split("/api")[0].split("/about")[0]})
                        self._emit_node(pn); self._emit_edge(node.id, pn.id, f"Présent sur {platform}")
                except: pass
        except: pass

    def _explore_domain(self, node, depth):
        domain = node.value.replace("https://","").replace("http://","").split("/")[0]
        self.status_update.emit(f"Domaine: {domain}")

        # DNS → IP
        try:
            import socket
            ip = socket.gethostbyname(domain)
            ipn = CorrelationNode(ip, NODE_IP, "DNS résolution", 95)
            self._emit_node(ipn); self._emit_edge(node.id, ipn.id, "Résoud vers")
            self._queue.append((ipn.id, depth+1))
        except: pass

        # WHOIS email/org
        try:
            import requests
            resp = requests.get(f"https://who-dat.as93.net/{domain}",
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                d = resp.json()
                reg = d.get("Registrant",{})
                if reg.get("Email") and "@" in reg["Email"]:
                    en = CorrelationNode(reg["Email"], NODE_EMAIL, "WHOIS", 80)
                    self._emit_node(en); self._emit_edge(node.id, en.id, "WHOIS email")
                    self._queue.append((en.id, depth+1))
                if reg.get("Organization"):
                    on = CorrelationNode(reg["Organization"], NODE_ORG, "WHOIS", 75)
                    self._emit_node(on); self._emit_edge(node.id, on.id, "Organisation")
        except: pass

        # Sous-domaines via crt.sh
        try:
            import requests
            resp = requests.get("https://crt.sh/", params={"q":f"%.{domain}","output":"json"},
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                seen = set()
                for c in resp.json()[:20]:
                    cn = c.get("common_name","")
                    if cn and cn != domain and cn not in seen and "*" not in cn:
                        seen.add(cn)
                        sn = CorrelationNode(cn, NODE_DOMAIN, "crt.sh", 85)
                        self._emit_node(sn); self._emit_edge(node.id, sn.id, "Sous-domaine")
        except: pass

    def _explore_ip(self, node, depth):
        ip = node.value
        self.status_update.emit(f"IP: {ip}")
        try:
            import requests
            resp = requests.get(f"http://ip-api.com/json/{ip}",
                params={"fields":"status,org,as,isp,country,city,lat,lon,hosting,proxy"},
                headers={"User-Agent":"SnoopOSINT"}, timeout=self.timeout)
            if resp.status_code == 200:
                d = resp.json()
                if d.get("status") == "success":
                    if d.get("org"):
                        on = CorrelationNode(d["org"], NODE_ORG, "ip-api.com", 80,
                            {"country":d.get("country",""),"city":d.get("city",""),
                             "hosting":d.get("hosting",False),"proxy":d.get("proxy",False)})
                        self._emit_node(on); self._emit_edge(node.id, on.id, "Organisation IP")
        except: pass

    def _build_summary(self):
        counts = {}
        for n in self.graph.nodes.values():
            counts[n.type] = counts.get(n.type,0) + 1
        parts = [f"{v} {k}" for k,v in counts.items()]
        return f"{self.graph.node_count()} nœuds — {' • '.join(parts)}"
