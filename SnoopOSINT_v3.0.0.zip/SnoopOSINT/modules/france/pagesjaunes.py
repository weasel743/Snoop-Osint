"""
Pages Jaunes / Pages Blanches — Annuaire français
"""
import requests, re
H = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

def run(query, what="", where="france", timeout=15):
    results = []
    results.extend(_search_pj(query, what, where, timeout))
    results.extend(_search_118712(query, timeout))
    return results

def _search_pj(query, what, where, timeout):
    results = []
    try:
        search_what = what or query
        resp = requests.get("https://www.pagesjaunes.fr/annuaire/chercherlespros",
            params={"quoiqui":search_what,"ou":where,"idOu":""},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(resp.text, "html.parser")
            for card in soup.select(".bi-content")[:15]:
                name = card.select_one(".denomination-links")
                addr = card.select_one(".adresse")
                phone = card.select_one(".num-deci")
                cat = card.select_one(".categorie")
                results.append({
                    "Source":"Pages Jaunes",
                    "Nom":(name.text.strip() if name else ""),
                    "Adresse":(addr.text.strip() if addr else ""),
                    "Téléphone":(phone.text.strip() if phone else ""),
                    "Catégorie":(cat.text.strip() if cat else ""),
                    "URL":""
                })
    except Exception as e:
        results.append({"Source":"Pages Jaunes","Nom":f"Erreur: {e}","Adresse":"","Téléphone":"","Catégorie":"","URL":""})
    return results

def _search_118712(query, timeout):
    results = []
    try:
        resp = requests.get("https://www.118712.fr/recherche",
            params={"qui":query,"quoi":"","ou":""},
            headers=H, timeout=timeout)
        if resp.status_code == 200 and query.lower() in resp.text.lower():
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(resp.text, "html.parser")
            for res in soup.select(".result-item")[:10]:
                name_el = res.select_one(".result-name")
                addr_el = res.select_one(".result-address")
                phone_el = res.select_one(".result-phone")
                if name_el:
                    results.append({
                        "Source":"118712","Nom":name_el.text.strip(),
                        "Adresse":addr_el.text.strip() if addr_el else "",
                        "Téléphone":phone_el.text.strip() if phone_el else "",
                        "Catégorie":"","URL":""
                    })
    except: pass
    return results
