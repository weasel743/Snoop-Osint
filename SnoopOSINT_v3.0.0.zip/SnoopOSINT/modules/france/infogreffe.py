"""
Infogreffe — Données officielles des greffes des tribunaux de commerce
"""
import requests
H = {"User-Agent":"SnoopOSINT/3.0"}

def run(query, timeout=15):
    results = []
    try:
        resp = requests.get("https://data.infogreffe.fr/api/explore/v2.1/catalog/datasets/dirigeants/records",
            params={"where":f'raisonSociale like "%{query}%" OR siren like "%{query}%"',
                    "limit":20},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for rec in data.get("results",[]):
                results.append({
                    "Source":"Infogreffe","Raison sociale":rec.get("raisonSociale",""),
                    "SIREN":rec.get("siren",""),"Dirigeant":f"{rec.get('prenom','')} {rec.get('nom','')}".strip(),
                    "Qualité":rec.get("qualite",""),"Ville":rec.get("ville",""),
                    "Date MAJ":rec.get("dateMiseAJour",""),"Forme juridique":rec.get("formeJuridique","")
                })
    except Exception as e:
        results.append({"Source":"Infogreffe","Raison sociale":"Erreur","SIREN":str(e),
            "Dirigeant":"","Qualité":"","Ville":"","Date MAJ":"","Forme juridique":""})
    if not results:
        try:
            resp2 = requests.get("https://recherche-entreprises.api.gouv.fr/search",
                params={"q":query,"per_page":5},
                headers=H, timeout=timeout)
            if resp2.status_code == 200:
                for r in resp2.json().get("results",[]):
                    dirigeants = r.get("dirigeants",[])
                    for d in dirigeants[:3]:
                        results.append({
                            "Source":"API Entreprises","Raison sociale":r.get("nom_complet",""),
                            "SIREN":r.get("siren",""),
                            "Dirigeant":f"{d.get('prenoms','')} {d.get('nom','')}".strip(),
                            "Qualité":d.get("qualite",""),"Ville":r.get("siege",{}).get("libelle_commune",""),
                            "Date MAJ":"","Forme juridique":r.get("forme_juridique","")
                        })
        except: pass
    return results
