"""
Data.gouv.fr — Données ouvertes officielles françaises
"""
import requests
H = {"User-Agent":"SnoopOSINT/3.0"}

def run(query, timeout=15):
    results = []
    results.extend(_search_datasets(query, timeout))
    results.extend(_search_elus(query, timeout))
    results.extend(_search_rna(query, timeout))
    return results

def _search_datasets(query, timeout):
    results = []
    try:
        resp = requests.get("https://www.data.gouv.fr/api/1/datasets/",
            params={"q":query,"page_size":5},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            for ds in resp.json().get("data",[]):
                results.append({
                    "Source":"data.gouv.fr","Type":"Dataset",
                    "Titre":ds.get("title","")[:80],"Organisation":ds.get("organization",{}).get("name","") if ds.get("organization") else "",
                    "Date":ds.get("last_modified","")[:10],"URL":ds.get("page",""),
                    "Description":(ds.get("description","") or "")[:100]
                })
    except: pass
    return results

def _search_elus(query, timeout):
    results = []
    try:
        resp = requests.get("https://www.data.gouv.fr/api/1/datasets/5c34944606e3e73d4a551f5e/",
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            resources = resp.json().get("resources",[])
            for res in resources[:2]:
                url = res.get("url","")
                if url and url.endswith(".csv"):
                    r2 = requests.get(url, headers=H, timeout=timeout, stream=True)
                    content = ""
                    for chunk in r2.iter_content(chunk_size=65536):
                        content += chunk.decode("utf-8","replace")
                        if len(content) > 200000: break
                    for line in content.split("\n"):
                        if query.lower() in line.lower():
                            parts = line.split(";")
                            if len(parts) > 5:
                                results.append({
                                    "Source":"Répertoire Élus Nationaux","Type":"Élu",
                                    "Titre":f"{parts[1] if len(parts)>1 else ''} {parts[2] if len(parts)>2 else ''}".strip(),
                                    "Organisation":parts[4] if len(parts)>4 else "",
                                    "Date":"","URL":"","Description":line[:150]
                                })
                            if len(results) >= 10: break
    except: pass
    return results

def _search_rna(query, timeout):
    results = []
    try:
        resp = requests.get("https://api-rna.dataesr.ovh/api/v1/associations",
            params={"q":query,"per_page":10},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            for a in resp.json().get("data",[]):
                results.append({
                    "Source":"RNA (Associations)","Type":"Association",
                    "Titre":a.get("titre",""),"Organisation":a.get("objet","")[:80],
                    "Date":a.get("date_creation","")[:10],"URL":a.get("url_rna",""),
                    "Description":f"Siège: {a.get('adresse_siege_social',{}).get('libelle_commune','')}"
                })
    except: pass
    return results
