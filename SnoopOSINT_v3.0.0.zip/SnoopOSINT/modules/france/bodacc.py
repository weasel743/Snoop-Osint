"""
BODACC — Bulletin Officiel des Annonces Civiles et Commerciales
API officielle et gratuite : api.bodacc.fr
"""
import requests
H = {"User-Agent":"SnoopOSINT/3.0","Accept":"application/json"}

def run(query, timeout=15):
    results = []
    results.extend(_search_bodacc(query, timeout))
    results.extend(_search_sirene(query, timeout))
    return results

def _search_bodacc(query, timeout):
    results = []
    try:
        resp = requests.get("https://bodacc-datadila.opendatasoft.com/api/v2/catalog/datasets/annonces-commerciales/records",
            params={"where":f'numeroImmatriculation like "*{query}*" OR denomination like "*{query}*"',
                    "limit":20,"order_by":"dateparution desc"},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for rec in data.get("records",[]):
                f = rec.get("record",{}).get("fields",{})
                results.append({
                    "Source":"BODACC","Type":f.get("typeavis",""),"Dénomination":f.get("denomination",""),
                    "SIREN":f.get("numeroImmatriculation",""),"Date":f.get("dateparution",""),
                    "Tribunal":f.get("tribunal",""),"Ville":f.get("ville",""),
                    "Description":(f.get("jugement","") or f.get("acte","") or "")[:120]
                })
    except Exception as e:
        results.append({"Source":"BODACC","Type":"Erreur","Dénomination":str(e),"SIREN":"","Date":"","Tribunal":"","Ville":"","Description":""})
    return results

def _search_sirene(query, timeout):
    results = []
    try:
        resp = requests.get("https://api.insee.fr/entreprises/sirene/V3.11/siret",
            params={"q":f'denominationUniteLegale:"{query}"',"nombre":10},
            headers={**H,"Authorization":"Bearer "},
            timeout=timeout)
    except: pass
    try:
        resp = requests.get("https://recherche-entreprises.api.gouv.fr/search",
            params={"q":query,"per_page":10,"page":1},
            headers=H, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for r in data.get("results",[]):
                results.append({
                    "Source":"API Entreprises (gouv.fr)",
                    "Type":"Entreprise",
                    "Dénomination":r.get("nom_complet",""),
                    "SIREN":r.get("siren",""),
                    "Date":r.get("date_creation",""),
                    "Tribunal":"",
                    "Ville":r.get("siege",{}).get("libelle_commune",""),
                    "Description":f"NAF:{r.get('activite_principale','')} | {r.get('categorie_entreprise','')} | Effectif:{r.get('tranche_effectif_salarie','')}"
                })
    except Exception as e:
        results.append({"Source":"API Entreprises","Type":"Info","Dénomination":"Essayez le nom exact ou le SIREN",
            "SIREN":"","Date":"","Tribunal":"","Ville":"","Description":str(e)})
    return results
