"""
Recherche sur les sites de paste — Pastebin, Ghostbin, etc.
"""
import requests, re
H = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

def run(query, timeout=15):
    results = []
    results.extend(_search_psbdmp(query, timeout))
    results.extend(_search_pastebin_scrape(query, timeout))
    results.extend(_search_pastehunter(query, timeout))
    return results

def _search_psbdmp(query, timeout):
    results = []
    try:
        resp = requests.get("https://psbdmp.ws/api/v3/search",
            params={"q":query}, headers=H, timeout=timeout)
        if resp.status_code == 200:
            data = resp.json()
            for item in data.get("data",[])[:10]:
                results.append({
                    "Source":"psbdmp.ws","ID":item.get("id",""),
                    "Date":item.get("time",""),"Taille":str(item.get("length",""))+"b",
                    "URL":f"https://pastebin.com/{item.get('id','')}",
                    "Extrait":(item.get("text","") or "")[:120]
                })
    except: pass
    return results

def _search_pastebin_scrape(query, timeout):
    results = []
    try:
        resp = requests.get("https://pastebin.com/search",
            params={"q":query}, headers=H, timeout=timeout)
        if resp.status_code == 200:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(resp.text, "html.parser")
            for item in soup.select(".search-result")[:10]:
                title = item.select_one(".preview-title")
                link = item.select_one("a")
                date = item.select_one(".date")
                preview = item.select_one(".paste-preview-content")
                results.append({
                    "Source":"Pastebin",
                    "ID":link["href"].lstrip("/") if link and link.get("href") else "",
                    "Date":date.text.strip() if date else "",
                    "Taille":"",
                    "URL":f"https://pastebin.com{link['href']}" if link else "",
                    "Extrait":preview.text.strip()[:120] if preview else (title.text.strip() if title else "")
                })
    except: pass
    return results

def _search_pastehunter(query, timeout):
    results = []
    try:
        resp = requests.get("https://shortener.goo.ne.jp/api.php",
            params={"url":f"https://pastehunter.com/search?q={query}"},
            headers=H, timeout=timeout)
    except: pass
    try:
        resp = requests.get("https://www.pastes.io/api/search",
            params={"query":query}, headers=H, timeout=timeout)
        if resp.status_code == 200:
            for item in resp.json().get("pastes",[])[:5]:
                results.append({
                    "Source":"pastes.io","ID":item.get("id",""),
                    "Date":item.get("created","")[:10],"Taille":"",
                    "URL":f"https://pastes.io/{item.get('id','')}",
                    "Extrait":item.get("title","")[:120]
                })
    except: pass
    return results
