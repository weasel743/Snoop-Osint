import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

SITES = [
    {"name":"GitHub","url":"https://github.com/{}","check":"status","not_found":404},
    {"name":"Reddit","url":"https://www.reddit.com/user/{}/about.json","check":"json","key":"name"},
    {"name":"Instagram","url":"https://www.instagram.com/{}/","check":"html","found":'"is_private"',"not_found":"Page introuvable"},
    {"name":"Twitter/X","url":"https://twitter.com/{}","check":"status","not_found":404},
    {"name":"TikTok","url":"https://www.tiktok.com/@{}","check":"html","found":'"uniqueId"'},
    {"name":"YouTube","url":"https://www.youtube.com/@{}","check":"status","not_found":404},
    {"name":"Twitch","url":"https://www.twitch.tv/{}","check":"html","found":'"login"'},
    {"name":"Steam","url":"https://steamcommunity.com/id/{}","check":"html","not_found":"The specified profile could not be found"},
    {"name":"LinkedIn","url":"https://www.linkedin.com/in/{}","check":"status","not_found":404},
    {"name":"Pinterest","url":"https://www.pinterest.com/{}/","check":"html","found":'"username"'},
    {"name":"Medium","url":"https://medium.com/@{}","check":"status","not_found":404},
    {"name":"Dev.to","url":"https://dev.to/{}","check":"status","not_found":404},
    {"name":"GitLab","url":"https://gitlab.com/{}","check":"status","not_found":404},
    {"name":"Bitbucket","url":"https://bitbucket.org/{}","check":"status","not_found":404},
    {"name":"HackerNews","url":"https://news.ycombinator.com/user?id={}","check":"html","found":"<td>user:</td>"},
    {"name":"Replit","url":"https://replit.com/@{}","check":"status","not_found":404},
    {"name":"Codepen","url":"https://codepen.io/{}","check":"status","not_found":404},
    {"name":"Dribbble","url":"https://dribbble.com/{}","check":"status","not_found":404},
    {"name":"Behance","url":"https://www.behance.net/{}","check":"status","not_found":404},
    {"name":"Vimeo","url":"https://vimeo.com/{}","check":"status","not_found":404},
    {"name":"SoundCloud","url":"https://soundcloud.com/{}","check":"status","not_found":404},
    {"name":"Flickr","url":"https://www.flickr.com/people/{}","check":"status","not_found":404},
    {"name":"Keybase","url":"https://keybase.io/{}","check":"json","key":"them"},
    {"name":"Pastebin","url":"https://pastebin.com/u/{}","check":"status","not_found":404},
    {"name":"ProductHunt","url":"https://www.producthunt.com/@{}","check":"status","not_found":404},
    {"name":"Gravatar","url":"https://en.gravatar.com/{}","check":"status","not_found":404},
    {"name":"Npm","url":"https://www.npmjs.com/~{}","check":"status","not_found":404},
    {"name":"PyPI","url":"https://pypi.org/user/{}/","check":"status","not_found":404},
    {"name":"DockerHub","url":"https://hub.docker.com/u/{}","check":"status","not_found":404},
    {"name":"Quora","url":"https://www.quora.com/profile/{}","check":"status","not_found":404},
    {"name":"VK","url":"https://vk.com/{}","check":"html","not_found":"Page not found"},
    {"name":"Last.fm","url":"https://www.last.fm/user/{}","check":"status","not_found":404},
    {"name":"Ko-fi","url":"https://ko-fi.com/{}","check":"status","not_found":404},
    {"name":"Wattpad","url":"https://www.wattpad.com/user/{}","check":"status","not_found":404},
    {"name":"Imgur","url":"https://imgur.com/user/{}","check":"status","not_found":404},
    {"name":"About.me","url":"https://about.me/{}","check":"status","not_found":404},
    {"name":"Fiverr","url":"https://www.fiverr.com/{}","check":"status","not_found":404},
    {"name":"AngelList","url":"https://angel.co/u/{}","check":"status","not_found":404},
    {"name":"Telegram","url":"https://t.me/{}","check":"html","found":"tgme_page_title"},
    {"name":"Mastodon","url":"https://mastodon.social/@{}","check":"status","not_found":404},
    {"name":"Bluesky","url":"https://bsky.app/profile/{}","check":"status","not_found":404},
    {"name":"Mixcloud","url":"https://www.mixcloud.com/{}/","check":"status","not_found":404},
    {"name":"Freelancer","url":"https://www.freelancer.com/u/{}","check":"status","not_found":404},
    {"name":"500px","url":"https://500px.com/p/{}","check":"status","not_found":404},
    {"name":"Thingiverse","url":"https://www.thingiverse.com/{}","check":"status","not_found":404},
    {"name":"Hackernoon","url":"https://hackernoon.com/u/{}","check":"status","not_found":404},
    {"name":"Disqus","url":"https://disqus.com/by/{}","check":"status","not_found":404},
    {"name":"Codecademy","url":"https://www.codecademy.com/profiles/{}","check":"status","not_found":404},
    {"name":"Spotify","url":"https://open.spotify.com/user/{}","check":"status","not_found":404},
    {"name":"Letterboxd","url":"https://letterboxd.com/{}","check":"status","not_found":404},
]

HEADERS = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}

def check_site(username, site, timeout=8):
    url = site["url"].format(username)
    check = site.get("check","status")
    try:
        resp = requests.get(url, headers=HEADERS, timeout=timeout, allow_redirects=True)
        if check == "status":
            not_found = site.get("not_found", 404)
            found = resp.status_code not in (404, 410, 403) and resp.status_code == 200
        elif check == "html":
            if "found" in site:
                found = site["found"] in resp.text
            elif "not_found" in site:
                found = site["not_found"] not in resp.text and resp.status_code == 200
            else:
                found = resp.status_code == 200
        elif check == "json":
            try:
                data = resp.json()
                key = site.get("key","")
                found = key in str(data) and resp.status_code == 200
            except: found = False
        else:
            found = resp.status_code == 200
        return {"platform":site["name"],"url":url,
                "status":"✅ Trouvé" if found else "❌ Non trouvé",
                "found":found,"code":resp.status_code}
    except Exception as e:
        return {"platform":site["name"],"url":url,"status":"⚫ Erreur réseau","found":False,"code":0}

def run(username, timeout=8, max_workers=30, progress_callback=None):
    results = []
    done = 0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(check_site, username, s, timeout): s for s in SITES}
        for fut in as_completed(futures):
            done += 1
            res = fut.result()
            results.append(res)
            if progress_callback: progress_callback(done, len(SITES), res)
    results.sort(key=lambda x: (0 if x["found"] else 1, x["platform"]))
    return results
