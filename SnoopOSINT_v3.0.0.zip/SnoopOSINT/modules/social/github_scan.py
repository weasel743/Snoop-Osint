import requests

HEADERS = {
    "User-Agent": "SnoopOSINT/2.0",
    "Accept": "application/vnd.github.v3+json"
}


def run(username, timeout=10):
    results = []
    user_data = _get_user(username, timeout)
    if user_data:
        results.extend(user_data)
    repos = _get_repos(username, timeout)
    results.extend(repos)
    orgs = _get_orgs(username, timeout)
    results.extend(orgs)
    events = _get_events(username, timeout)
    results.extend(events)
    emails = _extract_emails(username, timeout)
    results.extend(emails)
    return results


def _get_user(username, timeout):
    try:
        resp = requests.get(f"https://api.github.com/users/{username}",
                            headers=HEADERS, timeout=timeout)
        if resp.status_code == 404:
            return [{"champ": "Erreur", "valeur": "Utilisateur introuvable", "source": "GitHub API"}]
        if resp.status_code != 200:
            return []
        d = resp.json()
        fields = {
            "Nom": d.get("name", ""),
            "Login": d.get("login", ""),
            "ID": str(d.get("id", "")),
            "Bio": d.get("bio", ""),
            "Email public": d.get("email", ""),
            "Entreprise": d.get("company", ""),
            "Localisation": d.get("location", ""),
            "Site web": d.get("blog", ""),
            "Twitter": d.get("twitter_username", ""),
            "Repos publics": str(d.get("public_repos", 0)),
            "Gists publics": str(d.get("public_gists", 0)),
            "Followers": str(d.get("followers", 0)),
            "Following": str(d.get("following", 0)),
            "Créé le": d.get("created_at", "")[:10],
            "Mis à jour": d.get("updated_at", "")[:10],
            "Profil URL": d.get("html_url", ""),
            "Avatar": d.get("avatar_url", ""),
            "Hireable": "Oui" if d.get("hireable") else "Non",
        }
        return [{"champ": k, "valeur": str(v), "source": "GitHub API"}
                for k, v in fields.items() if v]
    except Exception as e:
        return [{"champ": "Erreur", "valeur": str(e), "source": "GitHub API"}]


def _get_repos(username, timeout):
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/repos",
            params={"per_page": 30, "sort": "updated"},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code != 200:
            return []
        repos = resp.json()
        results = [{"champ": "Nombre de repos", "valeur": str(len(repos)), "source": "GitHub API"}]
        for r in repos[:10]:
            desc = r.get("description", "") or ""
            lang = r.get("language", "") or ""
            stars = r.get("stargazers_count", 0)
            results.append({
                "champ": f"Repo: {r['name']}",
                "valeur": f"⭐{stars} | {lang} | {desc[:60]}",
                "source": "GitHub Repos"
            })
        langs = {}
        for r in repos:
            l = r.get("language", "")
            if l:
                langs[l] = langs.get(l, 0) + 1
        if langs:
            lang_str = ", ".join(f"{l}({c})" for l, c in sorted(langs.items(), key=lambda x: -x[1])[:8])
            results.append({"champ": "Langages principaux", "valeur": lang_str, "source": "GitHub API"})
        return results
    except Exception:
        return []


def _get_orgs(username, timeout):
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/orgs",
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code != 200:
            return []
        orgs = resp.json()
        if not orgs:
            return []
        org_names = ", ".join(o.get("login", "") for o in orgs)
        return [{"champ": "Organisations", "valeur": org_names, "source": "GitHub API"}]
    except Exception:
        return []


def _get_events(username, timeout):
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/events/public",
            params={"per_page": 10},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code != 200:
            return []
        events = resp.json()
        results = []
        for ev in events[:5]:
            etype = ev.get("type", "")
            repo = ev.get("repo", {}).get("name", "")
            date = ev.get("created_at", "")[:10]
            results.append({"champ": f"Event: {etype}", "valeur": f"{repo} — {date}", "source": "GitHub Events"})
        return results
    except Exception:
        return []


def _extract_emails(username, timeout):
    emails = set()
    try:
        resp = requests.get(
            f"https://api.github.com/users/{username}/events/public",
            params={"per_page": 30},
            headers=HEADERS, timeout=timeout
        )
        if resp.status_code == 200:
            import re
            text = resp.text
            found = re.findall(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}', text)
            for e in found:
                if "github" not in e.lower() and "noreply" not in e.lower():
                    emails.add(e)
    except Exception:
        pass
    if emails:
        return [{"champ": "Email extrait", "valeur": e, "source": "GitHub Events (scraping)"}
                for e in emails]
    return []
