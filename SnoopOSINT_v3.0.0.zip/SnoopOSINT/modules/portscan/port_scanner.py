import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS",
    445: "SMB", 993: "IMAPS", 995: "POP3S", 3306: "MySQL",
    3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 6379: "Redis",
    8080: "HTTP-Alt", 8443: "HTTPS-Alt", 8888: "HTTP-Dev",
    27017: "MongoDB", 9200: "Elasticsearch", 6443: "Kubernetes"
}


def scan_port(host, port, timeout=0.8):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        if result == 0:
            banner = _grab_banner(host, port, timeout)
            return {
                "port": str(port),
                "service": COMMON_PORTS.get(port, "Inconnu"),
                "statut": "🟢 Ouvert",
                "banner": banner
            }
        return {"port": str(port), "service": COMMON_PORTS.get(port, "Inconnu"),
                "statut": "🔴 Fermé", "banner": ""}
    except Exception:
        return {"port": str(port), "service": COMMON_PORTS.get(port, "Inconnu"),
                "statut": "⚫ Erreur", "banner": ""}


def _grab_banner(host, port, timeout):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        sock.connect((host, port))
        if port in (80, 8080, 8888):
            sock.send(b"HEAD / HTTP/1.0\r\n\r\n")
        elif port == 22:
            pass
        banner = sock.recv(256).decode("utf-8", errors="replace").strip()[:100]
        sock.close()
        return banner
    except Exception:
        return ""


def run(host, ports=None, timeout=0.8, max_workers=50, progress_callback=None):
    clean_host = host.replace("https://", "").replace("http://", "").split("/")[0]
    try:
        resolved_ip = socket.gethostbyname(clean_host)
    except Exception:
        return [{"port": "?", "service": "Erreur", "statut": "❌ Impossible de résoudre l'hôte", "banner": ""}]

    if ports is None:
        ports = list(COMMON_PORTS.keys())

    results = []
    total = len(ports)
    done = 0

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(scan_port, clean_host, p, timeout): p for p in ports}
        for fut in as_completed(futures):
            done += 1
            res = fut.result()
            results.append(res)
            if progress_callback:
                progress_callback(done, total, res)

    results.insert(0, {"port": "INFO", "service": "Hôte résolu", "statut": "ℹ️", "banner": resolved_ip})
    results.sort(key=lambda x: (0 if "Ouvert" in x["statut"] else 1,
                                int(x["port"]) if x["port"].isdigit() else 0))
    return results
