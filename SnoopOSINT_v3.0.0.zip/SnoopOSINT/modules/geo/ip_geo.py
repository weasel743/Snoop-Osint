from modules.ip.ipapi import run as ip_run

def run(ip_or_domain, timeout=10):
    return ip_run(ip_or_domain, timeout)
