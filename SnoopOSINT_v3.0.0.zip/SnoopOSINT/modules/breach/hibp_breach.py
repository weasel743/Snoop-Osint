from modules.email.hibp import run as hibp_run

def run(email, api_key="", timeout=10):
    return hibp_run(email, api_key=api_key, timeout=timeout)
