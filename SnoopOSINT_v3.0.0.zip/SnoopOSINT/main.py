#!/usr/bin/env python3
"""
⚡ Snoop OSINT v3.0.0
Corrélation automatique • Sources françaises • Vue graphe • 0 clef API requise
"""
import sys, os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)
for d in ("data","logs","reports","plugins"):
    os.makedirs(os.path.join(BASE_DIR,d), exist_ok=True)

def main():
    try:
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import Qt
        from PyQt6.QtGui import QFont
    except ImportError:
        print("❌ PyQt6 manquant. Lancez: pip install PyQt6")
        sys.exit(1)

    app = QApplication(sys.argv)
    app.setApplicationName("Snoop OSINT")
    app.setApplicationVersion("3.0.0")

    # Compatible toutes versions PyQt6
    font = QFont("Segoe UI", 10)
    app.setFont(font)

    from core.config_manager import ConfigManager
    from core.theme_manager import ThemeManager
    cfg = ConfigManager()
    tm = ThemeManager()
    tm.apply_theme(app, cfg.get("app", "theme", default="violet"))

    from ui.main_window import MainWindow
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
