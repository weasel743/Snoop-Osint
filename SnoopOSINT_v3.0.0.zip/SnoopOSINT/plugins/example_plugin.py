"""
Exemple de plugin Snoop OSINT
Copiez ce fichier, modifiez les métadonnées et la fonction run().
"""

PLUGIN_NAME = "Example Plugin"
PLUGIN_VERSION = "1.0.0"
PLUGIN_DESCRIPTION = "Plugin d'exemple — cherche le terme dans DuckDuckGo"
PLUGIN_AUTHOR = "SnoopOSINT"


def run(query, timeout=10, **kwargs):
    """
    Fonction principale du plugin.
    Doit retourner une liste de dicts.
    """
    import requests
    results = []
    try:
        resp = requests.get(
            "https://api.duckduckgo.com/",
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            headers={"User-Agent": "SnoopOSINT Plugin"},
            timeout=timeout
        )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("Abstract"):
                results.append({
                    "type": "Abstract",
                    "value": data["Abstract"][:300],
                    "source": data.get("AbstractSource", "DuckDuckGo")
                })
            for r in data.get("RelatedTopics", [])[:10]:
                if isinstance(r, dict) and r.get("Text"):
                    results.append({
                        "type": "Related",
                        "value": r["Text"][:200],
                        "source": "DuckDuckGo"
                    })
    except Exception as e:
        results.append({"type": "Erreur", "value": str(e), "source": "Plugin"})
    return results
